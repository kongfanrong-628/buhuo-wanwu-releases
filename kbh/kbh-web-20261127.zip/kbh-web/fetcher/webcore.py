# -*- coding: utf-8 -*-
"""写作工坊网页端业务核心（任务 #63）。

设计约束（来自 11-26 拍板）：
  - 去AI味 = 用户点「一键改写」把当前正文改掉，规则同源、锁 provider=cloud_llm；
  - 网页端无本地模型、无朱雀 → 只走 BYOK writing Key 服务端代调用；
  - AIGC = 显式角标 + 隐式元数据（不做盲水印，不承诺保证过检）；
  - 纯规则（ai_score / detox_post / rule_post）放 wccore/ 子包，零第三方依赖。

本模块由 server.py 注入 CFG 后调用，异常一律转成 {ok:false,...} 不外抛。
线上仅标准库 + requests（会员站 requirements 已有）。
"""
import base64
import hashlib
import json
import os
import time

CFG = {}  # server.py 注入：{"byok": byok_vault 模块, "cloud_headers": fn, "db": CLOUD_DB, "rpc": ...}

MAX_LEN = 50000

# 去AI味规则 prompt（与桌面端 detox._DETOX_RULES 同源，去掉 IP 称呼占位以保持中性）
_DETOX_RULES = """你是中文内容校对专家。任务：在「保留作者真人第一人称亲历声音」的前提下，只做最小必要修正，不重写、不润色、不洗掉人味。
最小修正规则：
1. 只改明显的错别字和事实硬伤（如「反应」改「反映」、「同比」改「同期」），其余原样保留。
2. 绝不改动作者的口语化表达、口头禅、停顿、反问——那是人味，必须留。
3. 绝不把第一人称亲历改成第三人称说教。
4. 绝不删掉作者点名的具体工具 / 平台 / 人名 / 时间 / 数字。
5. 不堆排比、不强行加「综上所述」等套话、不强行升华。
6. 保留原文的数据、专有名词、结论，不得杜撰、不得增删信息。
7. 只输出校对后的正文，不要解释。

原文：
"""

# 深度去味追加指令（桌面端 _inject_fulltext_variance 的网页精简版：全文级句长方差）
_VARIANCE = """【全文节奏要求】让整篇的句长有明显起伏：故意穿插极短句（3–8字）和较长句，
避免每段都长短齐全导致全文节奏均匀。不要用排比三段式。删掉只为引出下文的过渡句。

"""


class WebError(Exception):
    def __init__(self, code, http, message):
        self.code, self.http, self.message = code, http, message
        super().__init__(message)


def _body(resp, tag):
    try:
        return resp.json()
    except Exception:
        raise WebError("BAD_JSON", 502, "%s 返回非 JSON（HTTP %d）" % (tag, resp.status_code))


def _get_writing_key(token, uid):
    """从 BYOK 保险箱取 writing 槽明文 Key（仅服务端内部用，绝不出网到前端）。"""
    bv = CFG.get("byok")
    if not bv:
        raise WebError("VAULT_NOT_READY", 503, "密钥保险箱未加载")
    try:
        data, _err = bv.reveal(token, uid, "writing")
    except Exception as e:
        code = getattr(e, "code", "KEY_ERROR")
        http = getattr(e, "http", 400)
        raise WebError(code, http, str(e))
    if not data or not data.get("key"):
        raise WebError("KEY_NOT_CONFIGURED", 404, "还没配置写作 Key，去会员站保险箱添加后再试")
    return data


def llm_chat(token, uid, messages, temperature=0.75, timeout=180):
    """BYOK 服务端代调：OpenAI 兼容 /v1/chat/completions（同步 requests）。

    Key/base_url/model 全部来自用户保险箱 writing 槽；失败原因按 body 分类，
    绝不把上游原始 JSON 整段甩给前端。
    """
    import requests
    info = _get_writing_key(token, uid)
    key = info["key"]
    base = (info.get("base_url") or "https://api.openai.com/v1").rstrip("/")
    model = (info.get("model") or "gpt-4o-mini").strip()
    url = base + "/chat/completions"
    payload = {"model": model, "messages": messages, "temperature": temperature}
    try:
        r = requests.post(url,
                          headers={"Authorization": "Bearer " + key,
                                   "Content-Type": "application/json"},
                          json=payload, timeout=timeout)
    except requests.RequestException as e:
        raise WebError("UPSTREAM_NET", 502, "模型服务连接失败：%s" % str(e)[:120])
    if r.status_code == 401:
        raise WebError("KEY_INVALID", 401, "写作 Key 无效或已过期，去保险箱检查")
    if r.status_code == 429:
        raise WebError("QUOTA", 429, "模型账号额度不足或被限流，稍后重试或换 Key")
    if r.status_code == 400 and "guardrail" in r.text.lower():
        raise WebError("GUARDRAIL", 422, "内容触发上游安全策略，不是积分问题；可缩短文本重试")
    if r.status_code >= 400:
        raise WebError("UPSTREAM", 502, "模型服务返回 HTTP %d" % r.status_code)
    data = _body(r, "模型服务")
    try:
        out = data["choices"][0]["message"]["content"]
    except Exception:
        raise WebError("BAD_RESULT", 502, "模型返回格式异常，未取到正文")
    if not isinstance(out, str) or not out.strip():
        raise WebError("EMPTY_RESULT", 502, "模型返回空内容，请重试")
    return out.strip()


def score(text):
    """零 token 本地打分（ai_score.scan）。"""
    from wccore import ai_score
    r = ai_score.scan(text)
    return {"verdict": r.get("verdict"), "total": r.get("total"),
            "stats": r.get("stats"), "advice": r.get("advice")}


def detox_once(token, uid, content, mode="deep"):
    """一键去AI味：打分保护闸 →（需改写时）BYOK LLM → 后处理 → 返回。

    mode: deep（深度去味）/ proof（最小校对）。网页端锁 cloud_llm。
    """
    from wccore import ai_score, detox_post
    content = (content or "").strip()
    if not content:
        raise WebError("EMPTY", 400, "正文不能为空")
    if len(content) > MAX_LEN:
        raise WebError("TOO_LONG", 400, "正文超过 %d 字上限" % MAX_LEN)
    before = score(content)

    # 真人特征保护闸：原稿已很「人」时不改写，避免越改越差（与桌面端同源）
    if mode == "deep" and len(content) >= 200 and before.get("verdict") == "PASS":
        return {"content": content, "word_count": len(content),
                "before": before, "after": before,
                "detox_ok": True, "skipped": True,
                "skip_note": "原稿已具真人写作特征（本地扫描 %s/100），未改写——改写只会引入新 AI 味" % before.get("total"),
                "mode": mode}

    masked, mask = detox_post.mask_entities(content)
    rules = _DETOX_RULES if mode == "proof" else (_VARIANCE + _DETOX_RULES)
    raw = llm_chat(token, uid, [{"role": "user", "content": rules + masked}])
    aligned, rep = detox_post.postprocess(content, raw, mask)
    after = score(aligned)
    return {"content": aligned, "word_count": len(aligned),
            "before": before, "after": after,
            "detox_ok": True, "mode": mode,
            "postprocess": {"drift": rep.get("drift"),
                            "leak_cleared": bool((rep.get("leak") or {}).get("head"))}}


def aigc_mark(content, *, tool="不惑万物写作工坊", model="", label="AI 辅助创作"):
    """AIGC 双标识：显式角标（返回给前端渲染）+ 隐式元数据（存作品表）。

    不做盲水印；不承诺「保证过检」。隐式元数据用不可见零宽字符编码摘要，
    复制正文仍携带；显式角标由前端按 label 渲染在结果区。
    """
    digest = hashlib.sha256((content or "").encode("utf-8")).hexdigest()[:16]
    meta = {"label": label, "tool": tool, "model": model,
            "created_at": int(time.time()), "content_hash": digest}
    # 隐式：零宽字符编码 digest（U+200B=0 / U+200C=1），肉眼不可见
    zw = "".join("\u200b" if c == "0" else "\u200c" for c in "".join(bin(int(x, 16))[2:].zfill(4) for x in digest))
    marked = (content or "") + "\n\u200b" + zw
    return {"content": marked, "meta": meta, "label": label}


def strip_aigc(content):
    """去掉隐式零宽标记（读取正文时还原干净文本）。"""
    return "".join(c for c in (content or "") if c not in ("\u200b", "\u200c"))


# ── 长文写作（#63 切片3c）：通用 prompt + BYOK 代调 ──────────────────
# 网页端第一批不做桌面端 9 段风格档案链（那是第二批），用干净的通用 prompt
# 覆盖高频动作；风格档案/赛道 playbook 留 beta 反馈后再接。
_SYS_WRITER = """你是中文长文作者。写真人会写的文章：具体、克制、有细节，不堆排比套话，
不写「综上所述/值得注意的是」这类 AI 腔。事实、数字、专有名词一律保留原样，不得杜撰。
只输出正文，不要解释你的做法。"""

_ACTIONS = {
    "outline": {
        "prompt": "请把下面的选题拆成一份可直接写稿的大纲：{n} 个部分，每部分给出要点和要回答的问题。\n\n选题：{title}\n补充要求：{ctx}",
        "temp": 0.6,
    },
    "write": {
        "prompt": "按下面的大纲写一篇约 {n} 字的完整文章。首行写标题。\n\n大纲：{title}\n写作要求：{ctx}",
        "temp": 0.8,
    },
    "polish": {
        "prompt": "润色下面的正文：修复错别字和语病、让句子更自然，保留作者本来的语气和全部事实与数字，不重写结构。只输出润色后正文。\n\n{title}",
        "temp": 0.5,
    },
    "improve-title": {
        "prompt": "给下面的文章拟 5 个差异化标题，一行一个，不加序号：\n\n{title}\n要求：{ctx}",
        "temp": 0.9,
    },
    "improve-content": {
        "prompt": "按下面的要求改进这段正文，保留全部事实与数字：\n\n要求：{ctx}\n\n正文：\n{title}",
        "temp": 0.7,
    },
    "generate-titles": {
        "prompt": "围绕选题给出 {n} 个标题候选，一行一个，不加序号。\n\n选题：{title}\n{ctx}",
        "temp": 0.9,
    },
    "rewrite-segment": {
        "prompt": "按下面的要求改写这一段，保留全部事实与数字，只输出改写后段落：\n\n要求：{ctx}\n\n段落：\n{title}",
        "temp": 0.7,
    },
}


def gen_longform(token, uid, action, title="", ctx="", n=0):
    """长文写作统一入口：大纲/正文/润色/标题/改段。返回 {content, action}。"""
    if action not in _ACTIONS:
        raise WebError("BAD_ACTION", 400, "未知写作动作：" + str(action)[:40])
    title = str(title or "").strip()
    ctx = str(ctx or "").strip()
    if not title and action not in ("improve-titles",):
        raise WebError("EMPTY", 400, "选题/正文不能为空")
    if len(title) + len(ctx) > 30000:
        raise WebError("TOO_LONG", 400, "输入内容过长")
    spec = _ACTIONS[action]
    prompt = spec["prompt"].format(
        title=title[:12000],
        ctx=ctx[:8000],
        n=int(n) if n else (1500 if action == "write" else (5 if "title" in action else 5)))
    out = llm_chat(token, uid,
                   [{"role": "system", "content": _SYS_WRITER},
                    {"role": "user", "content": prompt}],
                   temperature=spec["temp"])
    return {"content": out, "action": action, "word_count": len(out)}
