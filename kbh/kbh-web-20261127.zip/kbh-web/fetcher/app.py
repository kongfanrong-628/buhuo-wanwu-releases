# -*- coding: utf-8 -*-
"""
孔不惑 · 作品链接抓取服务
零第三方依赖（纯标准库），可直接用 python app.py 起服务，也可部署到任意 Python 托管。

POST /fetch   {"url": "用户粘贴的任何内容（可以是一整段分享口令）"}
  -> {"ok":true, "platform":"xhs", "title":..., "desc":..., "images":[...], "comments":[...], ...}

GET  /health  -> {"ok":true}
"""
import json
import os
import re
import html as htmlmod
import gzip
import io
import ssl
import sys
import time
import traceback
import http.cookiejar
import threading
import urllib.request
import urllib.parse
import urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from html.parser import HTMLParser

try:
    import ocr as ocr_mod
except Exception:
    try:
        from . import ocr as ocr_mod
    except Exception:
        ocr_mod = None

UA_PC = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
         "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")
UA_MB = ("Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) "
         "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1")

ALLOW_ORIGIN = os.environ.get("ALLOW_ORIGIN", "*")
TIMEOUT = 22

# requests 优先：实测同为纯净 cookie + 同一 token，requests 能拿到正文，
# 纯 urllib 请求一律被 302 到 /login（WAF 认请求指纹，不是参数问题）。
try:
    import requests as _rq
except ImportError:
    _rq = None

_RS = [None]


def _rsess():
    if _RS[0] is None:
        s = _rq.Session()
        s.trust_env = False  # 不走系统代理，本机 http_proxy 会干扰
        _RS[0] = s
    return _RS[0]

# 小红书前面挂着 WAF：不带 acw_tc / abRequestId 这两个 cookie 直接请求笔记页，
# 会被 302 到 /login（看起来像"分享参数过期"，其实参数是好的）。
# 先打一次首页把 cookie 拿到手，同一个 jar 后续所有请求都带。
_COOKIE_JAR = http.cookiejar.CookieJar()
_warm_lock = threading.Lock()
_warm_at = [0.0]


def warm_xhs(force=False):
    with _warm_lock:
        if not force and _warm_at[0] and time.time() - _warm_at[0] < 300 and len(_COOKIE_JAR) > 0:
            return
        http_get("https://www.xiaohongshu.com/", ua=UA_PC, timeout=12, max_bytes=300_000)
        _warm_at[0] = time.time()

# 同一链接 3 分钟内只真抓一次：两个平台都按 IP 记访问频次，
# 用户来回改标题重抓会把出口 IP 打黑（实测本机跑十几次后微信公众号只剩空壳页）。
#
# 为什么从 10 分钟改成 3 分钟：
#   这份缓存的唯一价值是「防风控」——挡住短时间内对同一 URL 的重复请求。
#   正文抓完会立刻返回前端、存进页面上的输入框，后端这份当场就完成了使命，
#   之后留着只是白白延长第三方内容的留存时间。
#   一次「粘贴链接 → 抓取 → 拆解」的操作通常在 1-2 分钟内走完，
#   3 分钟足够覆盖误刷新和重复点击，同时把留存压到最小。
#   合规口径：抓取内容仅供本次分析，不落盘、不入库、进程重启即失。
CACHE_TTL = int(os.environ.get("CACHE_TTL") or 180)
_cache = {}
_cache_lock = __import__("threading").Lock()


def cache_get(key):
    now = time.time()
    with _cache_lock:
        hit = _cache.get(key)
        if not hit:
            return None
        ts, val = hit
        if now - ts > CACHE_TTL:
            _cache.pop(key, None)
            return None
        return val


def cache_put(key, val):
    with _cache_lock:
        if len(_cache) > 300:
            for k in sorted(_cache, key=lambda k: _cache[k][0])[:100]:
                _cache.pop(k, None)
        _cache[key] = (time.time(), val)


# ---------------------------------------------------------------- HTTP 工具

def http_get(url, ua=UA_PC, referer=None, timeout=TIMEOUT, max_bytes=6_000_000):
    """返回 (status, final_url, text)。不抛异常，失败返回 status=0。"""
    if _rq is not None:
        return _http_get_requests(url, ua, referer, timeout, max_bytes)
    return _http_get_urllib(url, ua, referer, timeout, max_bytes)


def _http_get_requests(url, ua, referer, timeout, max_bytes):
    # 头越少越安全：实测只带 UA 能过，加 Referer / Sec-Fetch-* 反而容易被判机器
    headers = {"User-Agent": ua, "Accept-Language": "zh-CN,zh;q=0.9"}
    if referer:
        headers["Referer"] = referer
    try:
        r = _rsess().get(url, headers=headers, timeout=timeout, allow_redirects=True)
        text = r.text or ""
        if len(text) > max_bytes:
            text = text[:max_bytes]
        return r.status_code, r.url, text
    except Exception:
        return 0, url, ""


def _http_get_urllib(url, ua, referer, timeout, max_bytes):
    headers = {
        "User-Agent": ua,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.6",
        "Accept-Encoding": "gzip",
        "Connection": "close",
    }
    if referer:
        headers["Referer"] = referer
    req = urllib.request.Request(url, headers=headers)
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    # 显式绕过系统代理：本机常带 http_proxy，云上没有，统一走直连最稳
    opener = urllib.request.build_opener(
        urllib.request.ProxyHandler({}),
        urllib.request.HTTPCookieProcessor(_COOKIE_JAR),
        urllib.request.HTTPSHandler(context=ctx),
    )
    try:
        with opener.open(req, timeout=timeout) as r:
            raw = r.read(max_bytes + 1)
            if len(raw) > max_bytes:
                raw = raw[:max_bytes]
            if r.headers.get("Content-Encoding") == "gzip":
                try:
                    raw = gzip.GzipFile(fileobj=io.BytesIO(raw)).read()
                except Exception:
                    pass
            enc = "utf-8"
            ct = r.headers.get("Content-Type", "") or ""
            m = re.search(r"charset=([\w-]+)", ct, re.I)
            if m:
                enc = m.group(1)
            try:
                text = raw.decode(enc, "replace")
            except LookupError:
                text = raw.decode("utf-8", "replace")
            return r.status, r.geturl(), text
    except urllib.error.HTTPError as e:
        body = ""
        try:
            body = e.read(200_000).decode("utf-8", "replace")
        except Exception:
            pass
        return e.code, url, body
    except Exception:
        return 0, url, ""


# ---------------------------------------------------------------- 链接识别

URL_RE = re.compile(r"https?://[^\s\u4e00-\u9fa5，。！？、；：\"'）】》]+", re.I)


def pick_url(text):
    """从任意粘贴内容里挑出第一个作品链接。支持整段分享口令。"""
    if not text:
        return ""
    t = text.strip()
    found = URL_RE.findall(t)
    if not found:
        return ""
    # 优先作品域名
    prio = ("xiaohongshu.com", "xhslink.com", "mp.weixin.qq.com", "toutiao.com",
            "douyin.com", "iesdouyin.com", "weibo.com", "bilibili.com")
    for p in prio:
        for u in found:
            if p in u:
                return u.rstrip(").,;'\"")
    return found[0].rstrip(").,;'\"")


def detect_platform(url):
    """只支持小红书。别家要么有验证码，要么没有公开网页，抓了也是白抓。"""
    u = url.lower()
    if "xhslink.com" in u or "xiaohongshu.com" in u:
        return "xhs"
    if "mp.weixin.qq.com" in u:
        return "gzh"
    if "toutiao.com" in u:
        return "toutiao"
    if "douyin.com" in u or "iesdouyin.com" in u:
        return "douyin"
    if "bilibili.com" in u or "b23.tv" in u:
        return "bili"
    if "weibo.com" in u or "weibo.cn" in u:
        return "weibo"
    if "shipinhao" in u or "channels.weixin.qq.com" in u:
        return "sph"
    return "unknown"


# ---------------------------------------------------------------- JS 对象解析

def balanced_json(text, start_idx):
    """从 start_idx 处的 '{' 开始做括号配平，跳过字符串内容，返回子串。"""
    if start_idx < 0 or start_idx >= len(text) or text[start_idx] != "{":
        return ""
    depth = 0
    i = start_idx
    in_str = False
    quote = ""
    esc = False
    n = len(text)
    while i < n:
        c = text[i]
        if in_str:
            if esc:
                esc = False
            elif c == "\\":
                esc = True
            elif c == quote:
                in_str = False
        else:
            if c in "\"'":
                in_str = True
                quote = c
            elif c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
                if depth == 0:
                    return text[start_idx:i + 1]
        i += 1
    return ""


def js_to_json(s):
    """把 JS 字面量里 JSON 不认的 token 修掉。"""
    s = re.sub(r":\s*undefined\b", ":null", s)
    s = re.sub(r":\s*NaN\b", ":null", s)
    s = re.sub(r":\s*Infinity\b", ":null", s)
    s = re.sub(r"\bundefined\b", "null", s)
    return s


def grab_state_object(page, marker="__INITIAL_STATE__"):
    idx = page.find(marker)
    if idx < 0:
        return None
    brace = page.find("{", idx)
    if brace < 0:
        return None
    raw = balanced_json(page, brace)
    if not raw:
        return None
    for candidate in (raw, js_to_json(raw)):
        try:
            return json.loads(candidate)
        except Exception:
            continue
    return None


# ---------------------------------------------------------------- 小红书

def xhs_follow_redirect(url):
    """xhslink 短链 / 无 token 链接 → 尽力拿到 (noteId, xsecToken, finalUrl)。"""
    nid = ""
    m = re.search(r"/(?:explore|discovery/item|item)/([0-9a-f]{24})", url)
    if m:
        nid = m.group(1)
    q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
    token = (q.get("xsec_token") or [""])[0]

    if not nid or "xhslink.com" in url:
        # 短链：跟随跳转，Location 里通常带 noteId + xsec_token
        status, final, body = http_get(url, ua=UA_MB, timeout=15, max_bytes=200_000)
        for cand in (final, body):
            if not cand:
                continue
            m2 = re.search(r"/(?:explore|discovery/item|item)/([0-9a-f]{24})", cand)
            if m2 and not nid:
                nid = m2.group(1)
            m3 = re.search(r"xsec_token=([A-Za-z0-9%_\-=]+)", cand)
            if m3 and not token:
                token = urllib.parse.unquote(m3.group(1))
            if nid and token:
                break
        if not nid:
            # 有些短链把 id 放在 itemId 参数里
            m4 = re.search(r"itemId[=%3D]+([0-9a-f]{24})", body or "")
            if m4:
                nid = m4.group(1)
    return nid, token, url


def xhs_extract(page, nid):
    """页面 → (note, comments)。兼容两种形态：
    PC 端 window.__INITIAL_STATE__.note.noteDetailMap
    手机端 window.__INITIAL_STATE__.noteData.data.noteData（同时带 commentData）
    """
    st = grab_state_object(page)
    if not st:
        return None

    ndm = (st.get("note") or {}).get("noteDetailMap") or {}
    if ndm:
        entry = ndm.get(nid) or list(ndm.values())[0]
        note = (entry or {}).get("note") or {}
        if note:
            raw = ((entry.get("comments") or {}).get("list") or [])
            cmts = [{
                "user": ((c.get("userInfo") or {}).get("nickname") or ""),
                "text": (c.get("content") or "").strip(),
                "like": c.get("likeCount") or "0",
            } for c in raw]
            return note, cmts

    nd = ((st.get("noteData") or {}).get("data") or {})
    note = nd.get("noteData") or {}
    if note:
        cmts = []
        for c in ((nd.get("commentData") or {}).get("comments") or []):
            cmts.append({
                "user": ((c.get("user") or {}).get("nickname") or ""),
                "text": (c.get("content") or "").strip(),
                "like": c.get("likeCount") or c.get("likeViewCount") or "0",
            })
            for sub in (c.get("subComments") or []):
                cmts.append({
                    "user": ((sub.get("user") or {}).get("nickname") or ""),
                    "text": "└ " + (sub.get("content") or "").strip(),
                    "like": sub.get("likeCount") or sub.get("likeViewCount") or "0",
                })
        return note, cmts

    return None


def parse_xhs(url, do_ocr=False):
    nid, token, _ = xhs_follow_redirect(url)
    notes = []
    warnings = []

    if not nid:
        return {"ok": False, "platform": "xhs",
                "error": "no_note_id",
                "message": "没从这个链接里认出笔记 ID。请在手机 App 里点【分享 → 复制链接】，把整段口令粘进来（网页版地址栏里的裸链接抓不到，必须带分享参数）。"}

    warm_xhs()

    state = None
    tried = []
    candidates = [url]  # 第一优先：用户给的原始链接，一个字都不改
    if token:
        candidates.append("https://www.xiaohongshu.com/explore/%s?xsec_token=%s&xsec_source=pc_feed"
                          % (nid, urllib.parse.quote(token, safe="")))
        candidates.append("https://www.xiaohongshu.com/explore/%s?xsec_token=%s&xsec_source=pc_share"
                          % (nid, urllib.parse.quote(token, safe="")))
    candidates.append("https://www.xiaohongshu.com/explore/%s" % nid)

    # url 和 token 都在,但 url 里可能带别的 host/参数,先按原样来
    seen = set()
    raw_comments = []
    for attempt in (0, 1):
        if attempt == 1:
            warm_xhs(force=True)  # 第一轮被判登录墙，重拿 cookie 再来一次
        for u in candidates:
            if attempt == 0 and u in seen:
                continue
            seen.add(u)
            # 手机 UA 优先：PC 端更容易被风控成 /login，手机页反而稳
            for ua, tag in ((UA_MB, "M"), (UA_PC, "P")):
                status, final, page = http_get(u, ua=ua)
                tried.append((status, tag + final[:70], len(page)))
                ex = xhs_extract(page, nid)
                if ex:
                    note, raw_comments = ex
                    state = True
                    break
            if state:
                break
        if state:
            break

    if not state:
        msg = "打开笔记页失败。"
        if not token:
            msg += "这个链接没带分享参数（xsec_token），小红书会当成陌生访问直接拦掉。请用 App 的【分享 → 复制链接】重新取一次。"
        else:
            msg += "分享参数可能已过期（一般几天），请在 App 里重新复制一次链接。"
        return {"ok": False, "platform": "xhs", "error": "blocked",
                "message": msg, "debug": tried}

    if not note:
        return {"ok": False, "platform": "xhs", "error": "empty_note",
                "message": "抓到了页面但没解析出笔记内容，可能在灰度实验里。", "debug": tried}

    imgs = []
    for im in (note.get("imageList") or []):
        u = im.get("urlDefault") or im.get("url") or ""
        if not u:
            continue
        infos = im.get("infoList") or []
        for info in infos:
            if info.get("imageScene") == "WB_DFT" and info.get("url"):
                u = info["url"]
                break
        if u.startswith("http://"):
            u = "https://" + u[7:]
        imgs.append({"url": u, "w": im.get("width"), "h": im.get("height")})

    video_url = ""
    vinfo = note.get("video") or {}
    try:
        streams = ((vinfo.get("media") or {}).get("stream") or {})
        for codec in ("h264", "h265", "av1"):
            arr = streams.get(codec) or []
            if arr:
                video_url = arr[0].get("masterUrl") or arr[0].get("backupUrls", [""])[0] or ""
                if video_url:
                    break
    except Exception:
        pass

    comments = raw_comments
    if not comments:
        warnings.append("评论区没取到（小红书要登录才给完整评论），建议把高赞评论手粘几条，这一层的信息价值最高。")

    ii = note.get("interactInfo") or {}
    tags = [t.get("name") for t in (note.get("tagList") or []) if t.get("name")]
    if not tags:
        tags = re.findall(r"#([^#\[\]]+)\[话题\]#", note.get("desc") or "")

    cover_text = ""
    ocr_note = ""
    if do_ocr and imgs:
        if ocr_mod is None or not ocr_mod.available():
            ocr_note = "服务端没装 OCR，封面文字需要你手抄一句"
        else:
            lines, err = ocr_mod.ocr_url(imgs[0]["url"])
            if lines:
                cover_text = ocr_mod.join_lines(lines)[:600]
            else:
                ocr_note = "封面文字没认出来（图太花或下载失败），手抄一句就行"

    return {
        "ok": True,
        "platform": "xhs",
        "coverText": cover_text,
        "ocrNote": ocr_note,
        "url": url,
        "id": nid,
        "kind": note.get("type") or "image",
        "title": (note.get("title") or "").strip(),
        "desc": (note.get("desc") or "").strip(),
        "tags": tags,
        "author": ((note.get("user") or {}).get("nickname")
                   or (note.get("user") or {}).get("nickName") or ""),
        "stats": {
            "liked": ii.get("likedCount") or "",
            "collected": ii.get("collectedCount") or "",
            "comment": ii.get("commentCount") or "",
            "share": ii.get("shareCount") or "",
        },
        "images": imgs,
        "video": video_url,
        "comments": comments,
        "publishedAt": note.get("time") or 0,
        "warnings": warnings,
    }


# ---------------------------------------------------------------- 公众号

# 被风控时微信返回的是一个极短验证页，里面压根没有 #js_content。
GZH_BLOCK_HINTS = ("请在微信客户端打开链接", "环境异常", "去验证",
                   "weixin110", "系统繁忙", "该内容已被发布者删除")


def _gzh_blocked(page):
    """命中验证页提示词，或压根没有正文容器，都算被拦。"""
    if "js_content" not in page:
        return True
    for h in GZH_BLOCK_HINTS:
        if h in page:
            return True
    return False


def _gzh_var(page, name):
    """取页面里的 var xxx = '...' / "..." / 123。公众号元信息都挂在这上面。
    刻意不跨行匹配：正文里常有同名前缀的变量（msg_title 后面紧跟 msg_desc），
    带 re.S 的非贪婪会把下一行一起吃掉，标题就串了。"""
    for pat in (r"var\s+%s\s*=\s*'([^'\n]*)'" % name,
                r'var\s+%s\s*=\s*"([^"\n]*)"' % name,
                r"var\s+%s\s*=\s*([0-9]+)" % name):
        m = re.search(pat, page)
        if m:
            return (m.group(1) or "").strip()
    return ""


def _strip_html(html):
    """HTML 片段 → 纯文本。抽标题/作者这类短片段时用，不引第三方库。"""
    if not html:
        return ""
    t = re.sub(r"(?is)<(script|style)\b.*?</\1>", "", html)
    t = re.sub(r"(?i)<br\s*/?>", " ", t)
    t = re.sub(r"(?s)<[^>]+>", "", t)
    t = (t.replace("&nbsp;", " ").replace("&amp;", "&")
          .replace("&lt;", "<").replace("&gt;", ">")
          .replace("&quot;", '"').replace("&#39;", "'"))
    return re.sub(r"\s+", " ", t).strip()


class _GzhText(HTMLParser):
    """抽取 #js_content 的正文文本。br 与块级标签落成换行，其余标签丢弃。
    用标准库而不是正则：正文里有嵌套 div，正则非贪婪会在第一个 </div> 就断。"""

    BLOCK = ("p", "div", "br", "h1", "h2", "h3", "h4", "h5", "h6",
             "li", "tr", "section", "blockquote")

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.depth = 0
        self.on = False
        self.out = []

    def handle_starttag(self, tag, attrs):
        if not self.on:
            if tag == "div" and dict(attrs).get("id") == "js_content":
                self.on = True
                self.depth = 1
            return
        # 只让 <div> 影响深度计数：正文里 <p>/<span>/<section> 不计入，
        # 否则它们只增不减，depth 永远归不了零，就会一路抓到页面末尾。
        if tag == "div":
            self.depth += 1
        if tag in self.BLOCK:
            self.out.append("\n")

    def handle_startendtag(self, tag, attrs):
        if self.on and tag in self.BLOCK:
            self.out.append("\n")

    def handle_endtag(self, tag):
        if not self.on:
            return
        if tag == "div":
            self.depth -= 1
            if self.depth <= 0:
                self.on = False
                self.depth = 0
        if tag in self.BLOCK:
            self.out.append("\n")

    def handle_data(self, data):
        if self.on:
            self.out.append(data)

    def text(self):
        t = "".join(self.out)
        t = re.sub(r"[ \t\u00a0]+", " ", t)
        t = re.sub(r"\n\s*\n(\s*\n)+", "\n\n", t)
        return "\n".join(l.strip() for l in t.split("\n")).strip()


def _js_unescape(s):
    """还原 JS 字符串里的十六进制转义（图片消息的 URL 里夹着 \\x26amp; 这种）。"""
    def _r(m):
        try:
            return chr(int(m.group(1), 16))
        except Exception:
            return m.group(0)
    s = re.sub(r'\\x([0-9a-fA-F]{2})', _r, s or "")
    s = s.replace('\\/', '/')
    return htmlmod.unescape(s)


def _gzh_picture_page(page):
    """公众号「图片消息」（appmsg_type=9 / picture_page）专用解析。

    这类文章整篇就是几张图，正文框里没有文字，图也不在 <img data-src> 上，
    而是塞在 window 里的 picture_page_info_list 这个 JS 数组里，页面上只有占位图。
    每个 item 取第一个 cdn_url —— 后面的 watermark_info.cdn_url 是水印小 logo，不是正文图。
    """
    i = page.find("picture_page_info_list")
    if i < 0:
        return []
    j = page.find("[", i)
    if j < 0:
        return []
    depth, end = 0, -1
    for k in range(j, min(len(page), j + 600000)):
        ch = page[k]
        if ch == "[":
            depth += 1
        elif ch == "]":
            depth -= 1
            if depth == 0:
                end = k + 1
                break
    if end < 0:
        return []
    block = page[j:end]

    items, depth, start = [], 0, -1
    for k, ch in enumerate(block):
        if ch == "{":
            if depth == 0:
                start = k
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0 and start >= 0:
                items.append(block[start:k + 1])
                start = -1

    out, seen = [], set()
    for it in items:
        m = re.search(r"cdn_url:\s*'([^']+)'", it)
        if not m:
            continue
        u = _js_unescape(m.group(1)).strip()
        if not u.startswith("http") or u in seen:
            continue
        seen.add(u)
        out.append({"url": u, "w": None, "h": None})
    return out


def parse_gzh(url, do_ocr=False):
    """公众号文章：服务端渲染的静态页，一次 GET 拿全，不需要登录也不需要 cookie。
    比小红书简单一个量级 —— 小红书要 xsec_token 且挂着 WAF，这里没有这些。
    图片是懒加载的，真实地址在 data-src 上，src 通常只是占位符。"""
    status, final, page = http_get(url, ua=UA_PC)
    warnings = []

    if status != 200 or not page:
        return {"ok": False, "platform": "gzh", "error": "fetch_failed",
                "message": "打开文章页失败（网络问题或链接失效）。可以把正文直接粘进「正文」框，一样能拆。"}

    if _gzh_blocked(page):
        return {"ok": False, "platform": "gzh", "error": "blocked",
                "message": "文章页返回了微信的验证页（通常是短时间抓太多次，出口 IP 被临时限制）。"
                           "歇一会儿再试；急着用就把正文粘进「正文」框，四层拆解照常出报告。"}

    p = _GzhText()
    try:
        p.feed(page)
        desc = p.text()
    except Exception:
        desc = ""

    title = _gzh_var(page, "msg_title")
    if not title:
        m = re.search(r'(?is)<h1[^>]*id="activity-name"[^>]*>(.*?)</h1>', page)
        if m:
            title = _strip_html(m.group(1))
    title = title or ""
    # 图片消息没有 activity-name / msg_title，标题只在 og:title 上
    if not title:
        m = re.search(r'property="og:title"\s+content="([^"]*)"', page)
        if m:
            title = htmlmod.unescape(m.group(1)).strip()

    author = _gzh_var(page, "nickname")
    if not author:
        m = re.search(r'(?is)<a[^>]*id="js_name"[^>]*>(.*?)</a>', page)
        if m:
            author = _strip_html(m.group(1))
    author = author or ""

    # 公众号：公众号名（来源）比作者更有辨识度，两个都取
    account = _gzh_var(page, "user_name") or ""
    m = re.search(r'var\s+user_name\s*=\s*([\'"])(.*?)\1', page, re.S)
    if m:
        account = m.group(2)

    ts = 0
    try:
        ts = int(_gzh_var(page, "ct") or 0)
    except Exception:
        ts = 0

    # 图片：懒加载真实地址在 data-src
    # 🔴 属性值里是 HTML 转义过的（&amp;wxfrom=...），不 unescape 直接请求会 400/403。
    imgs = _gzh_picture_page(page)      # 图片消息走专用解析，命中就不用再扫 <img>
    seen = set(im["url"] for im in imgs)

    def _add_img(raw_u):
        u = htmlmod.unescape((raw_u or "").strip())
        if not u.startswith("http") or u in seen:
            return
        seen.add(u)
        imgs.append({"url": u, "w": None, "h": None})

    if not imgs:
        for m in re.finditer(r'(?is)<img[^>]*data-src="([^"]+)"', page):
            _add_img(m.group(1))
    if not imgs:
        for m in re.finditer(r'(?is)<img[^>]*\ssrc="(https?://mmbiz[^"]+)"', page):
            _add_img(m.group(1))

    cover_text = ""
    ocr_note = ""
    if do_ocr and imgs:
        if ocr_mod is None or not ocr_mod.available():
            ocr_note = "服务端没装 OCR，配图里的文字需要你手抄一句。"
        else:
            lines, err = ocr_mod.ocr_url(imgs[0]["url"])
            if lines:
                cover_text = ocr_mod.join_lines(lines)[:600]
            else:
                ocr_note = "首图文字没认出来（图太花或下载失败），手抄一句就行。"

    if not desc:
        # 纯图片文章（公众号里很常见：整篇就是几张图 + 一句标题）。
        # 以前这里一律判失败，用户看到「只能抓文章不能抓图」——其实图早就抓到了，只是被丢掉了。
        # 现在把图原样返回，前端直接转进素材库：配图能下载、能当二创参考图，正文留空让人补一句。
        if imgs:
            return {
                "ok": True,
                "platform": "gzh",
                "kind": "article",
                "image_only": True,
                "coverText": cover_text,
                "ocrNote": ocr_note,
                "url": url,
                "id": _gzh_var(page, "biz") or "",
                "title": title,
                "desc": "",
                "tags": [],
                "author": author,
                "account": account,
                "stats": {},
                "images": imgs,
                "video": "",
                "comments": [],
                "publishedAt": ts,
                "warnings": ["这篇是纯图片文章，正文里没有文字。图已经抓下来了，可以直接当二创配图；"
                             "想拆解就在「正文」里补一句你打算怎么改写。"],
            }
        return {"ok": False, "platform": "gzh", "error": "empty",
                "message": "抓到了页面但没解析出正文（可能是纯图片文章或已删除）。请把正文粘进「正文」框。"}

    if len(desc) < 200:
        warnings.append("这篇文章正文偏短，四层拆解的「文案」层会不够扎实，建议再粘一点原文。")

    return {
        "ok": True,
        "platform": "gzh",
        "coverText": cover_text,
        "ocrNote": ocr_note,
        "url": url,
        "id": _gzh_var(page, "biz") or "",
        "kind": "article",
        "title": title,
        "desc": desc,
        "tags": [],
        "author": author,
        "account": account,
        "stats": {},
        "images": imgs,
        "video": "",
        "comments": [],
        "publishedAt": ts,
        "warnings": warnings,
    }


# ---------------------------------------------------------------- 分发

def fetch_any(raw_input, do_ocr=False):
    url = pick_url(raw_input)
    if not url:
        return {"ok": False, "error": "no_url",
                "message": "这段内容里没找到链接。请粘贴作品链接或 App 的分享口令。"}
    plat = detect_platform(url)

    # 2026-10-29：公众号通道上线。它比小红书简单得多（静态 SSR，无需登录），
    # 之前把它和小红书一起"劝退"是错误的保守 —— 用户工坊早就跑通了。
    if plat == "gzh":
        cached = cache_get("gzh|" + url)
        if cached:
            out = dict(cached)
            out["cached"] = True
            return out
        res = parse_gzh(url, do_ocr)
        if res.get("ok"):
            cache_put("gzh|" + url, res)
        return res

    if plat != "xhs":
        tips = {
            "toutiao": "头条请直接复制全文粘到「正文」框。",
            "douyin": "抖音有验证码拦截，抓不到。请把文案粘进「正文」框。",
            "bili": "B 站暂不支持，请把文案粘进「正文」框。",
            "weibo": "微博暂不支持，请把文案粘进「正文」框。",
            "sph": "视频号没有公开网页，抓不到。请把文案粘进「正文」框。",
        }
        return {"ok": False, "platform": plat, "error": "unsupported",
                "message": "现在支持小红书图文和公众号文章链接。" + tips.get(plat, "请把正文粘进来。")}

    # 短链每次都可能是新分享，不能按 URL 缓存
    cached = None if "xhslink.com" in url else cache_get("xhs|" + url)
    if cached:
        out = dict(cached)
        out["cached"] = True
        return out

    res = parse_xhs(url, do_ocr)

    if res.get("ok") and "xhslink.com" not in url:
        cache_put("xhs|" + url, res)
    return res


# ---------------------------------------------------------------- HTTP 服务

class Handler(BaseHTTPRequestHandler):
    server_version = "KBFetch/1.0"

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", ALLOW_ORIGIN)
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Max-Age", "86400")

    def _json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self._cors()
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self):
        if self.path.startswith("/health"):
            self._json({"ok": True, "service": "kbfetch", "ts": int(time.time())})
            return
        if self.path.startswith("/fetch"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            ocr_flag = (q.get("ocr") or [""])[0] in ("1", "true", "yes")
            self._handle((q.get("url") or [""])[0], ocr_flag)
            return
        self._json({"ok": False, "error": "not_found"}, 404)

    def do_POST(self):
        is_fetch = self.path.startswith("/fetch")
        is_ocr = self.path.startswith("/ocr")
        if not (is_fetch or is_ocr):
            self._json({"ok": False, "error": "not_found"}, 404)
            return
        try:
            n = int(self.headers.get("Content-Length") or 0)
            payload = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
        except Exception:
            self._json({"ok": False, "error": "bad_json"}, 400)
            return
        if is_ocr:
            self._handle_ocr(payload.get("urls") or [])
            return
        self._handle(payload.get("url") or payload.get("text") or "", bool(payload.get("ocr")))

    def _handle_ocr(self, urls):
        """配图按需识别：一次最多 10 张，边识别边回，前端能逐张显示。"""
        if not isinstance(urls, list):
            self._json({"ok": False, "error": "bad_urls"}, 400)
            return
        urls = [u for u in urls if isinstance(u, str) and u.startswith("http")][:10]
        if not urls:
            self._json({"ok": False, "error": "no_urls"}, 400)
            return
        if ocr_mod is None or not ocr_mod.available():
            self._json({"ok": False, "error": "ocr_unavailable",
                        "message": "服务端没装 OCR 组件，这步用不了，手抄关键句即可。"})
            return
        out = []
        for u in urls:
            lines, err = ocr_mod.ocr_url(u)
            out.append({"url": u, "text": ocr_mod.join_lines(lines)[:800], "err": err})
        self._json({"ok": True, "items": out})

    def _handle(self, raw, do_ocr=False):
        try:
            t0 = time.time()
            res = fetch_any(raw, do_ocr)
            res["elapsed"] = round(time.time() - t0, 2)
            self._json(res)
        except Exception:
            tb = traceback.format_exc()[-1200:]
            self._json({"ok": False, "error": "exception", "message": tb}, 500)

    def log_message(self, fmt, *args):
        sys.stderr.write("[%s] %s\n" % (time.strftime("%H:%M:%S"), fmt % args))


def main():
    port = int(os.environ.get("PORT") or 8901)
    srv = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    sys.stderr.write("kbfetch listening on %d\n" % port)
    srv.serve_forever()


if __name__ == "__main__":
    main()
