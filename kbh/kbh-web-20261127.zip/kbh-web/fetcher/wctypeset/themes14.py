# -*- coding: utf-8 -*-
"""17 套公众号主题排版引擎（从 md_to_gzh.py 移植为服务端纯函数版）。

与源文件（`公众号/待发布/md_to_gzh.py`）的差异，逐条对应移植清单：

1. THEMES 14 套色值原样搬运，一个字符未改；另从 `胜元公众号排版/references/`
   增补 3 套（moyu-ticket / graphite-minimal / zen-whitespace），色值取自各自
   主题文件的「设计变量速查表」，非凭记忆填写。
2. **删除模块级全局 T 与 set_theme()**。所有组件函数改为首参 `t: dict`。
   原写法在 FastAPI 下是并发 BUG：两个并发请求会互相覆盖全局 T，导致响应串色。
3. build() → render()：吃 markdown 字符串、返回 HTML 字符串，不读写文件；
   未知 theme_key 回落 "green" 而非 raise SystemExit。
4. byline 参数化，为空则整行不渲染。
5. image_embed 吃 src（URL / data URI），不再读本地文件转 base64。
6. cover_src 可选，为空跳过封面。
7. 删除 __main__ 批处理段（含硬编码路径）。

移植过程中另外修掉了源文件两个潜在缺陷（详见 to_fw / inline 注释）：
- to_fw() 半角逗号映射表键错位，中文后接半角逗号会 KeyError 崩溃；
- inline() 引号下划线分支因引号已被转全角而永远不触发（ul 设计变量全场死代码）。

输出保持源文件的合规特性：inline-style、中文节点 <span leaf=""> 包裹、无 class/id/script。
"""

import re
import html

BASE_FONT = (
    "-apple-system,BlinkMacSystemFont,'PingFang SC',"
    "'Hiragino Sans GB','Microsoft YaHei',sans-serif"
)

# ---------- 主题库（设计变量速查）----------
# accent      强调色（byline/章节号/重点/列表点/CTA主色）
# num         章节大号数字色
# title       章节中文标题色
# body        正文字色
# part        PART 英文标签色
# en          英文副标色
# divider     分隔线/竖线色
# bg          页面底色
# card        卡片/引用底
# border      卡片边框
# ul          关键词下划线色
# cta_bg / cta_border  CTA 转发图标盒
# font        主题专属字体（追加到 BASE_FONT）
# radius      主圆角
# shadow      cover 阴影 rgba（hard_shadow 主题填实色 hex，见下）
#
# 以上 16 个是每套主题都必须声明的设计变量。下面两个是**可选**扩展键，
# 只有骨架长得跟经典版不一样的主题才声明；老 14 套一个都不带，
# 全部组件用 t.get(...) 读取 —— 老主题的渲染结果因此逐字节不变。
# deco        章节/封面/引用的骨架变体："ticket" | "watermark" | "zen"，缺省=经典版
# hard_shadow True 时卡片用无虚化实心偏移块（票据风硬阴影），缺省=高斯柔光
THEMES: dict[str, dict] = {
    "green": dict(
        accent="#059669", num="#059669", title="#111827", body="#374151",
        part="#6B7280", en="#9CA3AF", divider="#E5E7EB", bg="#ffffff",
        card="#F9FAFB", border="#D1D5DB", ul="#A7F3D0", cta_bg="#ECFDF5", cta_border="#A7F3D0",
        font="", radius=16, shadow="rgba(5,150,105,0.12)",
        icon_footer=True,  # 对齐品牌绿：D 形态三连图标盒 footer（图上文下）
        # 批次15·切片2（2026-10-09）：接「magazine」专属骨架——绿色杂志风标签化章节，
        # 根治「与经典档撞脸」。skill theme-brand-green「标签化章节+封面快讯」。
        deco="magazine"),
    # 🔧 FIX(2026-08-25): 补「胜元大地」主题（公众号主题排版 theme-index.md 已注册，
    #   ai-writer 此前缺漏 → 写作台少一套暖调编辑风备选）。
    #   与品牌绿同骨架同 icon_footer 形态，只换调色：雾松绿 #3C6E6E + 暖陶 underline #C0553A。
    #   暖陶暖调备选 = 大地色系，给「更暖更有人味」的内容品类。
    "shengyuan-earth": dict(
        accent="#3C6E6E", num="#3C6E6E", title="#2B2A27", body="#4A4138",
        part="#8a7d6a", en="#8a7d6a", divider="#E8E2D6", bg="#FDFBF7",
        card="#F7F4EE", border="#D8CDB8", ul="#C0553A", cta_bg="#F7F2EC", cta_border="#C0553A",
        # 🔧 2026-09-09 批19：原「与品牌绿同骨架同 icon_footer 形态，只换调色」——
        #   去色后渲染结构签名与 green 完全相同，用户切换主题看不出任何区别（实测撞车）。
        #   三处改形态：① 加衬线（定位「暖调/人味长读」本就更该衬线，与 green 的无衬线杂志感区分）
        #   ② radius 16→12（green 保持 16）③ 去掉 icon_footer（green 保留三连图标盒 footer）。
        #   改完去色签名独立，与 green 一眼可分。
        font=",'Songti SC','Noto Serif SC',Georgia,serif", radius=12,
        shadow="rgba(60,110,110,0.12)", deco="editorial"),  # 暖调编辑风=内刊骨架换色
    "red-white": dict(
        accent="#DC2626", num="#DC2626", title="#1C1917", body="#374151",
        part="#9CA3AF", en="#9CA3AF", divider="#E5E7EB", bg="#ffffff",
        card="#FEF2F2", border="#FEE2E2", ul="#FECACA", cta_bg="#FEE2E2", cta_border="#FECACA",
        # 表态风：利落直角（radius=4）+ 无衬线，和 morandi/stripe/ocean 拉开形状差异
        font="", radius=4, shadow="rgba(220,38,38,0.12)"),
    "olive": dict(
        accent="#ed7b2f", num="#23251d", title="#23251d", body="#4d4f46",
        part="#9ea096", en="#9ea096", divider="#bfc1b7", bg="#fdfdf8",
        card="#eeefe9", border="#bfc1b7", ul="#ed7b2f", cta_bg="#eeefe9", cta_border="#bfc1b7",
        font=",'Songti SC','Noto Serif SC',Georgia,serif", radius=12, shadow="rgba(30,31,35,0.10)",
        deco="editorial"),
    "guofeng-ink": dict(
        accent="#C0392B", num="#1a1a1a", title="#1a1a1a", body="#2b2b2b",
        part="#8a7d6a", en="#8a7d6a", divider="#d8cdb8", bg="#F5F0E6",
        card="#efe9da", border="#d8cdb8", ul="#C0392B", cta_bg="#f0e6d2", cta_border="#C0392B",
        font=",'KaiTi','STKaiti','楷体'", radius=10, shadow="rgba(138,125,106,0.15)",
        # 批次15·切片2：接「ink」专属骨架——宣纸米底+楷体标题+朱砂竖条（skill theme-guofeng-ink）。
        deco="ink"),
    "mint-handbook": dict(
        accent="#2FB489", num="#2FB489", title="#2d4a3e", body="#3a5a4d",
        part="#9cc4b3", en="#9cc4b3", divider="#cfe9dd", bg="#EAF6F0",
        card="#ffffff", border="#cfe9dd", ul="#2FB489", cta_bg="#d8f0e6", cta_border="#2FB489",
        font="", radius=20, shadow="rgba(47,180,137,0.15)", deco="magazine"),  # 薄荷胶囊=标签化章节
    "morandi": dict(
        accent="#8C8A84", num="#6b6a64", title="#4a4a45", body="#5e5d57",
        part="#a8a6a0", en="#a8a6a0", divider="#ddd9d2", bg="#F2F0EC",
        card="#eae7e1", border="#ddd9d2", ul="#8C8A84", cta_bg="#e3e0d9", cta_border="#8C8A84",
        # 生活美学：衬线正文 + 柔和圆角（radius=14），与无衬线直角的 red-white 区分
        font=",'Songti SC','Noto Serif SC',Georgia,serif", radius=14, shadow="rgba(108,106,100,0.12)", deco="watermark"),  # 超大雾灰水印（track 特征同名）
    "stripe-silicon": dict(
        accent="#635BFF", num="#635BFF", title="#0A2540", body="#425466",
        part="#8898AA", en="#8898AA", divider="#E6E9ED", bg="#ffffff",
        card="#F6F9FC", border="#E6E9ED", ul="#635BFF", cta_bg="#F6F9FC", cta_border="#635BFF",
        # 科技/SaaS：紧凑小圆角（radius=8）+ 无衬线，和 ocean 的舒展圆角区分
        font="", radius=8, shadow="rgba(99,91,255,0.12)", deco="bar"),  # 左紫蓝粗条+PART（track 特征）
    "claude-oat": dict(
        accent="#B08968", num="#3D3A36", title="#2B2A27", body="#454138",
        part="#9C958A", en="#9C958A", divider="#E8E2D6", bg="#F7F5F0",
        card="#FBF9F4", border="#E8E2D6", ul="#B08968", cta_bg="#FBF9F4", cta_border="#B08968",
        font=",'Songti SC','Noto Serif SC',Georgia,serif", radius=10, shadow="rgba(176,137,104,0.14)",
        # 批次15·切片2：接「oat」专属骨架——衬线标题+暖陶左竖条（skill theme-claude-oat）。
        deco="oat"),
    "nyt-editorial": dict(
        accent="#121212", num="#111111", title="#121212", body="#333333",
        part="#767676", en="#767676", divider="#E0E0E0", bg="#ffffff",
        card="#F7F7F7", border="#E0E0E0", ul="#111111", cta_bg="#F7F7F7", cta_border="#111111",
        font=",'Songti SC','Noto Serif SC',Georgia,serif", radius=4, shadow="rgba(0,0,0,0.08)", deco="underline"),  # 衬线+墨黑下划线章节（track 特征）
    "bauhaus-bold": dict(
        accent="#E63946", num="#1D3557", title="#1D3557", body="#222222",
        part="#457B9D", en="#457B9D", divider="#1D3557", bg="#ffffff",
        card="#FFF8E1", border="#1D3557", ul="#E63946", cta_bg="#FFF8E1", cta_border="#E63946",
        font="", radius=2, shadow="rgba(230,57,70,0.12)", deco="bauhaus"),  # 三色横条+粗黑边
    "warm-sun": dict(
        accent="#EA580C", num="#EA580C", title="#7C2D12", body="#4A3528",
        part="#C2410C", en="#C2410C", divider="#FED7AA", bg="#FFF7ED",
        card="#FFF1E0", border="#FED7AA", ul="#EA580C", cta_bg="#FFF1E0", cta_border="#EA580C",
        font="", radius=16, shadow="rgba(234,88,12,0.12)", deco="magazine"),  # 橙色胶囊数字=标签化章节
    "ocean-deep": dict(
        accent="#0E7490", num="#0E7490", title="#083344", body="#334155",
        part="#64748B", en="#64748B", divider="#CFE8F0", bg="#EAF6FB",
        card="#F4FBFE", border="#CFE8F0", ul="#0E7490", cta_bg="#F4FBFE", cta_border="#0E7490",
        # 资讯/职场：舒展大圆角（radius=18）+ 无衬线，和 stripe 的紧凑小圆角区分
        font="", radius=18, shadow="rgba(14,116,144,0.12)",
        # 批次15·切片2：接「badge」专属骨架——深青方角徽章章节（skill theme-ocean-deep）。
        deco="badge"),
    # ---- 以下 3 套增补自 skills/胜元公众号排版/references/ ----
    # theme-moyu-ticket.md：米黄纸底 + 黑实边框 + 硬阴影（无虚化）+ 绿虚线撕票线。
    # shadow 在本主题是**实色**而非 rgba —— 硬阴影不能带 alpha，否则叠出灰边。
    # radius=0：票据是硬边裁切的，任何圆角都会破坏「凭证」隐喻。
    "moyu-ticket": dict(
        accent="#07C160", num="#07C160", title="#1a1a1a", body="#555555",
        part="#999999", en="#888888", divider="#A7F3D0", bg="#fffef8",
        card="#F0FDF4", border="#1a1a1a", ul="#A7F3D0", cta_bg="#F0FDF4", cta_border="#07C160",
        font="", radius=0, shadow="#1a1a1a",
        deco="ticket", hard_shadow=True),
    # theme-graphite-minimal.md：石墨灰 + 纯白 + 1px 几何细线 + 超大留白。
    # num 故意取极浅的 #E4E4E7 —— 它在本主题只出现在「超大水印编号」位置，
    # 是背景层视觉锚而非可读文字，用正文灰会喧宾夺主。
    "graphite-minimal": dict(
        accent="#52525B", num="#E4E4E7", title="#27272A", body="#52525B",
        part="#A1A1AA", en="#A1A1AA", divider="#E4E4E7", bg="#FFFFFF",
        card="#FAFAFA", border="#E4E4E7", ul="#52525B", cta_bg="#F4F4F5", cta_border="#52525B",
        font="", radius=0, shadow="rgba(82,82,91,0.08)",
        deco="watermark"),
    # theme-zen-whitespace.md：雾绿点缀 + 纯白 + 衬线大字 + 超大留白。
    # ul 用低饱和墨绿 #B5C8BC 而非 accent —— 原主题明确区分「强调色」与
    # 「关键词下划线色」，下划线压一档饱和度才不打断阅读节奏。
    "zen-whitespace": dict(
        accent="#4A5D52", num="#4A5D52", title="#2B2B2B", body="#525252",
        part="#A3A3A3", en="#A3A3A3", divider="#E8E8E8", bg="#FFFFFF",
        card="#EEF3F0", border="#E8E8E8", ul="#B5C8BC", cta_bg="#EEF3F0", cta_border="#B5C8BC",
        font=",'Noto Serif SC',Georgia,'Times New Roman',serif", radius=2,
        shadow="rgba(74,93,82,0.08)",
        ul_px=1.5, ul_w=500,  # #9 对齐 skill theme-index：zen 下划线 1.5px/500 压一档
        deco="zen"),
    # theme-stripe-silicon 同源增补（2026-08-05 自工作区 md_to_gzh.py news-pop 移植）：
    # 资讯爆款风：白底 + 橙 #FF6B00 强调，看点标签 + 🔥划重点黑引用 + ▶ 列表 + 实色 CTA。
    "news-pop": dict(
        accent="#FF6B00", num="#FF6B00", title="#111111", body="#333333",
        part="#FFB380", en="#999999", divider="#FFD9B8", bg="#ffffff",
        card="#FFF4EC", border="#FFE0CC", ul="#FF6B00", cta_bg="#FF6B00", cta_border="#FF6B00",
        font="", radius=4, shadow="rgba(255,107,0,0.12)",
        deco="pop"),
    # 开源项目介绍（2026-09-27 新增）：代码友好清爽蓝，仿 GitHub README/docs 观感。
    # 白底 + GitHub 蓝 #1F6FEB + 灰边框 #D0D7DE + 浅灰卡 #F6F8FA；与 stripe 紫 / ocean 青 拉开色相。
    # 不走 deco 变体，用经典骨架（render 全量 t.get 读取，逐字节安全）。
    # 真正杀手锏不是皮，是配套「项目介绍」写作赛道（track_playbook.json）强制在文末带仓库地址，
    # 打孤狼智写「生成项目介绍却不给仓库地址」的短板。
    "project-intro": dict(
        accent="#1F6FEB", num="#1F6FEB", title="#0D1117", body="#24292F",
        part="#57606A", en="#57606A", divider="#D0D7DE", bg="#FFFFFF",
        card="#F6F8FA", border="#D0D7DE", ul="#54AEFF", cta_bg="#DDF4FF", cta_border="#54AEFF",
        font="", radius=10, shadow="rgba(31,111,235,0.10)"),
}

DEFAULT_THEME = "green"

# 展示元数据：中文名 / 适配赛道 / 是否暗底。
# accent 不在此重复声明，一律从 THEMES 取，避免两处色值漂移。
# 列表顺序即前端展示顺序：亮色在前，暗底（dark=True）压到最后单独分组。
#
# 【track 字段的书写标准】ai-writer 面向全体公众号作者，不是某个账号的私人工具。
# track 唯一的作用是让一个**素不相识的作者**在 0.5 秒内判断「这套是不是我这类号该用的」，
# 所以只能写**公认的内容品类**，不能写自家业务黑话。
#   ✗ 反例：「漫剧IP」「AI工具实测」「实验暗色」
#           —— 前两个是某账号的栏目名，第三个描述的是视觉而不是内容品类，
#              而暗底信息前端已由 dark 字段单独承载，写在 track 里是浪费唯一的判断位。
#   ✓ 正例：「亲子/情感/生活」「科技/产品/SaaS」「影视/娱乐/夜读」
# 一套皮往往能覆盖多个品类，宁可多列不要写窄（多列用「/」分隔，最多 3 个，
# 超过 3 个卡片会换行撑破布局）。
THEME_META: dict[str, dict] = {
    "green":          {"name_cn": "品牌绿",      "track": "教程/干货/工具测评 · 绿色杂志风·封面快讯+标签化章节+行内高亮", "dark": False},
    "shengyuan-earth":{"name_cn": "大地暖调",    "track": "暖调备选/生活方式/人味长读 · 暖调编辑风·同骨架换大地色暖调", "dark": False},  # 2026-08-25 补
    "red-white":      {"name_cn": "红白表态",    "track": "观点/评论/热点表态 · 经典编辑风·编号章节+引言卡+签名区", "dark": False},
    # 原「深度评测」把一套暖调编辑风锁死在评测一个品类上，实际它更常见于
    # 生活方式与读书长文；放宽到三个品类。
    "olive":          {"name_cn": "橄榄手记",    "track": "生活方式/读书/深度长文 · 编辑部内刊·34组件全覆盖", "dark": False},
    "guofeng-ink":    {"name_cn": "国风墨色",    "track": "历史/人文/国学传统 · 宣纸米底+楷体标题+朱砂竖条", "dark": False},
    "mint-handbook":  {"name_cn": "薄荷手帐",    "track": "健康养生/心理成长 · 薄荷胶囊数字+20px大圆角", "dark": False},
    "morandi":        {"name_cn": "莫兰迪",      "track": "家居/穿搭/生活美学 · 超大雾灰水印+燕麦灰底", "dark": False},
    "stripe-silicon": {"name_cn": "Stripe 硅谷", "track": "科技/产品/SaaS · 左紫蓝粗条+PART标签章节", "dark": False},
    "claude-oat":     {"name_cn": "Claude 燕麦", "track": "认知思考/读书长文 · 燕麦米底+衬线标题+暖陶竖条", "dark": False},
    "nyt-editorial":  {"name_cn": "NYT 纽时",    "track": "财经/商业/行业分析 · 衬线宋体+黑色下划线章节", "dark": False},
    "bauhaus-bold":   {"name_cn": "包豪斯",      "track": "热点议题/观点交锋 · 红黄蓝三色横条+粗黑边卡片", "dark": False},
    "warm-sun":       {"name_cn": "暖阳橙",      "track": "亲子/情感/生活 · 奶油橙底+橙色胶囊数字", "dark": False},
    "ocean-deep":     {"name_cn": "深海蓝",      "track": "资讯快报/职场干货 · 浅青蓝底+深青方角徽章", "dark": False},
    "moyu-ticket":    {"name_cn": "票据风",      "track": "测评评测/榜单/好物 · 票据隐喻·星级+编号+撕票线", "dark": False},
    "graphite-minimal": {"name_cn": "石墨极简",  "track": "建筑/摄影/设计 · 超大水印编号+几何细线", "dark": False},
    "zen-whitespace": {"name_cn": "留白禅意",    "track": "疗愈/文化/慢生活 · 细线目录+衬线大字留白", "dark": False},
    # 2026-10-06 批1（导演第10条）：暗底主题 magazine-noir / cyberpunk 已下线——
    # 微信正文深色底在手机端观感差、转载/白名单场景易翻车，审查后不再提供。
    "news-pop":       {"name_cn": "资讯爆款",    "track": "热点资讯/科技快讯 · 白底橙强调+看点标签+黑引用划重点+实色CTA", "dark": False},
    "project-intro":  {"name_cn": "开源项目",    "track": "开源工具/技术项目/开发者向 · 代码友好·仓库地址盒+特性卡+清爽蓝", "dark": False},
}


def list_themes() -> list[dict]:
    """供前端主题面板渲染：[{key, name_cn, accent, track, dark}, ...]

    以 THEME_META 的声明顺序输出；若 THEMES 里存在未登记元数据的主题，
    仍会追加输出（用 key 兜底中文名），保证新增主题不会从 UI 里静默消失。
    """
    out: list[dict] = []
    for key, meta in THEME_META.items():
        if key not in THEMES:
            continue
        out.append({
            "key": key,
            "name_cn": meta["name_cn"],
            "accent": THEMES[key]["accent"],
            "track": meta["track"],
            "dark": meta["dark"],
        })
    for key in THEMES:
        if key not in THEME_META:
            out.append({
                "key": key,
                "name_cn": key,
                "accent": THEMES[key]["accent"],
                "track": "未分类",
                "dark": False,
            })
    return out


def get_theme(theme_key: str) -> dict:
    """未知 key 回落默认主题（服务端不抛异常）。"""
    return THEMES.get(theme_key) or THEMES[DEFAULT_THEME]


# ---------- 文本工具 ----------

def esc(t: str) -> str:
    # quote=True 同时转义双/单引号——本函数既用于文本节点也用于属性位置
    # （cover_image/image_embed 的 src、alt），不转义引号会导致属性注入 XSS。
    return html.escape(t, quote=True)


def leaf(t: str) -> str:
    return f'<span leaf="">{esc(t)}</span>'


# 半角 → 全角映射。
# 源文件此表首键误写为 U+201A（‚），导致「中文 + 半角逗号」触发 KeyError 崩溃；
# 命令行场景下手写稿都用全角逗号所以从未暴露，但 AI 生成正文半角逗号极常见，
# 直接接进 HTTP 接口会 500。此处修正为 ASCII 逗号，并把冒号并入字符类
# （源正则把冒号写在捕获组外的 `:?`，匹配到会被整体吃掉 —— 是在静默删字符）。
_FW_MAP = {",": "，", ";": "；", "!": "！", "?": "？", ":": "："}
_FW_RE = re.compile(r"([\u4e00-\u9fff])\s*([,;!?:])")

# 受保护片段：行内代码（反引号）、URL 与 Markdown 链接 `[text](url)`。
# 这些片段里的半角括号/引号/冒号是代码与链接语义，全角转换会破坏它们
# （print("hi") → print（hi）、URL 括号被转、[text](url) 的 () 被转成全角后
# _LINK_RE 匹配不上），所以转换前先抽出用占位符替身，转换后还原。
_PROTECT_RE = re.compile(r"`[^`]*`|https?://[^\s]+|\[[^\]\n]*\]\([^)\n]*\)")


# Markdown 链接 `[text](url)`：负向后顾排除图片 `![...](...)`（图片在块级已被
# _IMG_RE 整行捕获）。链接的括号受 _PROTECT_RE 保护，to_fw 不会动它。
_LINK_RE = re.compile(r"(?<!!)\[[^\]\n]*\]\([^)\n]*\)")


def _is_external(url: str) -> bool:
    """外链判定：http(s):// 且域名非 mp.weixin.qq.com 视为外链（需降级脚注）。
    其余（相对路径、mp.weixin 内链、无协议文本）一律按内链处理。"""
    u = (url or "").strip()
    if not (u.startswith("http://") or u.startswith("https://")):
        return False
    rest = u.split("://", 1)[1]
    host = rest.split("/", 1)[0].lower() if "/" in rest else rest.lower()
    return host != "mp.weixin.qq.com"


def to_fw(t: str) -> str:
    """中文语境下的半角标点转全角（公众号 warning 清零）。

    行内代码与 URL 受保护——跳过全角转换，避免破坏代码/链接内容。
    """
    if not t:
        return t
    stash: list[str] = []

    def _stash(m):
        stash.append(m.group(0))
        return f"\x00{len(stash) - 1}\x00"

    t = _PROTECT_RE.sub(_stash, t)
    t = _FW_RE.sub(lambda m: m.group(1) + _FW_MAP[m.group(2)], t)
    t = re.sub(r'"([^"]*)"', r'“\1”', t)
    t = t.replace("(", "（").replace(")", "）")
    t = t.replace("...", "…").replace("… …", "…")

    def _restore(m):
        return stash[int(m.group(1))]

    return re.sub(r"\x00(\d+)\x00", _restore, t)


def font_stack(t: dict) -> str:
    return BASE_FONT + t["font"]


# to_fw 已把成对半角引号转成 “ ”，所以这里必须按全角引号切分。
# 源文件此处仍用半角 " 切分，分支永远不成立 —— 「引号加主题色下划线」这个
# 设计从未生效过，14 套主题里的 ul 变量因此全是死变量。改用全角后恢复。
_QUOTE_SPLIT_RE = re.compile(r'(“[^”]*”)')
_BOLD_SPLIT_RE = re.compile(r'(\*\*.+?\*\*)')


def _link_label(ltext: str) -> str:
    """链接显示文本：剥掉全包裹的 **（`**[OpenAI](url)**` → OpenAI），
    避免 References 与正文出现字面 **。中部加粗 `[a **b** c](url)` 不做
    二次 inline（递归会产生非法嵌套 <a>，公众号粘贴丢标签）。"""
    if len(ltext) >= 4 and ltext.startswith("**") and ltext.endswith("**"):
        ltext = ltext[2:-2]
    return esc(to_fw(ltext))


def inline(t: dict, text: str, fn_buf: list | None = None) -> str:
    """批10b·需求3 行内语法总入口：
    ==高亮==（浅底高亮框）/ ++下划线++（主题 ul 色下划线）/ ~~删除线~~（旧词）。
    三层剥离后交 _inline_core（加粗/行内代码/引号下划线/链接，原逻辑不动）。
    """
    text = to_fw(text)
    out = []
    for hl in re.split(r"(==[^=\n]{1,80}==)", text):
        if len(hl) >= 4 and hl.startswith("==") and hl.endswith("=="):
            out.append(f'<span style="background:{t["cta_bg"]};color:{t["title"]};'
                       f'padding:0 4px;border-radius:3px;font-weight:600;">'
                       f'{_inline_core(t, hl[2:-2], fn_buf)}</span>')
            continue
        for up in re.split(r"(\+\+[^+\n]{1,80}\+\+)", hl):
            if len(up) >= 4 and up.startswith("++") and up.endswith("++"):
                # #9 下划线对齐 skill theme-index 权威表：主题可选 ul_px/ul_w 覆盖
                # 默认 2px/600；zen-whitespace 用 1.5px/500（skill 明示其下划线压一档）。
                out.append(f'<span style="border-bottom:{t.get("ul_px", 2)}px solid {t["ul"]};font-weight:{t.get("ul_w", 600)};">'
                           f'{_inline_core(t, up[2:-2], fn_buf)}</span>')
                continue
            for dp in re.split(r"(~~[^~\n]{1,80}~~)", up):
                if len(dp) >= 4 and dp.startswith("~~") and dp.endswith("~~"):
                    out.append(f'<span style="text-decoration:line-through;color:{t["en"]};">'
                               f'{_inline_core(t, dp[2:-2], fn_buf)}</span>')
                    continue
                out.append(_inline_marks(t, dp, fn_buf))
    return "".join(out)


def _inline_marks(t: dict, text: str, fn_buf: list | None = None) -> str:
    """1.0.80 新增 3 种行内强调，补齐 skill 9 种行内样式的缺口。

    · `$$文字$$` → 红色下划线（对比 / 否定 / 需要注意，对应 skill 6f）
    · `%%文字%%` → 荧光笔（底部半高亮带，对应 skill 6d；微信禁渐变，用浅底+粗下划线近似）
    · `@@文字@@` → 主题主色加粗（核心概念 / 结论，对应 skill 6a）

    全部只落在微信安全子集内（无渐变 / 无 box-shadow / 无 flex）。
    """
    out = []
    for seg in re.split(r"(\$\$[^$\n]{1,80}\$\$)", text):
        if len(seg) >= 5 and seg.startswith("$$") and seg.endswith("$$"):
            out.append(f'<span style="border-bottom:2px solid #DC2626;font-weight:600;">'
                       f'{_inline_core(t, seg[2:-2], fn_buf)}</span>')
            continue
        for fz in re.split(r"(%%[^%\n]{1,80}%%)", seg):
            if len(fz) >= 5 and fz.startswith("%%") and fz.endswith("%%"):
                out.append(f'<span style="background:{t["cta_bg"]};'
                           f'border-bottom:3px solid {t["ul"]};padding:0 2px;">'
                           f'{_inline_core(t, fz[2:-2], fn_buf)}</span>')
                continue
            for ac in re.split(r"(@@[^@\n]{1,80}@@)", fz):
                if len(ac) >= 5 and ac.startswith("@@") and ac.endswith("@@"):
                    out.append(f'<strong style="color:{t["accent"]};">'
                               f'{_inline_core(t, ac[2:-2], fn_buf)}</strong>')
                    continue
                out.append(_inline_core(t, ac, fn_buf))
    return "".join(out)


def _inline_core(t: dict, text: str, fn_buf: list | None = None) -> str:
    """处理 **加粗**（主题色）、`行内代码`（等宽卡片）、"引号"（主题色下划线）、
    `[text](url)` 链接（外链降级脚注 / 内链保留 <a>），其余普通 leaf。
    行内代码在 to_fw 之后切分，确保代码内容不被全角转换破坏。
    fn_buf 传入时外链会收集进脚注 buffer（render 局部新建，并发安全）；
    为 None 则外链只显示文本不输出 [N]。"""
    out = []
    # 先按行内代码 `` `code` `` 切分；命中片段走 code_inline（不二次 to_fw）
    for seg in re.split(r"(`[^`]+`)", text):
        if len(seg) >= 2 and seg.startswith("`") and seg.endswith("`"):
            out.append(code_inline(t, seg[1:-1]))
            continue
        # 非代码段：按链接切分，命中片段做链接降级/保留
        for lseg in re.split(rf"({_LINK_RE.pattern})", seg):
            if lseg and lseg.startswith("[") and "](http" in lseg:
                mm = re.match(r"\[([^\]\n]*)\]\(([^)\n]*)\)", lseg)
                if mm:
                    ltext, lurl = mm.group(1), mm.group(2).strip()
                    label = _link_label(ltext)
                    if _is_external(lurl):
                        if fn_buf is not None:
                            fn_buf.append((label, lurl))
                            out.append(
                                f'<span leaf="">{label}</span>'
                                f'<sup style="color:{t["en"]};font-size:11px;">'
                                f'[{len(fn_buf)}]</sup>'
                            )
                        else:
                            out.append(f'<span leaf="">{label}</span>')
                    else:
                        out.append(
                            f'<a href="{esc(lurl)}" '
                            f'style="color:{t["accent"]};text-decoration:underline;">'
                            f'<span leaf="">{label}</span></a>'
                        )
                    continue
            for p in _BOLD_SPLIT_RE.split(lseg):
                if len(p) >= 4 and p.startswith("**") and p.endswith("**"):
                    inner = p[2:-2]
                    # 2026-10-20 工单⑩：加粗形态随主题走（实色/底纹胶囊/黑底线/纸签底…）
                    out.append(
                        f'<strong style="{_strong_css(t)}">'
                        f'<span leaf="">{esc(to_fw(inner))}</span></strong>'
                    )
                else:
                    for qp in _QUOTE_SPLIT_RE.split(p):
                        if qp.startswith("“") and qp.endswith("”") and len(qp) >= 2:
                            inner = qp[1:-1]
                            out.append(
                                f'<span style="border-bottom:{t.get("ul_px", 2)}px solid {t["ul"]};font-weight:{t.get("ul_w", 600)};">'
                                f'<span leaf="">{esc(inner)}</span></span>'
                            )
                        elif qp.strip():
                            out.append(leaf(qp))
    return "".join(out)


# ---------- 组件 ----------

# ⚠️ 弃用（2026-08-05）：微信安全子集铁律禁止投影（粘贴即剥落），
# 所有调用点已改为实色 border。本函数保留仅为兼容外部 import，勿再调用。
def shadow_css(t: dict, soft: str = "0 4px 16px", hard: str = "4px 4px 0") -> str:
    """卡片投影偏移值（已弃用，仅兼容外部 import）。

    hard_shadow 主题（票据风）要的是**无虚化的实心偏移块**，视觉上像一张纸
    垫在下面；普通主题要的是高斯柔光。两者共用 t["shadow"] 一个色位，
    区别只在有没有 blur 半径，所以在这里收口，调用方不必各自 if。
    """
    return f'{hard} {t["shadow"]}' if t.get("hard_shadow") else f'{soft} {t["shadow"]}'


def star_rating(t: dict, filled: int = 5, total: int = 5, color: str = "") -> str:
    """星级评分（票据风签名组件）。

    实星取 color（缺省 accent），空星取 divider —— 两个色位都来自主题字典，
    换主题即换色，不存在硬编码。放在绿色标题条上时调用方传 color=t["bg"]，
    避免绿字压绿底。
    """
    filled = max(0, min(total, int(filled)))
    c = color or t["accent"]
    out = (f'<span style="font-size:11px;letter-spacing:2px;color:{c};">'
           f'<span leaf="">{"★" * filled}</span></span>')
    if filled < total:
        out += (f'<span style="font-size:11px;letter-spacing:2px;color:{t["divider"]};">'
                f'<span leaf="">{"☆" * (total - filled)}</span></span>')
    return out


def tear_line(t: dict) -> str:
    """撕票虚线（票据风签名组件）：两段主题色虚线夹一个剪刀标记。

    虚线段是纯装饰空元素，按公众号铁律必须塞 <span leaf=""><br></span> 占位，
    否则微信粘贴时会把整个 section 连同 border 一起剥掉。
    """
    seg = (f'<section style="display:inline-block;vertical-align:middle;'
           f'width:44%;border-top:2px dashed {t["divider"]};">'
           f'<span leaf=""><br></span></section>')
    return (f'<section style="text-align:center;padding:0 8px;margin:0;">'
            f'{seg}'
            f'<section style="display:inline-block;vertical-align:middle;'
            f'padding:0 8px;font-size:10px;color:{t["divider"]};">'
            f'<span leaf="">✂</span></section>'
            f'{seg}</section>')


def byline_line(t: dict, text: str) -> str:
    """署名行。text 为空时调用方不应调用本函数（render 已做判断）。"""
    return (f'<p style="font-size:12px;font-weight:700;color:{t["accent"]};'
            f'letter-spacing:2px;margin:0 0 18px;text-align:center;">'
            f'<span leaf="">{esc(text)}</span></p>')


def cover_image(t: dict, src: str) -> str:
    deco = t.get("deco", "")
    r = t["radius"]
    img = (f'<span leaf=""><img src="{esc(src)}" '
           f'style="max-width:100%;height:auto;display:block;margin:0 auto;"></span>')

    if deco == "ticket":
        # 票据封面：绿标题条（含星级）→ 纸感画框 → 撕票线 → 票根小字。
        # 原主题的 writing-mode:vertical-rl 竖排票根字这里没有移植：
        # 老客户端渲染不稳，且它不承载信息，删掉不损失内容。
        return (f'<section style="margin:0 0 28px;background:{t["bg"]};'
                f'border:2px solid {t["border"]};">'
                f'<section style="background:{t["accent"]};padding:10px 16px;">'
                f'<span style="color:{t["bg"]};font-size:11px;letter-spacing:4px;'
                f'font-weight:600;"><span leaf="">ADMIT ONE</span></span>'
                f'{star_rating(t, color=t["bg"])}'
                f'</section>'
                f'<section style="padding:6px;">{img}</section>'
                f'{tear_line(t)}'
                f'<section style="padding:8px 16px;">'
                f'<span style="font-size:10px;color:{t["part"]};letter-spacing:1px;">'
                f'<span leaf="">VALID FOR ONE READ</span></span>'
                f'<span style="font-size:10px;color:{t["part"]};letter-spacing:1px;float:none;display:inline-block;margin-left:20px;">'
                f'<span leaf="">NO.001</span></span>'
                f'</section></section>')

    if deco in ("watermark", "zen"):
        # 极简风：不加阴影、不加圆角、不裁切，只用一条 1px 细线收底。
        # 这两套主题的气质全靠留白撑，任何投影都会显脏。
        return (f'<section style="margin:0 0 28px;padding:0 0 20px;'
                f'border-bottom:1px solid {t["divider"]};">{img}</section>')

    return (f'<section style="margin:0 0 28px;border:1px solid {t["border"]};'
            f'border-radius:{r}px;">{img}</section>')


def chapter_title(t: dict, num: str, cn: str, en: str) -> str:
    deco = t.get("deco", "")

    if deco == "ticket":
        # 票据风章节：主题色编号块 + 标题 + 英文小标 + 星级，底部黑实线收口。
        # 星级放在这里（而不是只放封面）是刻意的——封面是可选参数，
        # 只挂封面会导致「不传封面的用户永远看不到本主题的签名元素」。
        return (f'<section style="margin-top:40px;margin-bottom:28px;padding:0 20px;">'
                f'<section style="padding-bottom:12px;border-bottom:2px solid {t["border"]};">'
                f'<span style="display:inline-block;background:{t["num"]};color:{t["bg"]};font-size:12px;'
                f'font-weight:800;padding:6px 12px;letter-spacing:2px;vertical-align:middle;margin-right:10px;">'
                f'<span leaf="">{esc(num)}</span></span>'
                f'<span style="display:inline-block;font-size:18px;font-weight:800;color:{t["title"]};'
                f'letter-spacing:1px;vertical-align:middle;"><span leaf="">{esc(to_fw(cn))}</span></span>'
                f'<span style="display:inline-block;font-size:11px;color:{t["en"]};letter-spacing:1px;'
                f'vertical-align:middle;margin-left:8px;"><span leaf="">/ {esc(en)}</span></span>'
                f'{star_rating(t)}'
                f'</section></section>')

    if deco == "watermark":
        # 石墨极简：48px 超大浅灰水印编号压在最上层，英文小标 + 深炭标题，
        # 1px 细线收底。原主题用 position:relative 让编号叠到标题背后，
        # 这里改成纵向堆叠——position 是公众号合规门禁的红线，不能带进来，
        # 且视觉上「大号浅色数字 + 紧随其后的标题」同样成立。
        return (f'<section style="margin-top:56px;margin-bottom:32px;padding:0 10px;">'
                f'<section style="padding-bottom:20px;'
                f'border-bottom:1px solid {t["divider"]};">'
                f'<p style="font-size:48px;font-weight:900;color:{t["num"]};margin:0;'
                f'line-height:1;letter-spacing:-2px;">'
                f'<span leaf="">{esc(num)}</span></p>'
                f'<p style="font-size:10px;color:{t["part"]};font-weight:500;'
                f'letter-spacing:3px;margin:6px 0;">'
                f'<span leaf="">{esc(en)}</span></p>'
                f'<p style="font-size:20px;font-weight:800;color:{t["title"]};margin:0;'
                f'letter-spacing:0.5px;line-height:1.4;">'
                f'<span leaf="">{esc(to_fw(cn))}</span></p>'
                f'</section></section>')

    if deco == "editorial":
        # 手记风·编辑部内刊：衬线大标题 + 细横线收底 + 小号英文标。
        return (f'<section style="margin-top:48px;margin-bottom:26px;padding:0 20px;">'
                f'<p style="margin:0 0 6px;font-size:11px;color:{t["part"]};'
                f'font-weight:600;letter-spacing:3px;"><span leaf="">{esc(num)} · {esc(en)}</span></p>'
                f'<p style="margin:0 0 14px;font-size:21px;font-weight:800;color:{t["title"]};'
                f'line-height:1.35;letter-spacing:0.4px;'
                f"font-family:{t.get('font','') or t['font']} or 'Songti SC','Noto Serif SC',Georgia,serif';\">"
                f'<span leaf="">{esc(to_fw(cn))}</span></p>'
                f'<p style="margin:0;border-bottom:1px solid {t["divider"]};height:1px;">'
                f'<span leaf=""><br></span></p></section>')

    if deco == "zen":
        # 留白禅意：雾绿小号英文标（编号内嵌在前）+ 衬线大字中文 + 40px 短线。
        # 无色块、无边框、无编号块，层级全靠字号与留白拉开。
        return (f'<section style="margin-top:64px;margin-bottom:32px;padding:0 16px;">'
                f'<p style="font-size:10px;color:{t["num"]};font-weight:600;'
                f'letter-spacing:4px;margin:0 0 10px;">'
                f'<span leaf="">{esc(num)} · {esc(en)}</span></p>'
                f'<p style="font-size:22px;font-weight:700;color:{t["title"]};'
                f'margin:0 0 16px;letter-spacing:0.5px;line-height:1.4;">'
                f'<span leaf="">{esc(to_fw(cn))}</span></p>'
                f'<section style="width:40px;height:2px;background:{t["accent"]};">'
                f'<span leaf=""><br></span></section>'
                f'</section>')

    if deco == "pop":
        # 资讯爆款：accent 实色块「看点 {tag}」标签 + 超大粗体标题（抓眼球）。
        return (f'<section style="margin-top:44px;margin-bottom:26px;padding:0 20px;">'
                f'<section style="margin-bottom:12px;">'
                f'<span style="display:inline-block;background:{t["accent"]};color:#fff;'
                f'font-size:12px;font-weight:900;padding:4px 12px;letter-spacing:1px;">'
                f'<span leaf="">看点 {esc(num)}</span></span></section>'
                f'<p style="margin:0;font-size:26px;font-weight:900;color:{t["title"]};'
                f'line-height:1.25;letter-spacing:0.3px;"><span leaf="">{esc(to_fw(cn))}</span></p>'
                f'<p style="margin:6px 0 0;font-size:11px;color:{t["en"]};letter-spacing:2px;">'
                f'<span leaf="">{esc(en)}</span></p></section>')

    if deco == "magazine":
        # 品牌绿·绿色杂志风（skill theme-brand-green「标签化章节」）：绿色药丸标签
        # （章节号）+ 粗体标题 + 3px 绿粗线收口——杂志刊头的标签感，与经典档
        # 「大号数字 PART + 竖线」一眼可辨。
        return (f'<section style="margin-top:44px;margin-bottom:26px;padding:0 20px;">'
                f'<section style="margin-bottom:12px;">'
                f'<span style="display:inline-block;background:{t["accent"]};color:#ffffff;'
                f'font-size:12px;font-weight:800;padding:5px 14px;border-radius:14px;'
                f'letter-spacing:2px;vertical-align:middle;margin-right:10px;">'
                f'<span leaf="">{esc(num)}</span></span>'
                f'<span style="display:inline-block;font-size:19px;font-weight:900;'
                f'color:{t["title"]};vertical-align:middle;">'
                f'<span leaf="">{esc(to_fw(cn))}</span></span>'
                f'<span style="display:inline-block;font-size:10px;color:{t["en"]};'
                f'letter-spacing:2px;vertical-align:middle;margin-left:8px;">'
                f'<span leaf="">{esc(en)}</span></span></section>'
                f'<section style="height:3px;background:{t["accent"]};'
                f'border-radius:2px;"><span leaf=""><br></span></section></section>')

    if deco == "badge":
        # 深海蓝（skill theme-ocean-deep「深青方角徽章」）：方角实色编号块（白字）
        # + 标题 + 1px 细线收底——冷静专业的徽章感，与绿药丸（圆角14）/票据（含星级）
        # 拉开：无圆角、无星级、细线更轻。
        return (f'<section style="margin-top:42px;margin-bottom:26px;padding:0 20px;">'
                f'<section style="padding-bottom:12px;border-bottom:1px solid {t["divider"]};">'
                f'<span style="display:inline-block;background:{t["num"]};color:#ffffff;'
                f'font-size:13px;font-weight:800;padding:7px 12px;'
                f'letter-spacing:1px;vertical-align:middle;margin-right:12px;">'
                f'<span leaf="">{esc(num)}</span></span>'
                f'<span style="display:inline-block;font-size:18px;font-weight:800;'
                f'color:{t["title"]};vertical-align:middle;">'
                f'<span leaf="">{esc(to_fw(cn))}</span></span>'
                f'<span style="display:inline-block;font-size:10px;color:{t["en"]};'
                f'letter-spacing:2px;vertical-align:middle;margin-left:8px;">'
                f'<span leaf="">{esc(en)}</span></span>'
                f'</section></section>')

    if deco in ("oat", "bar"):
        # 左竖条骨架（oat=Claude 燕麦衬线 / bar=Stripe 紫蓝无衬线）：
        # 4px 主题色左竖条 + 落款式编号英文行 + 大字标题。字体差异由
        # font_stack(t) 自动承载（衬线主题自带衬线、无衬线主题走 BASE_FONT），
        # 颜色取各自 accent——一个骨架吃掉两个 track 特征（暖陶竖条 / 紫蓝粗条）。
        return (f'<section style="margin-top:46px;margin-bottom:26px;padding:0 20px;">'
                f'<section style="border-left:4px solid {t["accent"]};'
                f'padding:4px 0 4px 16px;">'
                f'<p style="margin:0 0 4px;font-size:10px;color:{t["en"]};'
                f'font-weight:600;letter-spacing:3px;">'
                f'<span leaf="">{esc(num)} · {esc(en)}</span></p>'
                f'<p style="margin:0;font-size:20px;font-weight:700;color:{t["title"]};'
                f'line-height:1.4;letter-spacing:0.5px;'
                f"font-family:{font_stack(t)};\">"
                f'<span leaf="">{esc(to_fw(cn))}</span></p>'
                f'</section></section>')

    if deco == "ink":
        # 国风墨色（skill theme-guofeng-ink「宣纸米底+楷体标题+朱砂竖条」）：
        # 5px 朱砂实色竖条 + 楷体标题 + 朱砂小字编号——书卷气。
        # 字号/字距都比衬线系大半档：楷体在同字号下视觉偏小。
        return (f'<section style="margin-top:48px;margin-bottom:28px;padding:0 20px;">'
                f'<section style="border-left:5px solid {t["accent"]};'
                f'padding:4px 0 4px 18px;">'
                f'<p style="margin:0 0 6px;font-size:10px;color:{t["accent"]};'
                f'letter-spacing:4px;">'
                f'<span leaf="">{esc(num)} · {esc(en)}</span></p>'
                f'<p style="margin:0;font-size:21px;font-weight:700;color:{t["title"]};'
                f'line-height:1.5;letter-spacing:1px;'
                f"font-family:{font_stack(t)};\">"
                f'<span leaf="">{esc(to_fw(cn))}</span></p>'
                f'</section></section>')

    if deco == "underline":
        # NYT 纽时（skill theme-nyt-editorial「衬线宋体+黑色下划线章节」）：
        # 全直角 + 衬线标题 + 2px 墨黑下划线收底——报纸社论感。
        return (f'<section style="margin-top:46px;margin-bottom:26px;padding:0 20px;">'
                f'<p style="margin:0 0 4px;font-size:10px;color:{t["part"]};'
                f'font-weight:600;letter-spacing:3px;">'
                f'<span leaf="">{esc(num)} · {esc(en)}</span></p>'
                f'<p style="margin:0 0 10px;font-size:20px;font-weight:800;'
                f'color:{t["title"]};line-height:1.4;'
                f"font-family:{font_stack(t)};\">"
                f'<span leaf="">{esc(to_fw(cn))}</span></p>'
                f'<p style="margin:0;height:2px;background:{t["accent"]};">'
                f'<span leaf=""><br></span></p></section>')

    if deco == "bauhaus":
        # 包豪斯（skill theme-bauhaus-bold「红黄蓝三色横条+粗黑边」）：
        # 标题上方红/黄/蓝三段色条（三等分 inline-block，无渐变纯色）+ 特粗标题。
        # 黄色为包豪斯经典 #F4D35E（主题色板里没有黄位，写死是刻意的）。
        return (f'<section style="margin-top:46px;margin-bottom:26px;padding:0 20px;">'
                f'<section style="height:6px;margin-bottom:12px;">'
                f'<span style="display:inline-block;width:33%;height:6px;background:#E63946;"></span>'
                f'<span style="display:inline-block;width:33%;height:6px;background:#F4D35E;"></span>'
                f'<span style="display:inline-block;width:33%;height:6px;background:{t["num"]};"></span>'
                f'</section>'
                f'<p style="margin:0 0 2px;font-size:10px;color:{t["part"]};'
                f'font-weight:700;letter-spacing:3px;">'
                f'<span leaf="">{esc(num)} · {esc(en)}</span></p>'
                f'<p style="margin:0;font-size:21px;font-weight:900;color:{t["title"]};'
                f'line-height:1.35;letter-spacing:0.5px;">'
                f'<span leaf="">{esc(to_fw(cn))}</span></p></section>')

    return (f'<section style="margin-top:48px;margin-bottom:32px;padding:0 20px;">'
            f'<section style="margin-bottom:24px;">'
            f'<section style="display:inline-block;vertical-align:middle;text-align:center;margin-right:16px;">'
            f'<p style="margin:0;font-size:28px;font-weight:900;color:{t["num"]};'
            f'line-height:1;letter-spacing:-2px;"><span leaf="">{esc(num)}</span></p>'
            f'<p style="margin:0;font-size:8px;font-weight:700;color:{t["part"]};'
            f'letter-spacing:2px;"><span leaf="">PART</span></p>'
            f'</section>'
            f'<span style="display:inline-block;vertical-align:middle;width:1px;height:36px;background:{t["divider"]};margin-right:16px;">'
            f'<span leaf=""><br></span></span>'
            f'<section style="display:inline-block;vertical-align:middle;">'
            f'<p style="margin:0 0 1px;font-size:17px;font-weight:900;color:{t["title"]};'
            f'letter-spacing:0.3px;"><span leaf="">{esc(to_fw(cn))}</span></p>'
            f'<p style="margin:0;font-size:11px;font-weight:600;color:{t["en"]};'
            f'letter-spacing:1.5px;"><span leaf="">{esc(en)}</span></p>'
            f'</section></section></section>')


# ── 2026-10-20 工单⑩：主题差异化·段落层 + 强调层 ─────────────────────────
# 痛点（导演实测）：此前 paragraph() 主题无关（所有主题 14px/1.9/justify 一模
# 一样），strong 恒等于「accent 色加粗」——纯段落文章在 17 套主题下只有颜色差异。
# 现在每个主题带独立的 段落（字号/行高/缩进/段距/字距/正文色）与 强调（加粗的
# 形态：实色/底纹胶囊/黑底线/纸签底……）变体；未登记的 key 走 deco 兜底。
# 字段约定：p_size/p_lh/p_indent/p_gap/p_ls/p_color + strong_css（可用 {accent} 占位）。
_P_VARIANTS: dict[str, dict] = {
    "green":            {},
    "shengyuan-earth":  {"p_size": "15px", "p_lh": "2.0", "p_color": "#3D3830"},
    "red-white":        {"p_size": "15px", "p_gap": "18px"},
    "olive":            {"p_size": "15px", "p_lh": "2.0", "p_color": "#4A4235", "p_gap": "18px"},
    "guofeng-ink":      {"p_size": "15.5px", "p_lh": "2.1", "p_indent": "2em",
                         "p_color": "#2B2B2B", "p_font": "Kaiti SC,'KaiTi','STKaiti',serif"},
    "mint-handbook":    {"p_size": "14.5px", "p_lh": "2.0", "p_gap": "18px"},
    "morandi":          {"p_size": "14.5px", "p_lh": "2.0", "p_color": "#5B5852", "p_ls": "0.3px"},
    "stripe-silicon":   {"p_size": "14.5px", "p_lh": "1.85", "p_color": "#24292F"},
    "claude-oat":       {"p_size": "15px", "p_lh": "2.05", "p_color": "#3F3A33", "p_gap": "19px"},
    "nyt-editorial":    {"p_size": "15px", "p_lh": "2.0", "p_color": "#121212",
                         "p_font": "Georgia,'Songti SC','SimSun',serif"},
    "bauhaus-bold":     {"p_size": "15px", "p_lh": "1.85", "p_color": "#1A1A1A"},
    "warm-sun":         {"p_size": "15px", "p_lh": "2.0", "p_color": "#4A3F35"},
    "ocean-deep":       {"p_size": "14.5px", "p_lh": "1.9", "p_color": "#1F2937"},
    "moyu-ticket":      {"p_size": "14.5px", "p_lh": "1.95", "p_color": "#333333"},
    "graphite-minimal": {"p_size": "14.5px", "p_lh": "2.0", "p_color": "#3F3F46", "p_ls": "0.2px"},
    "zen-whitespace":   {"p_size": "15.5px", "p_lh": "2.15", "p_color": "#4A5D52",
                         "p_gap": "22px", "p_ls": "0.5px"},
    "news-pop":         {"p_size": "14.5px", "p_lh": "1.85", "p_color": "#333333"},
    "project-intro":    {"p_size": "14.5px", "p_lh": "1.85", "p_color": "#24292F"},
}
_STRONG_VARIANTS: dict[str, str] = {
    # 默认 = color:{accent}；这里只登记形态不同的主题
    "nyt-editorial":  "color:#121212;border-bottom:3px solid #121212;",
    "bauhaus-bold":   "background:#1A1A1A;color:#FFFFFF;padding:1px 6px;border-radius:2px;",
    "mint-handbook":  "background:#E0F5EE;color:#1F7A5C;padding:1px 6px;border-radius:8px;",
    "moyu-ticket":    "background:#FFF3C4;color:#8A6D1F;padding:1px 5px;border-radius:3px;",
    "zen-whitespace": "color:inherit;font-weight:700;border-bottom:1.5px solid #C9CFC6;",
    "guofeng-ink":    "color:#C0392B;font-weight:700;",
    "morandi":        "color:#6E6A63;font-weight:700;",
    "olive":          "background:#FDF0E3;color:#C2570F;padding:1px 5px;border-radius:4px;",
    "red-white":      "color:#DC2626;font-weight:700;",
}


def _p_css(t: dict) -> str:
    v = dict(_P_VARIANTS.get(t.get("key") or "", {}))
    # deco 兜底：未登记 key 也有主题感（保留旧默认做基线）
    if not v:
        v = {"p_size": "14px", "p_lh": "1.9"} if t.get("deco") else {}
    size = v.get("p_size", "14px")
    lh = v.get("p_lh", "1.9")
    gap = v.get("p_gap", "16px")
    color = v.get("p_color", "")
    font = v.get("p_font", "")
    indent = v.get("p_indent", "")
    ls = v.get("p_ls", "")
    css = f"margin-bottom:{gap};font-size:{size};line-height:{lh};text-align:justify;"
    if color:
        css += f"color:{color};"
    if font:
        css += f"font-family:{font};"
    if indent:
        css += f"text-indent:{indent};"
    if ls:
        css += f"letter-spacing:{ls};"
    return css


def _strong_css(t: dict) -> str:
    s = _STRONG_VARIANTS.get(t.get("key") or "")
    return s or f"color:{t['accent']};font-weight:700;"


def paragraph(t: dict, html: str) -> str:
    return f'<p style="{_p_css(t)}">{html}</p>'


def quote_box(t: dict, html: str) -> str:
    deco = t.get("deco", "")
    r = t["radius"]

    if deco == "ticket":
        # 票据风的结论卡片：左侧主题色实心竖条 + 浅色卡底。
        # 不用四周虚线框——虚线在本主题是「撕票线」的专属语义，
        # 拿来当引用框会跟封面的撕票线打架。
        return (f'<section style="background:{t["card"]};'
                f'border-left:4px solid {t["accent"]};padding:14px 16px;'
                f'margin-bottom:24px;text-align:justify;">'
                f'<p style="font-size:14px;color:{t["title"]};font-weight:600;'
                f'margin:0;line-height:1.7;">{html}</p></section>')

    if deco in ("watermark", "zen"):
        # 极简风：原主题明令「正文强调不用四周虚线框」，改 1px 细线左竖条 +
        # 大留白，不给底色，让引用轻到几乎只剩一条线。
        return (f'<section style="border-left:2px solid {t["divider"]};'
                f'padding:2px 0 2px 18px;margin:0 0 28px;text-align:justify;">'
                f'<p style="font-size:14px;color:{t["part"]};margin:0;line-height:1.8;">'
                f'{html}</p></section>')

    if deco == "pop":
        # 资讯爆款：黑底 + accent 左条 + 🔥划重点标签 + 白字（划重点金句）。
        return (f'<section style="background:#111111;border-left:5px solid {t["accent"]};'
                f'padding:16px 18px;margin:0 0 24px;text-align:justify;">'
                f'<p style="margin:0 0 8px;font-size:12px;font-weight:800;color:{t["accent"]};'
                f'letter-spacing:1px;"><span leaf="">🔥 划重点</span></p>'
                f'<p style="font-size:14px;color:#ffffff;margin:0;line-height:1.75;">'
                f'{html}</p></section>')

    if deco == "magazine":
        # 品牌绿：绿浅底 + 3px 绿左条 + 右侧圆角——杂志摘录卡。
        # 经典档是四周虚线框，这里换成实色左条，与标签化章节同语言。
        return (f'<section style="background:{t["cta_bg"]};'
                f'border-left:3px solid {t["accent"]};'
                f'border-radius:0 {r}px {r}px 0;padding:14px 16px;'
                f'margin-bottom:24px;text-align:justify;">'
                f'<p style="font-size:14px;color:{t["title"]};font-weight:600;'
                f'margin:0;line-height:1.7;">{html}</p></section>')

    if deco == "badge":
        # 深海蓝：方角（radius 0）+ 5px 深青左条 + 浅青蓝卡底——徽章语言延伸。
        return (f'<section style="background:{t["card"]};'
                f'border-left:5px solid {t["accent"]};padding:14px 16px;'
                f'margin-bottom:24px;text-align:justify;">'
                f'<p style="font-size:14px;color:{t["title"]};font-weight:600;'
                f'margin:0;line-height:1.7;">{html}</p></section>')

    if deco == "oat":
        # Claude 燕麦：暖陶细条 + 燕麦底 + 衬线——安静，不抢正文。
        return (f'<section style="background:{t["card"]};'
                f'border-left:2px solid {t["accent"]};'
                f'border-radius:0 {r}px {r}px 0;padding:14px 18px;'
                f'margin-bottom:24px;text-align:justify;">'
                f'<p style="font-size:14px;color:{t["body"]};margin:0;line-height:1.8;'
                f"font-family:{font_stack(t)};\">{html}</p></section>")

    if deco == "ink":
        # 国风墨色：宣纸底 + 5px 朱砂条 + 楷体——引文像题跋。
        return (f'<section style="background:{t["card"]};'
                f'border-left:5px solid {t["accent"]};'
                f'border-radius:{r}px;padding:14px 18px;'
                f'margin-bottom:24px;text-align:justify;">'
                f'<p style="font-size:14px;color:{t["title"]};margin:0;line-height:1.8;'
                f"font-family:{font_stack(t)};\">{html}</p></section>")

    if deco in ("underline", "bauhaus"):
        # NYT/包豪斯：实线边框引用（不用经典虚线框——笨重抢戏）。
        # NYT = 1px 细灰边 + 3px 墨黑左条；包豪斯 = 2px 蓝黑粗边（直角）+ 4px 红左条。
        _bd = ('2px solid ' + t["num"]) if deco == "bauhaus" else ('1px solid ' + t["divider"])
        return (f'<section style="border:{_bd};border-left:4px solid {t["accent"]};'
                f'background:{t["card"]};padding:12px 16px;'
                f'margin-bottom:24px;text-align:justify;">'
                f'<p style="font-size:13px;color:{t["body"]};margin:0;line-height:1.7;">'
                f'{html}</p></section>')

    return (f'<section style="background:{t["card"]};border:1px dashed {t["border"]};'
            f'border-radius:{r}px;padding:12px 16px;margin-bottom:24px;text-align:justify;">'
            f'<p style="font-size:13px;color:{t["body"]};margin:0;line-height:1.6;">'
            f'{html}</p></section>')


def ordered_list(t: dict, items: list[str], fn_buf: list | None = None) -> str:
    parts = []
    deco = t.get("deco", "")
    for i, it in enumerate(items, 1):
        if deco == "pop":
            # 资讯爆款：accent ▶ 前缀 + 粗体短句，无圆点徽章（抓眼球紧凑感）。
            parts.append(
                f'<section style="border-bottom:1px solid {t["divider"]};padding:8px 0;margin-bottom:0;">'
                f'<span style="display:inline-block;color:{t["accent"]};font-weight:900;'
                f'font-size:13px;vertical-align:middle;margin-right:6px;"><span leaf="">▶</span></span>'
                f'<span style="font-size:14px;color:{t["body"]};vertical-align:middle;line-height:1.9;">'
                f'{inline(t, it, fn_buf)}</span></section>')
            continue
        if deco in ("magazine", "badge", "oat", "bar", "bauhaus"):
            # 2026-10-09 反馈⑦：标签/徽章/竖条语言延续——方角数字块（区别于经典圆形）。
            # 包豪斯额外加 2px 黑边（三色横条同源的粗黑边语言）。
            _bd = ('border:2px solid ' + t["num"] + ';') if deco == "bauhaus" else ''
            parts.append(
                f'<section style="border-bottom:1px solid {t["divider"]};padding:8px 0;margin-bottom:0;">'
                f'<span style="display:inline-block;width:22px;height:22px;background:{t["accent"]};{_bd}'
                f'color:#fff;font-size:11px;font-weight:700;border-radius:2px;'
                f'text-align:center;line-height:22px;vertical-align:middle;margin-right:8px;">'
                f'<span leaf="">{i}</span></span>'
                f'<span style="font-size:14px;color:{t["body"]};vertical-align:middle;line-height:1.9;">'
                f'{inline(t, it, fn_buf)}</span></section>')
            continue
        if deco == "ink":
            # 国风墨色：朱砂空心圆 + 楷体数字——题跋序号语言。
            parts.append(
                f'<section style="border-bottom:1px solid {t["divider"]};padding:8px 0;margin-bottom:0;">'
                f'<span style="display:inline-block;width:22px;height:22px;'
                f'border:1px solid {t["accent"]};color:{t["accent"]};font-size:11px;'
                f"font-family:{font_stack(t)};"
                f'border-radius:50%;text-align:center;line-height:20px;'
                f'vertical-align:middle;margin-right:8px;">'
                f'<span leaf="">{i}</span></span>'
                f'<span style="font-size:14px;color:{t["body"]};vertical-align:middle;line-height:1.9;">'
                f'{inline(t, it, fn_buf)}</span></section>')
            continue
        if deco == "underline":
            # NYT：无徽章，衬线裸编号「01 ·」+ 正文——编辑部清单语言。
            parts.append(
                f'<section style="border-bottom:1px solid {t["divider"]};padding:8px 0;margin-bottom:0;">'
                f'<span style="font-size:13px;font-weight:700;color:{t["title"]};'
                f"font-family:{font_stack(t)};"
                f'vertical-align:middle;margin-right:8px;">'
                f'<span leaf="">{i:02d} ·</span></span>'
                f'<span style="font-size:14px;color:{t["body"]};vertical-align:middle;line-height:1.9;">'
                f'{inline(t, it, fn_buf)}</span></section>')
            continue
        if deco in ("watermark", "zen"):
            # 极简风：无徽章，accent 裸数字——留白气质，任何色块都嫌重。
            parts.append(
                f'<section style="border-bottom:1px solid {t["divider"]};padding:8px 0;margin-bottom:0;">'
                f'<span style="font-size:13px;font-weight:700;color:{t["accent"]};'
                f'vertical-align:middle;margin-right:8px;">'
                f'<span leaf="">{i:02d}</span></span>'
                f'<span style="font-size:14px;color:{t["body"]};vertical-align:middle;line-height:1.9;">'
                f'{inline(t, it, fn_buf)}</span></section>')
            continue
        parts.append(
            f'<section style="border-bottom:1px solid {t["divider"]};padding:8px 0;margin-bottom:0;">'
            f'<span style="display:inline-block;width:22px;height:22px;background:{t["accent"]};'
            f'color:#fff;font-size:11px;font-weight:700;border-radius:50%;'
            f'text-align:center;line-height:22px;vertical-align:middle;margin-right:8px;">'
            f'<span leaf="">{i}</span></span>'
            f'<span style="font-size:14px;color:{t["body"]};vertical-align:middle;line-height:1.9;">'
            f'{inline(t, it, fn_buf)}</span></section>')
    return f'<section style="margin-bottom:24px;">{"".join(parts)}</section>'


def unordered_list(t: dict, items: list[str], fn_buf: list | None = None) -> str:
    """无序列表：复用有序列表的安全子集结构，数字徽章换成主题色圆点。"""
    deco = t.get("deco", "")
    parts = []
    for it in items:
        # 2026-10-09 反馈⑦：圆点按 deco 分形态——方角点（标签/徽章/竖条/包豪斯）、
        # 短横线（NYT 下划线语言）、空心圈（国风）、默认实心圆点。
        if deco in ("magazine", "badge", "oat", "bar", "bauhaus"):
            dot = (f'<span style="display:inline-block;width:6px;height:6px;background:{t["accent"]};'
                   f'border-radius:2px;vertical-align:middle;margin-right:10px;">'
                   f'<span leaf=""><br></span></span>')
        elif deco == "underline":
            dot = (f'<span style="display:inline-block;width:12px;height:2px;background:{t["title"]};'
                   f'vertical-align:middle;margin-right:10px;">'
                   f'<span leaf=""><br></span></span>')
        elif deco == "ink":
            dot = (f'<span style="display:inline-block;width:8px;height:8px;'
                   f'border:1px solid {t["accent"]};border-radius:50%;'
                   f'vertical-align:middle;margin-right:8px;">'
                   f'<span leaf=""><br></span></span>')
        elif deco in ("watermark", "zen"):
            dot = (f'<span style="display:inline-block;width:4px;height:4px;background:{t["divider"]};'
                   f'border-radius:50%;vertical-align:middle;margin-right:12px;">'
                   f'<span leaf=""><br></span></span>')
        else:
            dot = (f'<span style="display:inline-block;width:6px;height:6px;background:{t["accent"]};'
                   f'border-radius:50%;vertical-align:middle;margin-right:10px;">'
                   f'<span leaf=""><br></span></span>')
        parts.append(
            f'<section style="border-bottom:1px solid {t["divider"]};padding:8px 0;margin-bottom:0;">'
            f'{dot}'
            f'<span style="font-size:14px;color:{t["body"]};vertical-align:middle;line-height:1.9;">'
            f'{inline(t, it, fn_buf)}</span></section>')
    return f'<section style="margin-bottom:24px;">{"".join(parts)}</section>'


def h3_title(t: dict, text: str) -> str:
    """三级标题：明显弱于 ## 章节标题，不抢层级。"""
    return (f'<p style="font-size:15px;font-weight:700;color:{t["title"]};'
            f'margin:24px 0 12px;line-height:1.5;">'
            f'<span leaf="">{esc(to_fw(text))}</span></p>')


def code_inline(t: dict, code: str) -> str:
    """行内代码：等宽字体 + 主题色卡片底（内容不经过 to_fw，原样保留）。"""
    return (f'<code style="font-family:Menlo,Consolas,monospace;font-size:13px;'
            f'background:{t["card"]};color:{t["accent"]};'
            f'padding:2px 6px;border-radius:4px;border:1px solid {t["border"]};'
            f'white-space:nowrap;">'
            f'<span leaf="">{esc(code)}</span></code>')


def code_block(t: dict, code: str) -> str:
    """围栏代码块：等宽卡片，white-space:pre-wrap 保留换行（不依赖 <pre>，公众号兼容）。"""
    r = t["radius"]
    return (f'<section style="background:{t["card"]};border:1px solid {t["border"]};'
            f'border-radius:{r}px;padding:14px 16px;margin:0 0 24px;'
            f'white-space:pre-wrap;word-break:break-all;overflow-x:auto;'
            f'font-family:Menlo,Consolas,monospace;font-size:13px;line-height:1.7;'
            f'color:{t["body"]};">'
            f'<span leaf="">{esc(code)}</span></section>')


def image_embed(t: dict, src: str, alt: str = "", size: str = "") -> str:
    """吃 URL / data URI，不做本地文件读取。src 为空时退化为占位块。

    size 语法（对标 doocs/md）：`![alt|200x100](url)` / `![alt|200](url)` /
    `![alt|50%](url)`。微信会剥 img 的 width/height 属性，必须内联进 style；
    同时保留 max-width:100% 防溢出。size 为空维持原行为。
    """
    if not src:
        return placeholder(t, "图片缺失：" + alt)
    r = t["radius"]
    # 微信安全子集：投影会被剥离，正文配图一律不挂投影（留白主题更干净）。
    wh = ""
    if size:
        s = size.strip()
        if s.endswith("%"):
            wh = f'width:{s};height:auto;'
        else:
            m = re.match(r"^(\d{1,4})(?:[xX×](\d{1,4}))?$", s)
            if m:
                w, h = m.group(1), m.group(2)
                wh = (f'width:{w}px;height:{h}px;' if h else f'width:{w}px;height:auto;')
    return (f'<section style="margin:0 0 8px;text-align:center;">'
            f'<span leaf=""><img src="{esc(src)}" alt="{esc(alt)}" '
            f'style="max-width:100%;height:auto;display:block;margin:0 auto;'
            f'border-radius:{r}px;{wh}"></span></section>')


def render_table(t: dict, rows: list[list[str]], aligns: list[str],
                 fn_buf: list | None = None) -> str:
    """Markdown 表格渲染（对标 doocs/md renderer-impl.ts:404-427）。

    - 外层 section overflow-x:auto：微信对超宽 table 会撑破正文容器，滚动容器兜底
    - border-collapse 合并边框；对齐逐格内联（微信剥 table 级样式属性）
    - th 用 card 底色 + 主题标题色，与主题视觉一致
    - cell 内容过 inline()（支持 **加粗** 与链接；fn_buf 透传收集 cell 内脚注）
    """
    if not rows:
        return ""
    head, body = rows[0], rows[1:]
    ths = []
    for j, c in enumerate(head):
        a = aligns[j] if j < len(aligns) else "left"
        ths.append(
            f'<th style="border:1px solid {t["border"]};padding:8px 12px;'
            f'text-align:{a};background:{t["card"]};font-weight:700;'
            f'color:{t["title"]};font-size:13px;">{inline(t, c, fn_buf)}</th>')
    trs = []
    for row in body:
        tds = []
        for j, c in enumerate(row):
            a = aligns[j] if j < len(aligns) else "left"
            tds.append(
                f'<td style="border:1px solid {t["border"]};padding:8px 12px;'
                f'text-align:{a};font-size:13px;color:{t["body"]};">{inline(t, c, fn_buf)}</td>')
        trs.append(f'<tr>{"".join(tds)}</tr>')
    return (f'<section style="max-width:100%;overflow-x:auto;margin:0 0 24px;">'
            f'<table style="border-collapse:collapse;width:100%;font-size:13px;">'
            f'<thead><tr>{"".join(ths)}</tr></thead>'
            f'<tbody>{"".join(trs)}</tbody></table></section>')


def _split_table_row(s: str) -> list[str]:
    """`| A | B |` → ["A", "B"]。首尾竖线剥掉后按 | 切分，逐格 strip。

    转义竖线：标准 markdown 表格里反斜杠+竖线是字面竖线（列内内容含 | 时使用）。
    split 前先替换成 \x01（SOH，与 to_fw 的 \x00N\x00 占位符错开），
    split 后再还原，避免误切成两格。
    """
    core = s.strip()
    if core.startswith("|"):
        core = core[1:]
    if core.endswith("|"):
        core = core[:-1]
    core = core.replace(r"\|", "\x01")
    return [c.strip().replace("\x01", "|") for c in core.split("|")]


def _cell_align(sep_cell: str) -> str:
    """`:---:` → center；`---:` → right；其余 → left。"""
    c = sep_cell.strip()
    left, right = c.startswith(":"), c.endswith(":")
    if left and right:
        return "center"
    if right:
        return "right"
    return "left"


def caption(t: dict, text: str) -> str:
    return (f'<p style="margin:0 0 24px;font-size:12px;color:{t["en"]};'
            f'text-align:center;line-height:1.6;">'
            f'<span leaf="">{esc(to_fw(text))}</span></p>')


def placeholder(t: dict, text: str) -> str:
    r = t["radius"]
    return (f'<section style="margin:0 0 24px;padding:30px 20px;'
            f'border:1.5px dashed {t["border"]};border-radius:{r}px;'
            f'background:{t["card"]};text-align:center;">'
            f'<p style="margin:0 0 10px;font-size:26px;line-height:1;">'
            f'<span leaf="">📊</span></p>'
            f'<p style="margin:0;font-size:14px;font-weight:700;color:{t["en"]};'
            f'letter-spacing:1px;"><span leaf="">待补素材</span></p>'
            f'<p style="margin:8px 0 0;font-size:13px;color:{t["part"]};line-height:1.7;">'
            f'<span leaf="">{esc(text)}</span></p></section>')


# ---------- 用户自定义 IP（1.0.80）----------
# 🔴 背景（胜元原话）：「文章排版的格式中有我 IP 的格式，需要清理，在软件里面设置一个
#    自定义 IP 内容植入的区域，替换进去」。
#    旧版把作者的署名行、文末互动文案、detox 人设都写死成某个具体博主 —— 那是把私人 IP
#    固化进了全体用户的导出稿。现在改为：模板只提供**结构与中性文案**，用户自己的
#    IP（称呼/身份/简介/CTA）由 workspace.ip_profile 提供，空则一律不注入。
CTA_TEXT_DEFAULT = "既然看到这里了，如果觉得有用，随手点个赞、在看、转发三连吧。"


def normalize_ip(ip: dict | None) -> dict:
    """把 config 里的 ip_profile 收敛成干净字符串字典（缺字段一律空串）。

    纯函数，不改入参。任何类型异常都降级为空 —— 排版绝不能因为一个字段类型不对而 500。
    """
    keys = ("name", "tagline", "intro", "cta", "signature")
    out: dict = {}
    for k in keys:
        v = (ip or {}).get(k)
        out[k] = str(v).strip() if isinstance(v, (str, int, float)) else ""
    for k in ("inject_signature", "inject_card", "inject_cta"):
        out[k] = bool((ip or {}).get(k, True))
    # 完整署名行：显式给了就用；只给了称呼/身份就拼成「我是{name}，{tagline}」
    if not out["signature"] and out["name"]:
        tail = f"，{out['tagline']}" if out["tagline"] else ""
        out["signature"] = f"我是{out['name']}{tail}"
    out["has_identity"] = bool(out["name"] or out["tagline"] or out["intro"])
    return out


def ip_card(t: dict, ip: dict) -> str:
    """文末 IP 卡：称呼 + 一句话身份 + 简介。

    只在用户填了 IP 内容时渲染（空 IP 不产生任何作者痕迹）。
    微信安全子集：纯 inline style / section+span / 主题色左竖线 / 无 flex 无阴影。
    """
    if not ip or not ip.get("has_identity"):
        return ""
    name = esc(to_fw(ip.get("name") or ""))
    tag = esc(to_fw(ip.get("tagline") or ""))
    intro = esc(to_fw(ip.get("intro") or ""))
    head = ""
    if name or tag:
        head = (
            f'<p style="margin:0 0 8px;font-size:14px;font-weight:700;'
            f'color:{t["title"]};line-height:1.6;">'
            f'<span leaf="">{name}</span>'
            + (f'<span style="font-weight:400;color:{t["part"]};">　{tag}</span>'
               if tag else "")
            + "</p>"
        )
    body = ""
    if intro:
        body = (
            f'<p style="margin:0;font-size:13px;color:{t["body"]};line-height:1.9;">'
            f'<span leaf="">{intro}</span></p>'
        )
    if not head and not body:
        return ""
    return (
        f'<section style="margin:28px 0 0;padding:18px 20px;background:{t["card"]};'
        f'border-left:4px solid {t["accent"]};border-radius:{t["radius"]}px;">'
        f'{head}{body}</section>'
    )


def _footer_cta_brand(t: dict, text: str = "") -> str:
    """品牌绿 D 形态互动三连：三列图标盒（图上文下），对齐 brand-green MD 组件 13a。

    微信安全子集：横排用 display:inline-block、竖排用 display:block，无 flex/阴影/渐变。
    text：互动引导文案（空 = 系统中性文案，1.0.80 起可由用户 IP 配置覆盖）。
    """
    r = t["radius"]
    _cta = (text or "").strip() or CTA_TEXT_DEFAULT
    return (
        f'<section style="background:{t["card"]};border:1px solid {t["divider"]};'
        f'border-radius:{r}px;padding:32px 20px;text-align:center;margin:0 0 24px;">'
        f'<p style="font-size:13px;font-weight:bold;color:{t["title"]};'
        f'margin-bottom:20px;line-height:1.6;">'
        f'<span leaf="">{esc(to_fw(_cta))}</span></p>'
        f'<section style="text-align:center;margin-bottom:16px;">'
        # 点赞
        f'<section style="display:inline-block;vertical-align:top;margin:0 12px;'
        f'text-align:center;cursor:pointer;color:#4B5563;">'
        f'<section style="display:block;width:40px;height:40px;line-height:40px;'
        f'margin:0 auto 6px;background:#fff;border-radius:12px;border:1px solid #F3F4F6;'
        f'text-align:center;">'
        f'<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" '
        f'stroke-width="1.8" style="vertical-align:middle;">'
        f'<path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"></path></svg>'
        f'</section>'
        f'<span style="font-size:10px;font-weight:600;display:block;text-align:center;">'
        f'<span leaf="">点赞</span></span></section>'
        # 在看
        f'<section style="display:inline-block;vertical-align:top;margin:0 12px;'
        f'text-align:center;cursor:pointer;color:#4B5563;">'
        f'<section style="display:block;width:40px;height:40px;line-height:40px;'
        f'margin:0 auto 6px;background:#fff;border-radius:12px;border:1px solid #F3F4F6;'
        f'text-align:center;">'
        f'<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" '
        f'stroke-width="1.8" style="vertical-align:middle;">'
        f'<circle cx="12" cy="12" r="3"></circle>'
        f'<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path></svg>'
        f'</section>'
        f'<span style="font-size:10px;font-weight:600;display:block;text-align:center;">'
        f'<span leaf="">在看</span></span></section>'
        # 转发（强调色 + 浅绿盒）
        f'<section style="display:inline-block;vertical-align:top;margin:0 12px;'
        f'text-align:center;cursor:pointer;color:{t["accent"]};">'
        f'<section style="display:block;width:40px;height:40px;line-height:40px;'
        f'margin:0 auto 6px;background:{t["cta_bg"]};border-radius:12px;'
        f'border:1px solid {t["cta_border"]};text-align:center;">'
        f'<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" '
        f'stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" '
        f'style="vertical-align:middle;">'
        f'<path d="M4 18v-4a8 8 0 0 1 8-8h8"></path>'
        f'<polyline points="16 2 20 6 16 10"></polyline></svg>'
        f'</section>'
        f'<span style="font-size:10px;font-weight:600;display:block;text-align:center;">'
        f'<span leaf="">转发</span></span></section>'
        f'</section>'
        f'<p style="font-size:10px;color:{t["en"]};letter-spacing:1px;margin:0;">'
        f'<span leaf="">THANKS FOR READING</span></p></section>'
    )


# 🔴 文末互动块（「既然看到这里了…点赞/在看/转发」+ THANKS FOR READING）默认关闭。
# 2026-10-01 胜元反馈：「我创作的文章为什么会有我固定的人设？这个去掉，用户用的适合是他自己的内容。」
# 这块 + 硬编码署名行是唯一写死进每个终端用户导出稿的作者痕迹 → 默认不渲染，需要时由
# ExportRequest.footer_cta=True 显式开启（或调用方传 enabled=True）。
FOOTER_CTA_DEFAULT = False

# ── 「正文纯白」配套常量（2026-10-05）─────────────────────────────────────
# 深底主题去掉外层底色后，原浅色 body 字会变成白底浅字（看不见）。判为浅色时，
# 外层字色统一换成这个深蓝灰 —— 取自导演参考文实测正文色 rgb(66,84,102) = #425466。
BODY_ON_WHITE = "#425466"


def _is_light_color(color: str, thresh: float = 0.62) -> bool:
    """颜色是否偏浅（在白底上会看不清）。

    只看 sRGB 相对亮度够不够，不做 HSL 往返 —— 主题字典里的 bg/body/border 全是 hex，
    算亮度判断够用且不会引第三方依赖（PyInstaller 打包也省事）。
    解析不了的（rgb()/变量名/空）一律当深色处理 → 维持原样，不改变现有行为。
    """
    c = (color or "").strip().lstrip("#")
    if len(c) == 3:
        c = "".join(ch * 2 for ch in c)
    if len(c) != 6:
        return False
    try:
        r, g, b = int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)
    except ValueError:
        return False
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255.0 > thresh


def footer_cta(t: dict, enabled: bool | None = None, text: str = "") -> str:
    """文末互动块。enabled=None 时取 FOOTER_CTA_DEFAULT（默认关）；关时返回空串。

    text：互动引导文案，空 = CTA_TEXT_DEFAULT（1.0.80 起用户 IP 配置可覆盖）。
    """
    if enabled is None:
        enabled = FOOTER_CTA_DEFAULT
    if not enabled:
        return ""
    _cta = (text or "").strip() or CTA_TEXT_DEFAULT
    # 品牌绿 D 形态：三列图标盒（图上文下），与 brand-green MD 组件 13a 逐字节等价
    if t.get("icon_footer"):
        return _footer_cta_brand(t, _cta)
    deco = t.get("deco", "")
    r = t["radius"]

    # 外框三态：极简风只留上下细线（渐变底和投影都会破坏留白气质）；
    # 票据风换黑实边框，并在最上方补一条撕票线收尾；
    # 微信安全子集：径向渐变/阴影会被剥离 → 统一纯色 card 底 + accent 上边线。
    if deco in ("watermark", "zen"):
        frame = (f'background:{t["bg"]};border-top:1px solid {t["divider"]};'
                 f'border-bottom:1px solid {t["divider"]};padding:36px 20px;')
        prefix = ""
    elif deco == "ticket":
        frame = (f'background:{t["bg"]};border:2px solid {t["border"]};'
                 f'padding:32px 20px;')
        prefix = tear_line(t)
    else:
        frame = (f'background:{t["card"]};'
                 f'border-top:4px solid {t["accent"]};padding:32px 20px;')
        prefix = ""

    # 微信安全子集：三连按钮改纯文本式（emoji + 文案），无 flex/阴影/圆角盒。
    return (prefix
            + f'<section style="{frame}'
            f'text-align:center;margin:0 0 24px;">'
            f'<p style="font-size:13px;font-weight:bold;color:{t["title"]};'
            f'margin-bottom:16px;line-height:1.6;">'
            f'<span leaf="">{esc(to_fw(_cta))}</span></p>'
            f'<p style="margin:0;font-size:14px;color:{t["body"]};letter-spacing:3px;">'
            f'<span leaf="">👍 点赞　　👁 在看　　↗ 转发</span></p>'
            f'<p style="font-size:10px;color:{t["en"]};letter-spacing:1px;margin:10px 0 0;">'
            f'<span leaf="">THANKS FOR READING</span></p></section>')


# ---------- Markdown 解析 ----------

EN_LABELS = ["INTRO", "WHY", "METHOD", "CHECKLIST", "DECISION", "INSIGHT",
             "FRAMEWORK", "CASES", "MYTH", "TRUTH", "SUMMARY", "ACTION"]

_H2_NUMBERED_RE = re.compile(r'^##\s*[一二三四五六七八九十]+[、.．\s]\s*(.+)$')
_IMG_RE = re.compile(r'^!\[([^\]|]*)(?:\|(\d{1,4}(?:[xX×]\d{1,4})?%?))?\]\((.*?)\)$')
_TABLE_ROW_RE = re.compile(r'^\s*\|.*\|\s*$')
_TABLE_SEP_RE = re.compile(r'^\s*\|?\s*:?-+:?\s*(\|\s*:?-+:?\s*)+\|?\s*$')
_CAPTION_RE = re.compile(r'^\*(.+)\*$')
_OL_RE = re.compile(r'^\d+[.、]\s+')
_UL_RE = re.compile(r'^[-*]\s+')
# 作者署名行：「我是X」/「我是X，一句话身份」。X 限 1~8 字，太长就是正文句子。
_AUTHOR_LINE_RE = re.compile(r'^[—\-—]{0,2}\s*我是\s*([^，,。！!？?\s]{1,8})\s*(?:[，,。].*)?$')


# ---------- 批10b·需求3：组件库（16 个 ::: 围栏组件，跨主题参数化）----------
# 触发：markdown 中 `::: 组件名 [参数]` + 若干行正文 + `:::` 闭合。
# 设计约束：微信安全子集——纯 inline style / section+span / hex 色 / 禁 flex /
# 禁投影 / 禁渐变；颜色全部取自主题字典（换主题即换色）；每个文本节点塞
# <span leaf=""> 占位，防微信粘贴剥落。组件无大色块，靠留白/细边框/主题色点睛。

def _leaf_wrap(inner: str) -> str:
    """leaf 占位包裹：空/纯装饰节点必须有 <span leaf=""> 内容，防微信粘贴剥落。"""
    return f'<span leaf="">{inner}</span>'


def _fence_label(t: dict, text: str) -> str:
    """小标签 pill：accent 底 + bg 色字。"""
    r = min(int(t.get("radius", 12)), 12)
    return (f'<span style="display:inline-block;padding:2px 10px;background:{t["accent"]};'
            f'color:{t["bg"]};font-size:11px;letter-spacing:2px;border-radius:{r}px;">'
            f'<span leaf="">{esc(text)}</span></span>')


def _fence_paras(t: dict, lines: list, size: str = "13px") -> str:
    """围栏正文行 → 段落串（走 inline，保留加粗/高亮等行内语法）。"""
    return "".join(
        f'<p style="font-size:{size};color:{t["body"]};line-height:1.8;margin:6px 0 0;">'
        f'{inline(t, x)}</p>'
        for x in lines if x.strip())


def comp_hero(t: dict, title: str, sub: str) -> str:
    """头图卡：文首标题+摘要（品牌绿 cover-breaking / 橄榄 hero-card 的跨主题收敛版）。"""
    sub_html = (f'<p style="font-size:13px;color:{t["part"]};line-height:1.7;margin:8px 0 0;">'
                f'<span leaf="">{esc(to_fw(sub))}</span></p>') if sub else ""
    return (f'<section style="background:{t["card"]};border-left:4px solid {t["accent"]};'
            f'border-radius:{t["radius"]}px;padding:18px 20px;margin:0 0 24px;">'
            f'<section style="font-size:20px;font-weight:700;color:{t["title"]};'
            f'line-height:1.4;margin:0;">{_leaf_wrap(esc(to_fw(title)))}</section>'
            f'{sub_html}</section>')


def comp_toc(t: dict, items: list) -> str:
    """横向滚动目录：胶囊章节导航（批10b 需求3 组件2）。"""
    pills = []
    for i, it in enumerate(items, 1):
        if not it.strip():
            continue
        pills.append(
            f'<span style="display:inline-block;padding:4px 12px;margin:0 6px 6px 0;'
            f'background:{t["card"]};border:1px solid {t["border"]};border-radius:14px;'
            f'font-size:12px;color:{t["body"]};">'
            f'<span style="color:{t["accent"]};font-weight:700;"><span leaf="">{i:02d}</span></span> '
            f'<span leaf="">{esc(to_fw(it.strip()))}</span></span>')
    if not pills:
        return ""
    return (f'<section style="margin:0 0 24px;padding:14px 16px;background:{t["bg"]};'
            f'border:1px solid {t["divider"]};border-radius:{t["radius"]}px;">'
            f'<p style="font-size:11px;letter-spacing:2px;color:{t["part"]};margin:0 0 8px;">'
            f'<span leaf="">目录</span></p>{"".join(pills)}</section>')


def comp_note(t: dict, lines: list) -> str:
    """编者按（橄榄手记组件14 跨主题版）。"""
    r = t["radius"]
    return (f'<section style="background:{t["card"]};border-left:4px solid {t["accent"]};'
            f'padding:14px 16px;margin:0 0 24px;border-radius:0 {r}px {r}px 0;">'
            f'{_fence_label(t, "编者按")}'
            f'<section style="margin-top:6px;">{_fence_paras(t, lines)}</section></section>')


def comp_point(t: dict, title: str, lines: list) -> str:
    """重点观点卡（橄榄手记组件15 跨主题版）。"""
    return (f'<section style="border:1px solid {t["accent"]};background:{t["bg"]};'
            f'border-radius:{t["radius"]}px;padding:14px 16px;margin:0 0 24px;">'
            f'{_fence_label(t, "重点观点")} '
            f'<span style="font-size:15px;font-weight:700;color:{t["title"]};">'
            f'<span leaf="">{esc(to_fw(title))}</span></span>'
            f'{_fence_paras(t, lines)}</section>')


def comp_quote_gold(t: dict, text: str) -> str:
    """金句卡（通用库 3d 左竖条金句 跨主题版）。"""
    return (f'<section style="margin:0 0 24px;padding:16px 20px;'
            f'border-left:4px solid {t["accent"]};background:{t["cta_bg"]};'
            f'border-radius:{t["radius"]}px;">'
            f'<p style="font-size:16px;font-weight:700;color:{t["title"]};line-height:1.8;margin:0;">'
            f'<span leaf="">「{esc(to_fw(text))}」</span></p></section>')


def comp_tip(t: dict, kind: str, lines: list) -> str:
    """提示/旁注块（通用库 3e 三态：info 提示 / warn 注意 / danger 重要）。"""
    kmap = {"warn": ("注意", "#d97706"), "danger": ("重要", "#dc2626"),
            "info": ("提示", t["accent"])}
    label, color = kmap.get(kind, kmap["info"])
    return (f'<section style="border-left:4px solid {color};background:{t["card"]};'
            f'padding:12px 16px;margin:0 0 24px;border-radius:{t["radius"]}px;">'
            f'<span style="display:inline-block;padding:1px 8px;background:{color};'
            f'color:#ffffff;font-size:11px;border-radius:4px;">'
            f'<span leaf="">{label}</span></span>'
            f'{_fence_paras(t, lines)}</section>')


def comp_steps(t: dict, items: list) -> str:
    """步骤卡：序号药丸 + 标题|说明（通用库 3c / 橄榄 step-heading 跨主题版）。"""
    rows = []
    n = len([x for x in items if x.strip()])
    for i, it in enumerate(items, 1):
        if not it.strip():
            continue
        title, _, desc = it.partition("|")
        line_color = t["divider"] if i < n else "transparent"
        numbox = (f'<span style="display:inline-block;min-width:22px;height:22px;'
                  f'line-height:22px;text-align:center;background:{t["accent"]};'
                  f'color:{t["bg"]};border-radius:50%;font-size:12px;font-weight:700;">'
                  f'<span leaf="">{i}</span></span>')
        dpart = (f'<p style="font-size:12px;color:{t["part"]};line-height:1.7;margin:2px 0 0 30px;">'
                 f'<span leaf="">{esc(to_fw(desc.strip()))}</span></p>') if desc.strip() else ""
        rows.append(
            f'<section style="border-left:2px solid {line_color};'
            f'padding:0 0 14px 14px;margin:0 0 0 10px;">'
            f'{numbox} '
            f'<span style="font-size:14px;font-weight:700;color:{t["title"]};">'
            f'<span leaf="">{esc(to_fw(title.strip()))}</span></span>{dpart}</section>')
    return f'<section style="margin:0 0 24px;">{"".join(rows)}</section>'


def comp_flow(t: dict, items: list) -> str:
    """流程示意图：纵向盒子 + 箭头（橄榄手记组件23 跨主题版）。"""
    cells = []
    seq = [x.strip() for x in items if x.strip()]
    for i, it in enumerate(seq):
        cells.append(f'<section style="background:{t["card"]};border:1px solid {t["border"]};'
                     f'border-radius:{t["radius"]}px;padding:10px 14px;text-align:center;'
                     f'font-size:13px;color:{t["body"]};"><span leaf="">{esc(to_fw(it))}</span></section>')
        if i < len(seq) - 1:
            cells.append(f'<p style="text-align:center;color:{t["accent"]};font-size:14px;'
                         f'margin:4px 0;line-height:1;"><span leaf="">↓</span></p>')
    return f'<section style="margin:0 0 24px;">{"".join(cells)}</section>'


def comp_timeline(t: dict, items: list) -> str:
    """案例时间线：`节点 | 事件` 行（橄榄手记组件26 跨主题版）。"""
    rows = []
    for it in items:
        if not it.strip():
            continue
        node, _, ev = it.partition("|")
        rows.append(
            f'<section style="border-left:2px dotted {t["accent"]};'
            f'padding:0 0 12px 14px;margin:0 0 0 4px;">'
            f'<span style="font-size:13px;font-weight:700;color:{t["accent"]};">'
            f'<span leaf="">{esc(to_fw(node.strip()))}</span></span>'
            f'<span style="font-size:13px;color:{t["body"]};"><span leaf="">　{esc(to_fw(ev.strip()))}</span></span></section>')
    return f'<section style="margin:0 0 24px;">{"".join(rows)}</section>'


def comp_faq(t: dict, items: list) -> str:
    """常见问题列表：`问题 | 答案` 行（橄榄手记组件25 跨主题版）。"""
    blocks = []
    for it in items:
        if not it.strip():
            continue
        q, has, a = it.partition("|")
        a_html = (f'<p style="font-size:13px;color:{t["body"]};line-height:1.8;margin:4px 0 0 18px;">'
                  f'<span style="color:{t["accent"]};font-weight:700;"><span leaf="">A</span></span> '
                  f'<span leaf="">{inline(t, a.strip())}</span></p>') if has and a.strip() else ""
        blocks.append(
            f'<section style="margin:0 0 12px;">'
            f'<p style="font-size:13px;font-weight:700;color:{t["title"]};margin:0;">'
            f'<span style="color:{t["accent"]};"><span leaf="">Q</span></span> '
            f'<span leaf="">{esc(to_fw(q.strip()))}</span></p>{a_html}</section>')
    return f'<section style="margin:0 0 24px;">{"".join(blocks)}</section>'


def comp_vs(t: dict, left: str, right: str) -> str:
    """二元对比卡（橄榄手记组件21 跨主题版）：47% / VS / 47% inline-block 双栏。"""
    def cell(txt, color):
        return (f'<section style="width:47%;display:inline-block;vertical-align:top;">'
                f'<p style="text-align:center;font-size:14px;color:{color};margin:0 0 6px;'
                f'font-weight:700;"><span leaf="">■</span></p>'
                f'<p style="font-size:13px;color:{t["body"]};line-height:1.8;margin:0;'
                f'text-align:center;">{inline(t, txt.strip())}</p></section>')
    mid = (f'<section style="width:6%;display:inline-block;vertical-align:top;text-align:center;'
           f'color:{t["en"]};font-weight:700;font-size:11px;padding-top:2px;">'
           f'<span leaf="">VS</span></section>')
    return (f'<section style="margin:0 0 24px;background:{t["card"]};'
            f'border-radius:{t["radius"]}px;padding:14px 6px;">'
            f'{cell(left, t["accent"])}{mid}{cell(right, t["part"])}</section>')


def comp_ba(t: dict, old: str, new: str, note: str = "") -> str:
    """新旧对照：删除线旧词 → 新词（橄榄手记组件12 跨主题版）。"""
    note_html = (f'<p style="font-size:12px;color:{t["part"]};margin:6px 0 0;">'
                 f'<span leaf="">{inline(t, note.strip())}</span></p>') if note.strip() else ""
    return (f'<section style="background:{t["card"]};border-radius:{t["radius"]}px;'
            f'padding:12px 16px;margin:0 0 24px;">'
            f'<p style="margin:0;font-size:14px;line-height:1.8;">'
            f'<span style="text-decoration:line-through;color:{t["en"]};">'
            f'<span leaf="">{esc(to_fw(old.strip()))}</span></span>'
            f'<span style="color:{t["accent"]};font-weight:700;">'
            f'<span leaf="">　→　{esc(to_fw(new.strip()))}</span></span></p>'
            f'{note_html}</section>')


def comp_listcard(t: dict, items: list) -> str:
    """条目列表卡：`标题 | 说明` 两层结构（橄榄手记组件24 跨主题版）。"""
    rows = []
    for it in items:
        if not it.strip():
            continue
        title, has, desc = it.partition("|")
        dpart = (f'<p style="font-size:12px;color:{t["part"]};line-height:1.7;margin:2px 0 0;">'
                 f'<span leaf="">{inline(t, desc.strip())}</span></p>') if has and desc.strip() else ""
        rows.append(f'<section style="background:{t["card"]};border:1px solid {t["divider"]};'
                    f'border-radius:{t["radius"]}px;padding:10px 14px;margin:0 0 8px;">'
                    f'<span style="font-size:14px;font-weight:700;color:{t["title"]};">'
                    f'<span leaf="">{esc(to_fw(title.strip()))}</span></span>{dpart}</section>')
    return f'<section style="margin:0 0 24px;">{"".join(rows)}</section>'


def comp_wall(t: dict, items: list) -> str:
    """信任墙：`数字 | 说明` 数据点（橄榄手记组件27 跨主题版）。"""
    cells = []
    for it in items:
        if not it.strip():
            continue
        num, _, label = it.partition("|")
        cells.append(
            f'<section style="display:inline-block;width:31%;vertical-align:top;'
            f'text-align:center;padding:10px 2px;margin:0 1% 8px;background:{t["cta_bg"]};'
            f'border-radius:{t["radius"]}px;">'
            f'<p style="font-size:20px;font-weight:700;color:{t["accent"]};margin:0;">'
            f'<span leaf="">{esc(to_fw(num.strip()))}</span></p>'
            f'<p style="font-size:11px;color:{t["part"]};margin:2px 0 0;">'
            f'<span leaf="">{esc(to_fw(label.strip()))}</span></p></section>')
    return f'<section style="margin:0 0 24px;">{"".join(cells)}</section>'


def comp_summary(t: dict, lines: list) -> str:
    """结尾摘要横幅条（橄榄手记组件32 跨主题版）。"""
    body = "".join(
        f'<p style="font-size:13px;color:{t["body"]};line-height:1.8;margin:6px 0 0;">'
        f'<span style="color:{t["accent"]};font-weight:700;"><span leaf="">· </span></span>'
        f'<span leaf="">{inline(t, x)}</span></p>'
        for x in lines if x.strip())
    return (f'<section style="background:{t["cta_bg"]};border:1px solid {t["cta_border"]};'
            f'border-radius:{t["radius"]}px;padding:14px 16px;margin:0 0 24px;">'
            f'{_fence_label(t, "本期要点")}{body}</section>')


def comp_tags(t: dict, items: list) -> str:
    """内容标签组：`TAG | 文本`（品牌绿组件7 STEP/CASE/SKILL/TOOL 跨主题版）。"""
    rows = []
    for it in items:
        if not it.strip():
            continue
        tag, _, txt = it.partition("|")
        rows.append(f'<p style="margin:0 0 8px;font-size:13px;color:{t["body"]};line-height:1.8;">'
                    f'<span style="display:inline-block;padding:1px 8px;background:{t["accent"]};'
                    f'color:{t["bg"]};font-size:10px;font-weight:700;letter-spacing:1px;'
                    f'border-radius:4px;margin-right:8px;">'
                    f'<span leaf="">{esc(tag.strip())}</span></span>'
                    f'<span leaf="">{inline(t, txt.strip())}</span></p>')
    return f'<section style="margin:0 0 24px;">{"".join(rows)}</section>'


_FENCE_TIP_KINDS = {"warn", "danger", "info"}


# ─────────────────────────────────────────────────────────────────────────────
# 工单3后半场（2026-10-16）：主题签名组件菜单
# 背景：comp_* 组件（hero/toc/note/point/quote/tip/steps/flow/timeline/faq/
# vs/ba/listcard/wall/summary/tags）本就存在，靠作者在 markdown 里手写
# `:::name` 触发；但①每套主题没有声明"我推荐哪些组件"②写作 prompt 从不教
# fence 语法 → 组件对 LLM 与用户都是死的。此处补两样：
#   THEME_COMPONENTS  每主题推荐组件子集（气质匹配，不是全量硬塞）
#   component_menu_block()  生成注入写作 prompt 的组件菜单文本
# 未知主题/空主题 → 返回全量菜单（不报错、零阻断）。
# ─────────────────────────────────────────────────────────────────────────────
THEME_COMPONENTS: dict[str, list[str]] = {
    "green":            ["hero", "toc", "point", "tip:info", "summary", "tags"],
    "shengyuan-earth":  ["hero", "quote", "timeline", "note", "tags"],
    "red-white":        ["hero", "point", "tip:warn", "summary", "tags"],
    "olive":            ["note", "point", "steps", "summary"],
    "guofeng-ink":      ["hero", "quote", "timeline", "note"],
    "mint-handbook":    ["steps", "flow", "faq", "tip:info", "note"],
    "morandi":          ["quote", "note", "point", "timeline"],
    "stripe-silicon":   ["vs", "ba", "flow", "steps", "faq"],
    "claude-oat":       ["note", "tip:info", "point", "quote"],
    "nyt-editorial":    ["hero", "toc", "quote", "point", "timeline"],
    "bauhaus-bold":     ["point", "vs", "flow", "hero"],
    "warm-sun":         ["hero", "quote", "tip:info", "summary"],
    "ocean-deep":       ["hero", "point", "note", "timeline"],
    "moyu-ticket":      ["steps", "ba", "faq", "tip:warn"],
    "graphite-minimal": ["point", "note", "faq", "summary"],
    "zen-whitespace":   ["quote", "note", "timeline"],
    "news-pop":         ["hero", "tags", "summary", "point", "tip:info"],
    "project-intro":    ["vs", "flow", "faq", "point", "steps"],
}

def comp_step(t: dict, items: list) -> str:
    """STEP 步骤标签组（skill 主题库 7a）：实色 STEP 标签 + 步骤标题 + 可选说明。

    1.0.80 新增——软件原来只有 `:::steps` 的序号药丸、没有 skill 的 STEP 实色标签，
    教程/清单类文章少了这个就成不了「手把手」的节奏感。
    """
    rows = []
    for i, it in enumerate(items, 1):
        if not it.strip():
            continue
        title, has, desc = it.partition("|")
        dpart = (f'<p style="font-size:13px;color:{t["body"]};line-height:1.8;margin:5px 0 0;">'
                 f'{inline(t, desc.strip())}</p>') if has and desc.strip() else ""
        rows.append(
            f'<section style="margin:0 0 12px;">'
            f'<span style="display:inline-block;background:{t["accent"]};color:#ffffff;'
            f'font-size:10px;font-weight:800;padding:2px 8px;letter-spacing:1px;'
            f'border-radius:2px;vertical-align:middle;margin-right:8px;">'
            f'<span leaf="">STEP {i:02d}</span></span>'
            f'<span style="font-size:14px;font-weight:700;color:{t["title"]};'
            f'vertical-align:middle;"><span leaf="">{esc(to_fw(title.strip()))}</span></span>'
            f'{dpart}</section>')
    return f'<section style="margin:0 0 24px;">{"".join(rows)}</section>'


def comp_case(t: dict, args: str, items: list) -> str:
    """CASE 案例卡（skill 主题库 7b）：CASE 标签 + 案例名 + 导语 + 案例正文。"""
    name, _, lead = args.partition("|")
    head = (f'<span style="display:inline-block;background:{t["card"]};color:{t["accent"]};'
            f'border:1px solid {t["accent"]};font-size:10px;font-weight:800;padding:2px 8px;'
            f'letter-spacing:1px;border-radius:2px;vertical-align:middle;margin-right:8px;">'
            f'<span leaf="">CASE</span></span>')
    name_html = (f'<span style="font-size:15px;font-weight:700;color:{t["title"]};'
                 f'vertical-align:middle;"><span leaf="">{esc(to_fw(name.strip()))}</span></span>')
    lead_html = (f'<p style="font-size:12px;color:{t["part"]};margin:6px 0 0;line-height:1.7;">'
                 f'{inline(t, lead.strip())}</p>') if lead.strip() else ""
    body = "".join(paragraph(t, inline(t, x)) for x in items if x.strip())
    return (f'<section style="background:{t["card"]};border-left:4px solid {t["accent"]};'
            f'border-radius:0 {t["radius"]}px {t["radius"]}px 0;padding:14px 16px;margin:0 0 24px;">'
            f'<section>{head}{name_html}</section>{lead_html}'
            f'<section style="margin-top:8px;">{body}</section></section>')


def comp_cols(t: dict, items: list) -> str:
    """三列对比卡（skill 主题库 11c）：每行 `左 | 中 | 右`，首行作表头。

    1.0.80 新增——原 `:::vs` 只支持左右两列，工具横评/方案对比常要三列。
    """
    rows = []
    for i, it in enumerate(items):
        if not it.strip():
            continue
        cells = [c.strip() for c in it.split("|")]
        while len(cells) < 3:
            cells.append("")
        cells = cells[:3]
        is_head = (i == 0)
        tds = "".join(
            f'<section style="display:inline-block;width:32%;vertical-align:top;'
            f'padding:8px 2px;text-align:center;">'
            f'<span style="font-size:{12 if is_head else 13}px;'
            f'font-weight:{700 if is_head else 400};'
            f'color:{t["title"] if is_head else t["body"]};line-height:1.6;">'
            f'<span leaf="">{esc(to_fw(c))}</span></span></section>'
            for c in cells)
        rows.append(
            f'<section style="margin:0;padding:2px 0;'
            f'background:{t["cta_bg"] if is_head else "transparent"};'
            f'border-bottom:1px solid {t["divider"]};">{tds}</section>')
    return (f'<section style="border:1px solid {t["border"]};border-radius:{t["radius"]}px;'
            f'padding:4px 6px;margin:0 0 24px;">{"".join(rows)}</section>')


def comp_tool(t: dict, args: str, items: list) -> str:
    """工具说明卡（skill 主题库 11e）：工具名 + 一句话定位 + 要点行。"""
    name, _, pos = args.partition("|")
    pos_html = (f'<p style="font-size:12px;color:{t["part"]};margin:3px 0 0;line-height:1.6;">'
                f'<span leaf="">{esc(to_fw(pos.strip()))}</span></p>') if pos.strip() else ""
    pts = "".join(
        f'<p style="font-size:13px;color:{t["body"]};line-height:1.8;margin:6px 0 0;">'
        f'<span style="color:{t["accent"]};font-weight:700;"><span leaf="">·</span></span> '
        f'{inline(t, x)}</p>'
        for x in items if x.strip())
    return (f'<section style="border:1px solid {t["border"]};border-radius:{t["radius"]}px;'
            f'padding:14px 16px;margin:0 0 24px;background:{t["card"]};">'
            f'<span style="font-size:16px;font-weight:800;color:{t["title"]};">'
            f'<span leaf="">{esc(to_fw(name.strip()))}</span></span>{pos_html}{pts}</section>')


def comp_brand(t: dict, args: str, items: list) -> str:
    who, _, bio = args.partition("|")
    who_html = (f'<p style="margin:0;font-size:13px;font-weight:700;color:{t["title"]};">'
                f'<span leaf="">{esc(to_fw(who.strip()))}</span></p>') if who.strip() else ""
    bio_html = (f'<p style="margin:4px 0 0;font-size:12px;color:{t["part"]};line-height:1.7;">'
                f'<span leaf="">{esc(to_fw(bio.strip()))}</span></p>') if bio.strip() else ""
    cta = "".join(
        f'<p style="margin:6px 0 0;font-size:12px;color:{t["body"]};line-height:1.8;">'
        f'{inline(t, x)}</p>'
        for x in items if x.strip())
    return (f'<section style="margin:28px 0 0;padding:18px 20px;background:{t["cta_bg"]};'
            f'border-top:2px solid {t["accent"]};border-radius:{t["radius"]}px;">'
            f'{who_html}{bio_html}{cta}</section>')


# 全量组件菜单（未知主题时用；也是 THEME_COMPONENTS 各值的合法性来源）
ALL_COMPONENTS: list[str] = [
    "hero", "toc", "note", "point", "quote", "tip:info", "tip:warn", "tip:danger",
    "steps", "flow", "timeline", "faq", "vs", "ba", "listcard", "wall",
    "summary", "tags",
    # 1.0.80 新增（对齐 skill 主题库 7a/7b/11c/11e/13b）
    "step", "case", "cols", "tool", "brand",
]


def theme_components(theme_key: str) -> list[str]:
    """该主题推荐的 fence 组件子集；未知主题回落全量。"""
    return list(THEME_COMPONENTS.get(theme_key or "") or ALL_COMPONENTS)


def component_menu_block(theme_key: str) -> str:
    """生成注入写作 prompt 的「主题组件菜单」文本。

    空 theme_key / 异常 → 返回全量菜单（绝不返回空字符串阻断链路）。
    用法（markdown 里）：
        :::hero 主标题 | 副标题
        :::point 小标题 | 补充说明
        :::tip:info
        要点行…
    """
    comps = theme_components(theme_key)
    names = "、".join(c.replace(":", "/") for c in comps)
    return (
        "【主题组件菜单】当前排版主题的签名组件（写正文时可用下列围栏语法插入，"
        "用不了的场合不要硬塞；每篇至多 4-6 个，穿插在章节之间）：\n"
        f"  :::hero 主标题 | 副标题\n"
        f"  :::toc\n  - 目录项（每行一条）\n"
        f"  :::note\n  - 便签行（每行一条）\n"
        f"  :::point 小标题 | 一句补充\n  - 要点行\n"
        f"  :::quote 一句金句（或把金句放围栏体里）\n"
        f"  :::tip:info / :::tip:warn / :::tip:danger\n  - 提示行\n"
        f"  :::steps\n  - 步骤行（有序）\n"
        f"  :::flow\n  - 流程节点（每行一个，用 > 连接）\n"
        f"  :::timeline\n  - 时间节点（每行一个）\n"
        f"  :::faq\n  Q：问题\n  A：回答\n"
        f"  :::vs 左侧 | 右侧\n  - 对比行\n"
        f"  :::ba 改前 | 改后 | 一句说明\n  - 补充行\n"
        f"  :::listcard / :::wall / :::summary / :::tags\n  - 清单行\n"
        f"  :::step\n  - 步骤标题 | 说明（每行一个步骤，自动编 STEP 01/02…，教程/清单用）\n"
        f"  :::case 案例名 | 一句导语\n  - 案例正文行\n"
        f"  :::cols\n  - 左 | 中 | 右（首行作表头，三列对比）\n"
        f"  :::tool 工具名 | 一句话定位\n  - 要点行（工具说明卡）\n"
        f"  :::brand 署名 | 一句简介\n  - 互动引导行（品牌尾卡）\n"
        f"  行内强调（正文里用，务必穿插）：**加粗** / ==高亮== / ++下划线++ /"
        f" $$红色下划线·对比否定$$ / %%荧光笔%% / @@主色重音@@ / ~~删除线~~\n"
        f"本主题（{theme_key or '默认'}）推荐优先使用：{names}。"
    )


def render_fence(t: dict, name: str, args: str, body: list,
                 fn_buf: list | None = None) -> str:
    """::: 围栏分发器。未知组件名优雅降级为普通段落（绝不丢内容）。"""
    name = (name or "").strip().lower()
    lines = [x.strip() for x in body if x.strip()]
    if name == "hero":
        title, _, sub = args.partition("|")
        return comp_hero(t, title.strip(), sub.strip())
    if name == "toc":
        return comp_toc(t, [x.lstrip("-*0123456789.、 ").strip() for x in lines])
    if name == "note":
        return comp_note(t, lines)
    if name == "point":
        title, _, rest = args.partition("|")
        extra = [rest.strip()] if rest.strip() else []
        return comp_point(t, title.strip(), extra + lines)
    if name == "quote":
        return comp_quote_gold(t, args.strip() or (lines[0] if lines else ""))
    if name in _FENCE_TIP_KINDS:
        extra = [args.strip()] if args.strip() else []
        return comp_tip(t, name, extra + lines)
    if name == "steps":
        return comp_steps(t, lines)
    if name == "flow":
        return comp_flow(t, lines)
    if name == "timeline":
        return comp_timeline(t, lines)
    if name == "faq":
        return comp_faq(t, lines)
    if name == "vs":
        left, _, right = args.partition("|")
        return comp_vs(t, left, right)
    if name == "ba":
        parts = args.split("|")
        old = parts[0] if parts else ""
        new = parts[1] if len(parts) > 1 else ""
        note = parts[2] if len(parts) > 2 else ""
        return comp_ba(t, old, new, note)
    if name == "listcard":
        return comp_listcard(t, lines)
    if name == "wall":
        return comp_wall(t, lines)
    if name == "summary":
        return comp_summary(t, lines)
    if name == "tags":
        return comp_tags(t, lines)
    # 1.0.80 新增组件（对齐 skill 主题库 7a/7b/11c/11e/13b）
    if name == "step":
        return comp_step(t, lines)
    if name == "case":
        return comp_case(t, args.strip(), lines)
    if name == "cols":
        return comp_cols(t, lines)
    if name == "tool":
        return comp_tool(t, args.strip(), lines)
    if name == "brand":
        return comp_brand(t, args.strip(), lines)
    # 未知组件：按普通段落渲染（内容零丢失）
    return "".join(paragraph(t, inline(t, x, fn_buf)) for x in lines)


def parse(markdown: str) -> tuple[str, list[str], list]:
    """吃 markdown 字符串（源版本吃文件路径）。

    返回 (title, intro_lines, blocks)。blocks 元素为 [章节中文名, _unused, 正文行]。

    与源版本的行为差异：**不再把首行当 byline 吞掉**。
    源版本只要首行含「｜」就整行剥离，而「AI工具测评｜第 3 期」这类正常首行
    会被静默删除 —— 这是内容丢失。byline 现在只由 render() 的参数提供。
    """
    lines = markdown.replace("\r\n", "\n").replace("\r", "\n").split("\n")

    # H1 主标题：解析出来但不渲染（公众号标题在后台单独填，正文重复出现是冗余）。
    title = ""
    for i, l in enumerate(lines):
        if l.startswith("# "):
            title = l[2:].strip()
            lines[i] = ""
            break

    blocks: list = []
    cur = None
    intro: list[str] = []
    for l in lines:
        m = _H2_NUMBERED_RE.match(l)
        if m:
            if cur:
                blocks.append(cur)
            cur = [m.group(1).strip(), [], []]
        elif l.startswith("## "):
            if cur:
                blocks.append(cur)
            cur = [l[3:].strip(), [], []]
        else:
            if cur is None:
                intro.append(l)
            else:
                cur[2].append(l)
    if cur:
        blocks.append(cur)
    return title, intro, blocks


def _is_author_line(s: str) -> bool:
    """这行是不是「作者自我介绍/署名行」（文末上浮用）。

    🔴 1.0.80 去 IP 硬编码：旧实现把某个博主的名字写死在判定里，
       等于把私人口癖固化进全体用户的导出稿。现在只看**句式**：
       「我是 + 1~8 字的称呼 / 称呼+一句话身份」，整行 ≤40 字。
       普通正文里「我是说这个方案还有很多细节…」这类长句不会被误伤
       （称呼段超过 8 字就不认）。
    """
    x = (s or "").strip()
    if not x or len(x) > 40:
        return False
    return bool(_AUTHOR_LINE_RE.match(x))


def render_block_body(t: dict, lines: list[str], signature_buf: list[str],
                      fn_buf: list | None = None) -> str:
    html: list[str] = []
    list_buf: list[str] = []
    ul_buf: list[str] = []
    in_code: bool = False
    code_buf: list[str] = []
    skip_until: int = -1  # 表格已消费的行号上界（enumerate 需跳过）

    def flush_list():
        nonlocal list_buf
        if list_buf:
            html.append(ordered_list(t, list_buf, fn_buf))
            list_buf = []

    def flush_ul():
        nonlocal ul_buf
        if ul_buf:
            html.append(unordered_list(t, ul_buf, fn_buf))
            ul_buf = []

    def flush_code():
        nonlocal code_buf
        if code_buf:
            html.append(code_block(t, "\n".join(code_buf)))
            code_buf = []

    for idx, l in enumerate(lines):
        if idx <= skip_until:
            continue
        s = l.strip()
        # 围栏代码块（``` 起止，语言标识行被丢弃）
        if s.startswith("```"):
            if in_code:
                in_code = False
                flush_code()
            else:
                flush_list(); flush_ul()
                in_code = True
                code_buf = []
            continue
        if in_code:
            code_buf.append(l)
            continue
        if not s:
            flush_list(); flush_ul()
            continue
        # 批10b·需求3：::: 组件围栏（`:::名 参数` … `:::` 闭合；未闭合消费到末尾）
        if s.startswith(":::"):
            flush_list(); flush_ul()
            if s == ":::":
                continue  # 游离闭合符，跳过
            fname, _, fargs = s[3:].strip().partition(" ")
            j = idx + 1
            fbody = []
            while j < len(lines) and lines[j].strip() != ":::":
                fbody.append(lines[j].strip())
                j += 1
            skip_until = j  # 连闭合符一起消费（未闭合则消费到末尾）
            html.append(render_fence(t, fname, fargs.strip(), fbody, fn_buf))
            continue
        # 作者签名行上浮到全文末尾（保留源行为）
        # 🔴 1.0.80：原来写死 `我是 孔不惑` —— 那是作者本人的口癖，属于把私人 IP 固化进
        #    全体用户导出稿的模板。改为通用判定：任何以「我是」开头的独立短行都视为作者
        #    自我介绍行 → 上浮到文末，不再绑定某个具体人名。
        if _is_author_line(s):
            flush_list(); flush_ul()
            signature_buf.append(s)
            continue
        if s in signature_buf:
            continue
        m_img = _IMG_RE.match(s)
        if m_img:
            flush_list(); flush_ul()
            html.append(image_embed(t, m_img.group(3), m_img.group(1), m_img.group(2) or ""))
            continue
        # Markdown 表格：首行表头 + 次行分隔行（须含 -）才视为表格；
        # 单行含 | 无分隔行 → 落段落原文（与 doocs/md 行为一致）。
        if (_TABLE_ROW_RE.match(s) and idx + 1 < len(lines)
                and _TABLE_SEP_RE.match(lines[idx + 1].strip())):
            flush_list(); flush_ul()
            header = _split_table_row(s)
            aligns = [_cell_align(c) for c in _split_table_row(lines[idx + 1].strip())]
            rows = [header]
            j = idx + 2
            while j < len(lines) and _TABLE_ROW_RE.match(lines[j].strip()):
                rows.append(_split_table_row(lines[j].strip()))
                j += 1
            html.append(render_table(t, rows, aligns, fn_buf))
            skip_until = j - 1
            continue
        m_cap = _CAPTION_RE.match(s)
        if m_cap:
            flush_list(); flush_ul()
            html.append(caption(t, m_cap.group(1)))
            continue
        if s.startswith("【"):
            flush_list(); flush_ul()
            if "封面" in s:
                html.append("__COVER__")
            else:
                html.append(placeholder(t, s.strip("【】")))
            continue
        if s.startswith(">"):
            flush_list(); flush_ul()
            html.append(quote_box(t, inline(t, s[1:].strip(), fn_buf)))
            continue
        if s.startswith("### "):
            flush_list(); flush_ul()
            html.append(h3_title(t, s[3:].strip()))
            continue
        if _OL_RE.match(s):
            flush_ul()
            list_buf.append(_OL_RE.sub("", s))
            continue
        if _UL_RE.match(s):
            flush_list()
            ul_buf.append(_UL_RE.sub("", s))
            continue
        flush_list(); flush_ul()
        html.append(paragraph(t, inline(t, s, fn_buf)))
    flush_list(); flush_ul()
    if in_code:
        flush_code()
    return "".join(html)


# ---------- 组装 ----------

def render(markdown: str, theme_key: str = DEFAULT_THEME,
           byline: str = "", cover_src: str = "",
           footer_cta_enabled: bool | None = None,
           ip: dict | None = None) -> str:
    """Markdown 字符串 → 公众号可直接粘贴的 HTML 字符串。

    纯函数：无全局状态，可并发调用。theme_key 未知时回落 "green"。
    byline 为空则不渲染署名行；cover_src 为空则不渲染封面；
    footer_cta_enabled=None 时取 FOOTER_CTA_DEFAULT（默认关，不塞「点赞在看转发」互动块）。

    ip（1.0.80）：用户自定义 IP 内容，形如
        {"name":"不惑","tagline":"陪你一起搭建人生资产","intro":"…","cta":"…",
         "inject_signature":True,"inject_card":True,"inject_cta":True}
    空 / None → 不注入任何作者痕迹（模板保持中性）。见 normalize_ip()。

    🔴 形参必须叫 footer_cta_enabled 而不是 footer_cta：会和本文件里的
    footer_cta() 函数同名 → 形参遮蔽函数 → `footer_cta(t, True)` 变成 `True(t, True)`
    抛 TypeError: 'bool' object is not callable（2026-10-01 实测踩到，导出 500）。
    """
    t = dict(get_theme(theme_key))
    t["key"] = theme_key   # 段落/强调变体表按 key 取（2026-10-20 工单⑩）
    _ip = normalize_ip(ip)
    _title, intro, blocks = parse(markdown or "")

    # 脚注 buffer：render 局部新建（仿 signature_buf 先例），并发安全。
    # 外链在 inline() 中降级为 <sup>[N]</sup> 并收集到这里，文末拼 References。
    fn_buf: list = []

    inner: list[str] = []
    if byline:
        inner.append(byline_line(t, byline))
    if cover_src:
        inner.append(cover_image(t, cover_src))

    sig: list[str] = []
    if intro:
        inner.append(render_block_body(t, intro, sig, fn_buf))

    n = len(blocks)
    for i, (cn, _unused, body) in enumerate(blocks):
        # F-5 修复：只有 1 个章节时（n==1）唯一章节是"正文"而非"结尾章"，
        # 编号应显示 01 而非 ///；多章时末章才用 /// + ACTION 收尾。
        num = "///" if i == n - 1 and n > 1 else f"{i + 1:02d}"
        en_lbl = ("ACTION" if i == n - 1 and n > 1
                  else (EN_LABELS[i + 1] if i + 1 < len(EN_LABELS) else f"PART {i + 1}"))
        inner.append(chapter_title(t, num, cn, en_lbl))
        b = render_block_body(t, body, sig, fn_buf)
        b = b.replace("__COVER__", "", 1)
        inner.append(b)

    if footer_cta_enabled is None:
        footer_cta_enabled = FOOTER_CTA_DEFAULT
    for s in sig:
        inner.append(paragraph(t, inline(t, s, fn_buf)))
    # ── 用户自定义 IP 植入（1.0.80）──
    # 顺序对齐参考文的真实收尾：署名行 → IP 卡（称呼+身份+简介）→ 互动三连。
    # 三块都只在用户填了内容 + 对应开关打开时才出现，空 IP 一个字都不加。
    if _ip["has_identity"]:
        if _ip["inject_signature"] and _ip["signature"] and not sig:
            inner.append(paragraph(t, inline(t, _ip["signature"], fn_buf)))
        if _ip["inject_card"]:
            _card = ip_card(t, _ip)
            if _card:
                inner.append(_card)
    if footer_cta_enabled:
        inner.append(footer_cta(t, True, _ip.get("cta") or ""))

    # 文末 References 块：外链降级脚注的归宿（对标 doocs/md buildFootnoteArray）
    if fn_buf:
        refs = [f'<section style="border-top:1px solid {t["border"]};'
                f'margin:24px 0 0;padding-top:12px;">']
        for n_i, (rtxt, rurl) in enumerate(fn_buf, 1):
            refs.append(
                f'<p style="font-size:12px;color:{t["en"]};margin:4px 0;'
                f'line-height:1.6;word-break:break-all;">'
                f'<span leaf="">[{n_i}] {esc(rtxt)}：</span>'
                f'<span leaf="">{esc(rurl)}</span></p>')
        refs.append("</section>")
        inner.append("".join(refs))

    # ── 正文纯白无装饰（2026-10-05 导演拍板，参考其公众号《WorkBuddy 新增的匿名大模型…》）──
    # 参考文实测规律：正文 15px/line-height 1.9/justify/color #425466，**正文区完全不铺底色**；
    # 深藏青 #1A1A2E 底 + 白字只出现在小面积重点块上（padding 8px 20px），引文用 border-left 竖线。
    # 于是「背景干净」= ①外层不铺底色 ②强调块/引用块原样保留（它们自带底色+浅字，是点缀不是背景）。
    #
    # 🔴 关键坑：不能只删 background。深底主题（cyberpunk 紫黑 / magazine-noir 墨黑）的
    # body 字色是为深底设计的**浅色**，删掉外层底色后正文就成「白底浅字」——整篇看不见。
    # 所以这里额外做一次可读性兜底：仅当 body 是浅色时，把**外层**字色换成深蓝灰；
    # 内层强调块继续用原 t["body"]（它们有深底，浅字是对的，一概不动）。
    # 字体/字号/行高/强调块一律保持各主题原样 —— 导演要求「字体参数根据文章风格来定」。
    outer_body = t["body"] if not _is_light_color(t.get("body", "")) else BODY_ON_WHITE
    full = (f'<section style="max-width:677px;margin:0 auto;'
            f'font-family:{font_stack(t)};color:{outer_body};line-height:1.75;'
            f'letter-spacing:0.5px;overflow-x:hidden;">'
            f'{"".join(inner)}</section>')
    full = re.sub(r'<section></section>', '', full)
    full = full.replace("__COVER__", "")
    return full
