# -*- coding: utf-8 -*-
r"""排版三件套（2026-10-16）：图位语义锚点 / 导演填留白块 / 双版本输出。

背景（导演原话）
  排版引擎只覆盖了手写脚本约 40%，缺三样就还得靠人手改：
    ① 图位语义锚点  —— 图该插在哪，正文里得有"语义位置"，不能靠人眼数段落
    ② 【导演填｜XX】 —— 写到一半留的占位，排版时要看得见（提醒还没填），
                        但发布时必须整块剔除（占位发到公众号 = 事故）
    ③ 双版本输出    —— 常规版（保留占位，继续写）+ 发布版（占位已剔，可直接粘贴）

作者写法（Markdown 里直接写，零学习成本）
    图位：   [[图位]]                 或  [[图位|开头情绪图]]
    导演填： 【导演填｜真实案例】      或  【导演填|一句话金句】
    （全半角竖线都认；图位会自动编号）

🔴 纪律
  - 纯函数，不改 themes14.render 一行代码：本模块只做**渲染前预处理** + 清单提取。
  - 发布版剔除是**整行整块**剔除，绝不留下半截空行（宁可少一行，不留空格子）。
  - 图位编号按**出现顺序**稳定，生图回填时靠 id 定位，不靠行号（行号会飘）。
"""
from __future__ import annotations

import re
from typing import Any, Dict, List

# [[图位]] / [[图位|说明]] / [[图位：说明]]
_IMG = re.compile(r"\[\[\s*图位\s*(?:[|｜:：]\s*([^\]]*?))?\s*\]\]")
# 【导演填｜XX】 / 【导演填|XX】
_DIR = re.compile(r"【\s*导演填\s*[|｜:：]\s*([^】]*?)\s*】")

_ANCHOR = "awslot"   # 锚点 id 前缀（生图回填用）


def image_slots(markdown: str) -> List[Dict[str, Any]]:
    """提取图位清单：序号 / 说明 / 锚点 id / 上下文（前后各取 40 字）。

    给生图用：知道"第 3 张图应该表现什么、插在哪句话后面"。
    """
    md = markdown or ""
    out: List[Dict[str, Any]] = []
    for i, m in enumerate(_IMG.finditer(md), 1):
        note = (m.group(1) or "").strip()
        before = md[max(0, m.start() - 40):m.start()].replace("\n", " ")
        after = md[m.end():m.end() + 40].replace("\n", " ")
        out.append({
            "id": f"{_ANCHOR}-{i}",
            "index": i,
            "note": note,
            "hint": note or f"第 {i} 张配图",
            "context_before": before.strip(),
            "context_after": after.strip(),
            "pos": m.start(),
        })
    return out


def director_slots(markdown: str) -> List[Dict[str, Any]]:
    """提取【导演填｜XX】占位清单（写作时用，发布前必须清掉）。"""
    md = markdown or ""
    return [{"index": i, "what": (m.group(1) or "").strip(), "pos": m.start()}
            for i, m in enumerate(_DIR.finditer(md), 1)]


def _img_block(note: str, idx: int) -> str:
    """常规版：图位渲染成看得见的占位提示（引用块，醒目但不抢戏）。"""
    txt = note or f"第 {idx} 张配图"
    return f"> 🖼 **图位 {idx}** · {txt}\n>\n> _（生图后自动替换成图片；发布版会剔除这一块）_"


def _dir_block(what: str) -> str:
    """常规版：导演填渲染成留白块（提醒作者这里还没填）。"""
    return f"> ✍️ **待填：{what}**\n>\n> _（发布版会自动剔除这一块，占位不会带到公众号）_"


def prepare(markdown: str, publish: bool = False) -> str:
    """渲染前预处理。

    publish=False → 常规版：图位/导演填都渲染成可见占位块（继续写稿用）
    publish=True  → 发布版：图位/导演填**整块剔除**（可直接粘贴公众号）
    """
    md = markdown or ""
    if publish:
        md = _IMG.sub("", md)
        md = _DIR.sub("", md)
        # 剔除后可能留下连续空行 —— 压成最多一个空行，但不并段
        md = re.sub(r"\n{3,}", "\n\n", md)
        return md.strip()

    n = {"i": 0}

    def _rimg(m: re.Match) -> str:
        n["i"] += 1
        return _img_block((m.group(1) or "").strip(), n["i"])

    md = _IMG.sub(_rimg, md)
    md = _DIR.sub(lambda m: _dir_block((m.group(1) or "").strip()), md)
    return md


def summary(markdown: str) -> Dict[str, Any]:
    """给前端用的一次性概览：有几张图位、几个待填、发布版会剔除多少块。"""
    imgs = image_slots(markdown)
    dirs = director_slots(markdown)
    return {
        "image_slots": imgs,
        "director_slots": dirs,
        "image_count": len(imgs),
        "director_count": len(dirs),
        "publish_will_drop": len(imgs) + len(dirs),
        "publish_ready": len(dirs) == 0,   # 还有【导演填】= 不建议直接发
    }


def render_two(markdown: str, renderer, **kw) -> Dict[str, Any]:
    """双版本输出：常规版（占位可见）+ 发布版（占位已剔）。

    renderer=themes14.render 这类 `md -> html` 的可调用对象。
    """
    normal = renderer(prepare(markdown, publish=False), **kw)
    publish = renderer(prepare(markdown, publish=True), **kw)
    return {"normal": normal, "publish": publish, **summary(markdown)}


if __name__ == "__main__":   # 自测
    md = """# 标题

第一段正文。

[[图位|开头情绪图]]

第二段正文。

【导演填｜一个真实案例】

结尾。
"""
    s = summary(md)
    assert s["image_count"] == 1 and s["director_count"] == 1, s
    assert s["publish_ready"] is False
    pub = prepare(md, publish=True)
    assert "图位" not in pub and "导演填" not in pub, pub
    norm = prepare(md, publish=False)
    assert "图位 1" in norm and "待填：一个真实案例" in norm, norm
    print("OK", s["image_count"], s["director_count"])
