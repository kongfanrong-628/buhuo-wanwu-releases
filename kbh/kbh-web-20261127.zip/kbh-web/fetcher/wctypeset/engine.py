"""
排版引擎：Markdown → inline-style 公众号 HTML。
核心壁垒——输出 inline-style HTML，禁 class/外链 CSS。
6 套模板，每套有独立布局风格 + 配色方案。
"""

import re

from .colors import ColorScheme, get_scheme
from .theme_map import primary_theme

# 有序列表匹配：支持 "1. " "1) " "10. " 等格式
_ORDERED_RE = re.compile(r'^(\d+)[.)]\s+(.+)')


# ─── 模板配置：每套模板 = 配色 + 布局参数 ───
TEMPLATE_CONFIG = {
    "杂志深读风": {
        "color": "松绿+墨黑配色",
        "desc": "知识/科技赛道，左竖线标题，大留白，沉稳专业",
        "h2_align": "left",
        "h2_border": "left",       # left | bottom | none | bg
        "h2_bg": "",
        "p_indent": False,
        "blockquote_style": "border",  # border | bg | quote-mark
        "divider": "line",        # line | dots | none
        "title_align": "left",
        "section_num": False,
    },
    "红白表态风": {
        "color": "珊瑚橘+暖灰配色",
        "desc": "观点/热点赛道，色块标题，强烈态度感",
        "h2_align": "left",
        "h2_border": "bg",
        "h2_bg": "primary",
        "p_indent": False,
        "blockquote_style": "bg",
        "divider": "dots",
        "title_align": "center",
        "section_num": False,
    },
    "橄榄叙事风": {
        "color": "焦糖+墨绿配色",
        "desc": "深度/叙事赛道，衬线感，首行缩进，文学气质",
        "h2_align": "center",
        "h2_border": "bottom",
        "h2_bg": "",
        "p_indent": True,
        "blockquote_style": "quote-mark",
        "divider": "line",
        "title_align": "center",
        "section_num": False,
    },
    "摸鱼绿工具风": {
        "color": "晨雾+靛青配色",
        "desc": "工具/教程赛道，卡片分块，步骤编号，清爽高效",
        "h2_align": "left",
        "h2_border": "none",
        "h2_bg": "accent",
        "p_indent": False,
        "blockquote_style": "bg",
        "divider": "none",
        "title_align": "left",
        "section_num": True,
    },
    "黛紫手帐风": {
        "color": "黛紫+银白配色",
        "desc": "品牌/情感赛道，圆润装饰，柔和色调，手帐感",
        "h2_align": "left",
        "h2_border": "left",
        "h2_bg": "",
        "p_indent": False,
        "blockquote_style": "bg",
        "divider": "dots",
        "title_align": "center",
        "section_num": False,
    },
    "雾蓝商务风": {
        "color": "雾蓝+月白配色",
        "desc": "商业/数据赛道，极简线条，专业克制",
        "h2_align": "left",
        "h2_border": "bottom",
        "h2_bg": "",
        "p_indent": False,
        "blockquote_style": "border",
        "divider": "line",
        "title_align": "left",
        "section_num": False,
    },
}

TEMPLATE_NAMES = list(TEMPLATE_CONFIG.keys())

# 兼容旧映射
SKELETON_TEMPLATE_MAP = {
    "A": {"template": "杂志深读风", "color": "松绿+墨黑配色"},
    "B": {"template": "红白表态风", "color": "珊瑚橘+暖灰配色"},
    "C": {"template": "摸鱼绿工具风", "color": "晨雾+靛青配色"},
    "D": {"template": "黛紫手帐风", "color": "黛紫+银白配色"},
    "quick": {"template": "雾蓝商务风", "color": "雾蓝+月白配色"},
}


def get_recommended(skeleton: str, domain: str | None = None) -> dict:
    """根据骨架返回推荐模板和配色。

    若传入 domain 且命中「题材→主题」映射（theme_map.primary_theme），
    额外返回命中主题键（theme 字段），供前端排版面板高亮/自动选中。
    模板层与主题层正交，模板仍按骨架取。
    """
    base = SKELETON_TEMPLATE_MAP.get(skeleton, SKELETON_TEMPLATE_MAP["A"])
    rec = primary_theme(domain)
    if rec:
        return {**base, "theme": rec}
    return base


def list_templates() -> list[dict]:
    """列出所有模板（供前端展示）。"""
    return [
        {"name": name, "desc": cfg["desc"], "color": cfg["color"]}
        for name, cfg in TEMPLATE_CONFIG.items()
    ]


# ── 已退役（2026-08-03 决策，见 oss-bench-typeset-2026-08-03.md）──
# article 路径已全部切换到 themes14 新引擎（main.py api_export_html）。
# render_html/_inline 输出 <div> 违反自家 compliance.py:20 ERROR 规则、
# 无 <span leaf=""> 包裹、_inline() 不转义 —— 老引擎产物过不了自家合规门禁。
# 保留仅因 sticker/comic 仍经 TEMPLATE_CONFIG 取配色；待其迁移后整体移 _archive。
def render_html(
    markdown_content: str,
    template_name: str = "杂志深读风",
    color_scheme_name: str = "",
    title: str = "",
) -> str:
    """
    将 Markdown 正文渲染为公众号兼容的 inline-style HTML。
    注意：此函数已不再被任何活跃调用方引用（article 路径已退役）。
    所有样式内联，无 class、无外链 CSS、无 <style> 块，可直接粘贴到公众号编辑器。
    template_name 决定布局风格 + 配色（若 color_scheme_name 为空则自动跟随模板）。
    """
    cfg = TEMPLATE_CONFIG.get(template_name, TEMPLATE_CONFIG["杂志深读风"])
    scheme_name = color_scheme_name or cfg["color"]
    scheme = get_scheme(scheme_name) or get_scheme("松绿+墨黑配色")

    # ─── 根据模板配置生成各元素样式 ───
    body_style = (
        f"font-family:-apple-system,'PingFang SC','Microsoft YaHei',sans-serif;"
        f"font-size:15px;line-height:1.8;color:{scheme.text_color};"
        f"background:{scheme.bg_color};padding:0;margin:0;"
    )

    # H2 样式：根据 h2_border 配置
    if cfg["h2_border"] == "left":
        h2_style = (
            f"font-size:19px;font-weight:700;color:{scheme.secondary};"
            f"margin:32px 0 14px;padding-left:12px;"
            f"border-left:4px solid {scheme.primary};"
        )
    elif cfg["h2_border"] == "bottom":
        h2_style = (
            f"font-size:19px;font-weight:700;color:{scheme.secondary};"
            f"margin:32px 0 14px;padding-bottom:8px;"
            f"border-bottom:2px solid {scheme.primary};"
        )
    elif cfg["h2_border"] == "bg":
        bg_color = scheme.primary if cfg.get("h2_bg") == "primary" else scheme.accent
        text_color = "#FFFFFF" if cfg.get("h2_bg") == "primary" else scheme.secondary
        h2_style = (
            f"font-size:17px;font-weight:700;color:{text_color};"
            f"margin:28px 0 14px;padding:10px 16px;"
            f"background:{bg_color};border-radius:6px;"
        )
    else:  # none
        if cfg.get("h2_bg") == "accent":
            h2_style = (
                f"font-size:17px;font-weight:700;color:{scheme.secondary};"
                f"margin:28px 0 14px;padding:10px 16px;"
                f"background:{scheme.accent};border-radius:6px;"
            )
        else:
            h2_style = (
                f"font-size:19px;font-weight:700;color:{scheme.secondary};"
                f"margin:32px 0 14px;"
            )

    h3_style = (
        f"font-size:16px;font-weight:600;color:{scheme.primary};"
        f"margin:22px 0 8px;"
    )

    # 段落样式
    p_indent = "text-indent:2em;" if cfg["p_indent"] else ""
    p_style = f"margin:0 0 16px;color:{scheme.text_color};{p_indent}"

    strong_style = f"color:{scheme.primary};font-weight:700;"

    # 引用样式
    if cfg["blockquote_style"] == "border":
        blockquote_style = (
            f"margin:16px 0;padding:12px 16px;background:{scheme.accent};"
            f"border-left:4px solid {scheme.primary};border-radius:4px;"
            f"color:{scheme.text_color};font-size:14px;"
        )
    elif cfg["blockquote_style"] == "quote-mark":
        blockquote_style = (
            f"margin:16px 0;padding:16px 20px 16px 40px;background:{scheme.accent};"
            f"border-radius:8px;color:{scheme.text_color};font-size:14px;"
            f"position:relative;"
        )
    else:  # bg
        blockquote_style = (
            f"margin:16px 0;padding:14px 18px;background:{scheme.accent};"
            f"border-radius:8px;color:{scheme.text_color};font-size:14px;"
        )

    code_style = (
        f"background:{scheme.accent};color:{scheme.secondary};"
        f"padding:2px 6px;border-radius:3px;font-size:13px;"
        f"font-family:Menlo,Consolas,monospace;"
    )

    # 分割线样式
    if cfg["divider"] == "dots":
        hr_style = f"border:none;margin:28px auto;text-align:center;"
        hr_html = f'<p style="text-align:center;margin:28px 0;color:{scheme.primary};letter-spacing:8px;font-size:14px;">···</p>'
    elif cfg["divider"] == "line":
        hr_style = f"border:none;border-top:1px solid {scheme.accent};margin:28px 0;"
        hr_html = None
    else:
        hr_style = f"border:none;margin:20px 0;"
        hr_html = None

    # ─── 解析 Markdown ───
    lines = markdown_content.split("\n")
    html_parts = []
    section_counter = 0

    # 标题
    if title:
        title_align = cfg.get("title_align", "left")
        html_parts.append(
            f'<h1 style="font-size:22px;font-weight:800;color:{scheme.secondary};'
            f'margin:0 0 24px;text-align:{title_align};">{title}</h1>'
        )

    i = 0
    while i < len(lines):
        line = lines[i].rstrip()
        if not line.strip():
            i += 1
            continue

        # 标题
        if line.startswith("### "):
            html_parts.append(f'<h3 style="{h3_style}">{_inline(line[4:], scheme)}</h3>')
        elif line.startswith("## "):
            section_counter += 1
            heading_text = _inline(line[3:], scheme)
            if cfg.get("section_num"):
                heading_text = f'<span style="color:{scheme.primary};margin-right:6px;">{section_counter:02d}</span>{heading_text}'
            align = f"text-align:{cfg['h2_align']};" if cfg["h2_align"] != "left" else ""
            html_parts.append(f'<h2 style="{h2_style}{align}">{heading_text}</h2>')
        elif line.startswith("# "):
            section_counter += 1
            heading_text = _inline(line[2:], scheme)
            if cfg.get("section_num"):
                heading_text = f'<span style="color:{scheme.primary};margin-right:6px;">{section_counter:02d}</span>{heading_text}'
            align = f"text-align:{cfg['h2_align']};" if cfg["h2_align"] != "left" else ""
            html_parts.append(f'<h2 style="{h2_style}{align}">{heading_text}</h2>')
        # 分割线
        elif line.strip() in ("---", "***", "___"):
            if hr_html:
                html_parts.append(hr_html)
            else:
                html_parts.append(f'<hr style="{hr_style}">')
        # 引用
        elif line.startswith("> "):
            quote_text = _inline(line[2:], scheme)
            if cfg["blockquote_style"] == "quote-mark":
                html_parts.append(
                    f'<blockquote style="{blockquote_style}">'
                    f'<span style="position:absolute;left:14px;top:8px;font-size:28px;color:{scheme.primary};opacity:.4;">"</span>'
                    f'{quote_text}</blockquote>'
                )
            else:
                html_parts.append(f'<blockquote style="{blockquote_style}">{quote_text}</blockquote>')
        # 无序列表
        elif line.startswith("- ") or line.startswith("* "):
            items = []
            while i < len(lines) and (lines[i].startswith("- ") or lines[i].startswith("* ")):
                items.append(f'<li style="margin:6px 0;">{_inline(lines[i][2:].strip(), scheme)}</li>')
                i += 1
            html_parts.append(
                f'<ul style="padding-left:24px;margin:0 0 16px;color:{scheme.text_color};">{"".join(items)}</ul>'
            )
            continue
        # 有序列表
        elif _ORDERED_RE.match(line):
            items = []
            while i < len(lines):
                m = _ORDERED_RE.match(lines[i])
                if not m:
                    break
                items.append(f'<li style="margin:6px 0;">{_inline(m.group(2).strip(), scheme)}</li>')
                i += 1
            html_parts.append(
                f'<ol style="padding-left:24px;margin:0 0 16px;color:{scheme.text_color};">{"".join(items)}</ol>'
            )
            continue
        # 普通段落
        else:
            html_parts.append(f'<p style="{p_style}">{_inline(line, scheme)}</p>')

        i += 1

    content_html = "".join(html_parts)
    content_html = _add_image_gaps(content_html)
    return (
        f'<section style="{body_style}">'
        f'<div style="max-width:680px;margin:0 auto;padding:20px;">'
        f'{content_html}'
        f'</div></section>'
    )


def _add_image_gaps(html: str) -> str:
    """在相邻块级元素间插入可插图空白段（移植自「胜元公众号排版」add_image_gaps.py 意图）。

    公众号编辑器因嵌套 section 导致光标难定位、图片插不进。这里在相邻
    <h2>/<p>/<blockquote>/<ol>/<ul> 之间补 <p><br></p> 作插图缝，不影响合规
    （无 CJK 文本，不触发 LeafChecker 的 span leaf 包裹规则）。
    """
    return re.sub(
        r'(</h2>|</p>|</blockquote>|</ol>|</ul>)\s*(<h2|<p|<blockquote|<ol|<ul)',
        r'\1\n  <p style="margin:0;line-height:1.6;"><br></p>\n  \2',
        html,
    )


def _inline(text: str, scheme: "ColorScheme") -> str:
    """处理行内格式：**粗体**、`代码`、*斜体*。"""
    strong_style = f"color:{scheme.primary};font-weight:700;"
    code_style = f"background:{scheme.accent};color:{scheme.secondary};padding:2px 6px;border-radius:3px;font-size:13px;font-family:Menlo,Consolas,monospace;"
    # 代码
    text = re.sub(r'`([^`]+)`', lambda m: f'<code style="{code_style}">{m.group(1)}</code>', text)
    # 粗体
    text = re.sub(r'\*\*([^*]+)\*\*', lambda m: f'<strong style="{strong_style}">{m.group(1)}</strong>', text)
    # 斜体
    text = re.sub(r'\*([^*]+)\*', lambda m: f'<em>{m.group(1)}</em>', text)
    return text
