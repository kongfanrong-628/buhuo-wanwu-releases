"""
高端配色卡：6 套配色方案，全部 hex 常量。
60-30-10 规则，浅色只做背景，正文永远深色。
与计划书 §6.2 对齐。
"""

from dataclasses import dataclass


@dataclass
class ColorScheme:
    """配色方案。"""
    name: str           # 显示名
    primary: str        # 主色（60%）- 背景/大块
    secondary: str      # 辅色（30%）- 文字/分隔
    accent: str         # 点缀（10%）- 强调/金句/按钮
    text_color: str     # 正文文字色（深色）
    bg_color: str       # 页面背景色
    track: str          # 主赛道


# 6 套配色卡
COLOR_SCHEMES: dict[str, ColorScheme] = {
    "松绿+墨黑配色": ColorScheme(
        name="松绿+墨黑配色",
        primary="#07C160",
        secondary="#1A1A1A",
        accent="#E8F5EE",
        text_color="#1A1A1A",
        bg_color="#FFFFFF",
        track="知识/科技（品牌主色）",
    ),
    "雾蓝+月白配色": ColorScheme(
        name="雾蓝+月白配色",
        primary="#2E5C8A",
        secondary="#F5F7FA",
        accent="#C9D6E3",
        text_color="#2E5C8A",
        bg_color="#F5F7FA",
        track="商业/数据",
    ),
    "珊瑚橘+暖灰配色": ColorScheme(
        name="珊瑚橘+暖灰配色",
        primary="#FF7A59",
        secondary="#3D3D3D",
        accent="#FFF0EB",
        text_color="#3D3D3D",
        bg_color="#FFFFFF",
        track="生活/娱乐/种草",
    ),
    "黛紫+银白配色": ColorScheme(
        name="黛紫+银白配色",
        primary="#6B5B95",
        secondary="#FAF8FC",
        accent="#D9D2E9",
        text_color="#3D3A44",
        bg_color="#FAF8FC",
        track="品牌/故事/情感",
    ),
    "焦糖+墨绿配色": ColorScheme(
        name="焦糖+墨绿配色",
        primary="#B5651D",
        secondary="#2F4F4F",
        accent="#F3E9DC",
        text_color="#2F4F4F",
        bg_color="#FFFFFF",
        track="深度/观点/叙事",
    ),
    "晨雾+靛青配色": ColorScheme(
        name="晨雾+靛青配色",
        primary="#A8C5C5",
        secondary="#1F3A5F",
        accent="#EEF4F4",
        text_color="#1F3A5F",
        bg_color="#FFFFFF",
        track="资讯/科普",
    ),
}


def get_scheme(name: str) -> ColorScheme | None:
    """获取指定配色方案。"""
    return COLOR_SCHEMES.get(name)


def list_schemes() -> list[dict]:
    """列出所有配色方案。"""
    return [
        {"name": s.name, "primary": s.primary, "track": s.track}
        for s in COLOR_SCHEMES.values()
    ]