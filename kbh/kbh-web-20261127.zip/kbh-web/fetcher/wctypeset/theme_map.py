#!/usr/bin/env python3
"""题材 → 公众号排版主题 映射（同步自「胜元公众号排版」skill 的 theme-index.md L44-57）。

为什么单独成文件：
- 工坊 `themes14.py` 已有 19 套主题（含 skill 全部 18 套 +「资讯爆款」），主题数量并不落后；
  落后的是「按题材/赛道推荐主题」这层决策逻辑（旧引擎只有按骨架骨架推荐）。
- 这里只做"决策层"，不动主题定义本身，风险最低。

匹配方式：子串命中（domain 可能是"AI工具教程"/"AI科技"/"工具"都命品牌绿）。
primary = ★推荐默认，alts = 并列/备选（导演显式选时才用）。
"""
from __future__ import annotations

# (匹配关键词, 主键 theme key, [备选 key...])
# 顺序无关，recommend_theme 按最长关键词优先。
_THEME_RULES: list[tuple[str, str, list[str]]] = [
    ("AI工具教程", "green", ["stripe-silicon"]),
    ("AI工具横评", "moyu-ticket", ["nyt-editorial"]),
    ("AI工具", "green", ["stripe-silicon"]),
    ("AI资讯", "ocean-deep", ["red-white"]),
    ("认知观点", "claude-oat", ["bauhaus-bold", "red-white"]),
    ("观点", "claude-oat", ["bauhaus-bold"]),
    ("AI副业", "olive", []),
    ("副业变现", "olive", []),
    ("变现", "olive", []),
    ("漫剧", "olive", ["warm-sun"]),
    ("故事", "olive", ["warm-sun"]),
    ("漫画", "olive", ["warm-sun"]),
    ("随笔", "olive", ["warm-sun"]),
    ("国风", "guofeng-ink", []),
    ("传统", "guofeng-ink", []),
    ("国风墨色", "guofeng-ink", []),
    ("手帐", "mint-handbook", []),
    ("治愈", "mint-handbook", []),
    ("自我成长", "mint-handbook", []),
    ("设计审美", "morandi", []),
    ("家居", "morandi", []),
    ("生活美学", "morandi", []),
    ("暖调", "shengyuan-earth", ["green"]),
    ("人味", "shengyuan-earth", ["green"]),
    ("资讯", "ocean-deep", ["red-white", "news-pop"]),
    ("财经", "nyt-editorial", ["olive"]),
    ("商业", "nyt-editorial", ["olive"]),
    ("行业分析", "nyt-editorial", []),
    ("热点", "red-white", ["bauhaus-bold"]),
    ("娱乐", "nyt-editorial", []),      # 2026-10-06 批1：暗底 magazine-noir/cyberpunk 下线，改指浅色骨架
    ("影视", "nyt-editorial", []),
    ("游戏", "stripe-silicon", []),
    ("电竞", "stripe-silicon", []),
    ("极客", "stripe-silicon", []),
    ("开源", "project-intro", ["stripe-silicon", "ocean-deep"]),
    ("GitHub", "project-intro", ["stripe-silicon"]),
    ("科技", "stripe-silicon", ["green"]),
    ("产品", "stripe-silicon", []),
    ("SaaS", "stripe-silicon", []),
    ("职场", "ocean-deep", []),
    ("情感", "warm-sun", []),
    ("亲子", "warm-sun", []),
    ("健康", "mint-handbook", []),
    ("心理", "mint-handbook", []),
    ("读书", "claude-oat", ["olive"]),
    ("长读", "claude-oat", ["olive"]),
    ("深度", "claude-oat", ["olive"]),
    # ── 2026-10-01 补齐「工坊 UI 真实赛道名」兜底 ──────────────────────────
    # 上面这批是按早期题材词（AI工具教程/认知观点…）写的，漏了 UI 下拉里真实存在的
    # 「人文历史」「民生时事」「职场成长」「生活情绪」等整条赛道名 → matched=False，
    # 前端拿不到推荐只能回退默认版式（导演反馈「情绪文排成工具攻略味」的一半原因在这）。
    # 注意：同一批赛道的主版式已由 track_playbook.json 的 theme 字段钉死并优先消费，
    # 这里只作未登记赛道的兜底，两边结论不一致时以 track_playbook 为准。
    ("人文历史", "guofeng-ink", ["claude-oat"]),
    ("历史", "guofeng-ink", []),
    ("生活情绪", "warm-sun", ["olive"]),
    ("情绪", "warm-sun", ["olive"]),
    ("民生时事", "red-white", ["news-pop"]),
    ("时事", "red-white", []),
    ("副业", "olive", ["nyt-editorial"]),
    ("职场成长", "ocean-deep", ["olive"]),
    ("成长", "ocean-deep", ["olive"]),
    ("生活", "warm-sun", ["olive"]),
]


def recommend_theme(domain: str | None) -> dict:
    """按题材返回推荐主题。

    返回 {"primary": key_or_None, "alts": [key...], "matched": bool}
    domain 为空 / 无命中时 primary=None（交给调用方回退到骨架映射或默认主题）。
    """
    if not domain:
        return {"primary": None, "alts": [], "matched": False}
    d = domain.strip()
    if not d:
        return {"primary": None, "alts": [], "matched": False}
    # 最长关键词优先，避免"资讯"误吞"AI资讯"
    best: tuple[int, tuple[str, str, list[str]]] | None = None
    for rule in _THEME_RULES:
        kw = rule[0]
        if kw in d:
            score = len(kw)
            if best is None or score > best[0]:
                best = (score, rule)
    if best is None:
        return {"primary": None, "alts": [], "matched": False}
    _, (kw, primary, alts) = best
    return {"primary": primary, "alts": list(alts), "matched": True, "_kw": kw}


def primary_theme(domain: str | None) -> str | None:
    """仅取主键（无命中返回 None）。"""
    return recommend_theme(domain)["primary"]


if __name__ == "__main__":
    for t in ["AI工具教程", "AI资讯速递", "认知观点", "漫剧", "财经", "情感恋爱", "随便写写"]:
        print(t, "→", recommend_theme(t))
