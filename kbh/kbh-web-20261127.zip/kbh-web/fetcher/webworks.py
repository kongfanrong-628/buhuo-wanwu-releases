# -*- coding: utf-8 -*-
"""写作工坊网页端 · 作品云端表 web_work（任务 #63 切片3b）。

RLS 按 owner_uid = auth.jwt sub 隔离，服务端带用户 token 走 PostgREST，
用户只能读写自己的作品。与 byok_vault 同范式（线上 requests 已有）。
save 用 POST + Prefer:resolution=merge-duplicates 做 upsert（幂等）。
"""
import datetime

CFG = {}  # server.py 注入：{"db": CLOUD_DB, "cloud_headers": fn}

MAX_TITLE = 200
MAX_CONTENT = 200000


class WorkError(Exception):
    def __init__(self, code, http, message):
        self.code, self.http, self.message = code, http, message
        super().__init__(message)


def _request(method, token, params=None, payload=None, prefer=None, timeout=20):
    import requests
    url = CFG["db"] + "web_work"
    headers = dict(CFG["cloud_headers"](token))
    headers["Prefer"] = prefer or "return=representation"
    try:
        if method == "GET":
            return requests.get(url, params=params or {}, headers=headers, timeout=timeout)
        if method == "POST":
            return requests.post(url, json=payload or {}, headers=headers, timeout=timeout)
        if method == "PATCH":
            return requests.patch(url, params=params or {}, json=payload or {},
                                  headers=headers, timeout=timeout)
        if method == "DELETE":
            return requests.delete(url, params=params or {}, headers=headers, timeout=timeout)
    except Exception as e:  # noqa: BLE001
        raise WorkError("NETWORK", 503, "%s: %s" % (type(e).__name__, str(e)[:120]))
    raise WorkError("BAD_METHOD", 500, method)


def _check(r, action):
    if r.status_code in (200, 201, 204, 206):
        return
    try:
        body = r.json()
        msg = (body.get("message") or body.get("details") or
               body.get("hint") or str(body))[:160]
    except Exception:
        msg = (r.text or "")[:160]
    if r.status_code in (401, 403):
        raise WorkError("FORBIDDEN", 403, "作品库拒绝访问（%s）：%s" % (action, msg))
    raise WorkError("DB_ERROR", 502, "作品%s失败：%s" % (action, msg))


def _json(r):
    try:
        return r.json()
    except Exception:
        return []


def save(token, uid, body):
    """保存作品（upsert 按 owner_uid+work_id）。"""
    if not uid:
        raise WorkError("NOT_SIGNED_IN", 401, "请先登录会员账号")
    work_id = str((body or {}).get("work_id") or "").strip()
    if not work_id:
        raise WorkError("NO_ID", 400, "作品缺少 work_id")
    title = str((body or {}).get("title") or "")[:MAX_TITLE]
    content = str((body or {}).get("content") or "")
    if len(content) > MAX_CONTENT:
        raise WorkError("TOO_LONG", 400, "作品正文超过上限")
    extra = (body or {}).get("extra") or {}
    aigc = (body or {}).get("aigc") or {}
    row = {"owner_uid": uid, "work_id": work_id[:80], "title": title,
           "content": content,
           "content_type": str((body or {}).get("content_type") or "article")[:20],
           "extra": extra if isinstance(extra, dict) else {},
           "aigc": aigc if isinstance(aigc, dict) else {},
           "updated_at": datetime.datetime.utcnow().isoformat() + "Z"}
    r = _request("POST", token, payload=row,
                 prefer="resolution=merge-duplicates,return=representation")
    _check(r, "保存")
    rows = _json(r)
    return {"saved": True, "work_id": work_id,
            "row": rows[0] if isinstance(rows, list) and rows else row}


def list_works(token, uid, limit=100):
    """列出当前用户作品（只回元数据，不回正文，减流量）。"""
    if not uid:
        raise WorkError("NOT_SIGNED_IN", 401, "请先登录会员账号")
    try:
        lim = min(max(int(limit), 1), 300)
    except Exception:
        lim = 100
    params = {"owner_uid": "eq." + uid,
              "select": "work_id,title,content_type,created_at,updated_at",
              "order": "updated_at.desc", "limit": lim}
    r = _request("GET", token, params=params)
    _check(r, "列表")
    rows = _json(r)
    return {"works": rows if isinstance(rows, list) else []}


def load_work(token, uid, work_id):
    """加载单篇作品全文。"""
    if not uid:
        raise WorkError("NOT_SIGNED_IN", 401, "请先登录会员账号")
    work_id = str(work_id or "").strip()
    if not work_id:
        raise WorkError("NO_ID", 400, "缺少 work_id")
    params = {"owner_uid": "eq." + uid, "work_id": "eq." + work_id, "limit": 1}
    r = _request("GET", token, params=params)
    _check(r, "读取")
    rows = _json(r)
    if not isinstance(rows, list) or not rows:
        raise WorkError("NOT_FOUND", 404, "作品不存在或已删除")
    return {"work": rows[0]}
