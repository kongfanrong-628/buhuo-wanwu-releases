# -*- coding: utf-8 -*-
"""
封面/配图文字识别（可选能力）

为什么需要：小红书图文笔记的大量内容是"图里写字"，正文常常只有一两句。
不读图，封面爆点和配图信息这两层就只能靠用户手抄。

实现取舍：
- 单张中文图在 CPU 上约 8-10 秒，9 张图全读要一分多钟，同步接口扛不住。
- 所以默认只读封面 1 张（8 秒），其余图由前端按需再发 /ocr 请求。
- 依赖装不上时整个模块降级为不可用（available=False），不抛异常、不影响抓取。
"""
import io
import os
import threading
import time

_engine = [None]
_init_fail = [False]
_lock = threading.Lock()

MAX_SIDE = 900

# OCR 结果缓存：一张图在 CPU 上要跑 8-10 秒，一批 4-8 张就是 30-80 秒。
# 用户点了「读全部图」之后再调模板、再重拆，每次都重跑一遍纯属烧 CPU。
#
# 为什么是 15 分钟而不是跟正文一样 3 分钟：
#   正文抓完立刻就进了页面输入框，后端这份当场完成使命；
#   但 OCR 是「按需计算」的 —— 用户可能过几分钟才点第二次，
#   而这个结果跟平台侧无关（纯本地计算产物），留久一点不会增加风控风险。
#   15 分钟足够覆盖一次完整会话，又远不到"存储"的程度。
#
# 只缓存「成功且认出文字」的结果：空结果可能是临时网络抖动，
# 缓存住会让用户一直拿到空的，宁可下次重算。
OCR_TTL = int(os.environ.get("OCR_TTL") or 900)
OCR_MAX = 200
_ocr_cache = {}
_ocr_cache_lock = threading.Lock()


def available():
    if _engine[0] is not None:
        return True
    if _init_fail[0]:
        return False
    try:
        from rapidocr_onnxruntime import RapidOCR  # noqa: F401
        return True
    except Exception:
        _init_fail[0] = True
        return False


def _get():
    if _engine[0] is not None:
        return _engine[0]
    with _lock:
        if _engine[0] is None:
            from rapidocr_onnxruntime import RapidOCR
            _engine[0] = RapidOCR()
    return _engine[0]


def ocr_bytes(data):
    """返回识别出的文本行 list（按阅读顺序）。失败返回 []。"""
    if not available():
        return []
    try:
        from PIL import Image
        im = Image.open(io.BytesIO(data))
        if im.mode not in ("RGB", "L"):
            im = im.convert("RGB")
        if max(im.size) > MAX_SIDE:
            im.thumbnail((MAX_SIDE, MAX_SIDE * 3), Image.LANCZOS)
        buf = io.BytesIO()
        im.convert("RGB").save(buf, "JPEG", quality=88)
        res, _ = _get()(buf.getvalue())
        if not res:
            return []
        lines = []
        for item in res:
            try:
                txt = str(item[1]).strip()
            except Exception:
                continue
            if txt:
                lines.append(txt)
        return lines
    except Exception:
        return []


def ocr_url(url, timeout=15):
    """下载后识别（带缓存）。返回 (lines, err)。"""
    if not available():
        return [], "ocr_unavailable"

    now = time.time()
    with _ocr_cache_lock:
        hit = _ocr_cache.get(url)
        if hit and (now - hit[0]) <= OCR_TTL:
            return list(hit[1]), ""

    lines, err = _ocr_url_uncached(url, timeout)

    if lines and not err:
        with _ocr_cache_lock:
            if len(_ocr_cache) > OCR_MAX:
                for k in sorted(_ocr_cache, key=lambda k: _ocr_cache[k][0])[:50]:
                    _ocr_cache.pop(k, None)
            _ocr_cache[url] = (time.time(), list(lines))
    return lines, err


def _ocr_url_uncached(url, timeout=15):
    """真正干活的那次请求，ocr_url 负责缓存外壳。返回 (lines, err)。"""
    try:
        import requests
        r = requests.get(url, timeout=timeout, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                          "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
            "Referer": "https://www.xiaohongshu.com/",
        })
        if r.status_code != 200 or len(r.content) < 1000:
            return [], "download_%s" % r.status_code
        return ocr_bytes(r.content), ""
    except Exception as e:
        return [], "download_error:%s" % type(e).__name__


def join_lines(lines, sep="\n"):
    """OCR 出来的行按行拼。短行（≤6 字）多半是大字标题，单独成行更利读。"""
    out = []
    for ln in lines:
        ln = ln.strip()
        if not ln:
            continue
        out.append(ln)
    return sep.join(out)
