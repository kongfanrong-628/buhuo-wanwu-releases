# -*- coding: utf-8 -*-
"""BYOK 密钥保险箱：服务端 AES-256-GCM 加密 + 数据库 RLS 按 uid 隔离。

设计（任务 #62，对应 db/2026-11-26_user_api_keys.sql）：
  - 会员站没有 KMS（app_secrets 只有 name/value_hash，存 sha256 不可逆）。
    故主密钥由环境变量 WB_BYOK_MASTER_KEY 提供（32 字节 hex / base64），
    生产必须显式配置；本地开发有专用 dev 默认值（仅用于 18999 自测）。
  - 每把 Key 用 AES-256-GCM 加密，nonce 随机 12 字节，密文+nonce 存 bytea。
    数据库里没有任何明文 Key；日志只留 sk-****<尾4>，不留全文。
  - 越权：PostgREST 走用户 token，RLS 策略 owner_uid = auth.jwt sub，
    用户 A 无论如何拿不到用户 B 的行（服务端代调用也带的是 A 自己的 token）。
  - 删除即失效：delete 行 → 下次服务端代调用取不到 Key → 直接报「未配置 Key」。

接口（供 server.py 注入 CFG 后调用，全部返回 (data, err)，异常不外抛）：
  save(uid, slot, key, name, base_url, model) -> ({slot,key_tail,...}, None)
  list(uid)                                  -> ({"keys":[{slot,name,key_tail,base_url,model}]}, None)
  delete(uid, slot)                          -> ({"deleted":bool}, None)
  reveal(uid, slot)                          -> ({"key":明文}, None)   # 仅服务端代调用内部用
"""
import base64
import hashlib
import json
import os

# 由 server.py 注入：CFG = {"db":..., "cloud_headers": fn}
CFG = {}

SLOTS = ("writing", "image", "redfox")
_DEV_MASTER = "dev-only-do-not-use-in-prod"  # 仅本地 18999 用；hash 派生 32 字节


class VaultError(Exception):
    def __init__(self, code, http=400, message=""):
        super().__init__(message or code)
        self.code = code
        self.http = http


def _master_key():
    raw = os.environ.get("WB_BYOK_MASTER_KEY", "")
    if raw:
        try:
            if len(raw) >= 64 and all(c in "0123456789abcdefABCDEF" for c in raw):
                k = bytes.fromhex(raw)
            else:
                k = base64.urlsafe_b64decode(raw + "=" * (-len(raw) % 4))
            if len(k) == 32:
                return k
        except Exception:  # noqa: BLE001
            pass
        raise VaultError("MASTER_KEY_INVALID", 500,
                         "WB_BYOK_MASTER_KEY 必须是 32 字节 hex 或 base64")
    # 没有配置：仅允许本地开发端口，生产必须显式配
    if os.environ.get("PORT") == "18999":
        return hashlib.sha256(_DEV_MASTER.encode()).digest()
    raise VaultError("MASTER_KEY_MISSING", 500,
                     "服务端未配置密钥主密钥（WB_BYOK_MASTER_KEY），拒绝保存 Key")


def _aead():
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    except ImportError as e:  # noqa: BLE001
        raise VaultError(
            "CRYPTO_MISSING", 503,
            "服务端缺少 cryptography 依赖，无法加密保存 Key。部署环境需 pip install cryptography。")
    return AESGCM(_master_key())


def mask(key):
    """日志/回显专用：只留 sk-****+尾4，绝不返回全文。"""
    s = str(key or "")
    if len(s) <= 8:
        return "sk-****"
    return s[:3] + "****" + s[-4:]


def _key_tail(key):
    s = str(key or "").strip()
    return s[-4:] if len(s) >= 4 else ""


def _request(method, table, token, params=None, payload=None, timeout=20):
    """走 PostgREST，带用户 token；RLS 自动按 uid 隔离。"""
    import requests
    url = CFG["db"] + table
    headers = dict(CFG["cloud_headers"](token))
    headers["Prefer"] = "return=representation"
    try:
        if method == "GET":
            return requests.get(url, params=params or {}, headers=headers, timeout=timeout)
        if method == "POST":
            return requests.post(url, json=payload or {}, headers=headers, timeout=timeout)
        if method == "PATCH":
            return requests.patch(url, params=params or {}, json=payload or {},
                                  headers=headers, timeout=timeout)
        if method == "DELETE":
            return requests.delete(url, params=params or {}, headers=headers, timeout=timeout)
    except Exception as e:  # noqa: BLE001
        raise VaultError("NETWORK", 503, "%s: %s" % (type(e).__name__, str(e)[:120]))
    raise VaultError("BAD_METHOD", 500, method)


def _check(r, action):
    if r.status_code in (200, 201, 204, 206):
        return
    try:
        body = r.json()
        msg = (body.get("message") or body.get("details") or
               body.get("hint") or str(body))[:160]
    except Exception:  # noqa: BLE001
        msg = (r.text or "")[:160]
    if r.status_code in (401, 403):
        raise VaultError("FORBIDDEN", 403, "密钥保险箱拒绝访问（%s）：%s" % (action, msg))
    raise VaultError("DB_ERROR", 502, "保险箱%s失败：%s" % (action, msg))


def _json(r):
    try:
        return r.json()
    except Exception:  # noqa: BLE001
        return []


def save(token, uid, slot, key, name="", base_url="", model=""):
    if not uid:
        raise VaultError("NOT_SIGNED_IN", 401, "请先登录会员账号")
    slot = str(slot or "").strip()
    if slot not in SLOTS:
        raise VaultError("BAD_SLOT", 400, "Key 槽位只能是 writing/image/redfox")
    key = str(key or "").strip()
    if len(key) < 8:
        raise VaultError("BAD_KEY", 400, "Key 太短，请检查是否复制完整")

    nonce = os.urandom(12)
    ct = _aead().encrypt(nonce, key.encode("utf-8"), uid.encode("utf-8"))
    row = {
        "owner_uid": uid,
        "slot": slot,
        "name": str(name or "")[:80],
        "base_url": str(base_url or "")[:300],
        "model": str(model or "")[:120],
        "ciphertext": base64.b64encode(ct).decode(),
        "nonce": base64.b64encode(nonce).decode(),
        "key_tail": _key_tail(key),
    }
    # upsert：先查有没有，有则 PATCH，无则 POST（避免依赖 on_conflict header 行为）
    r = _request("GET", "user_api_keys", token, params={"owner_uid": "eq." + uid,
                                                                "slot": "eq." + slot})
    _check(r, "查询")
    exist = _json(r)
    if exist:
        del row["owner_uid"]  # RLS 不允许改 owner
        del row["slot"]
        r2 = _request("PATCH", "user_api_keys", token,
                      params={"owner_uid": "eq." + uid, "slot": "eq." + slot}, payload=row)
    else:
        r2 = _request("POST", "user_api_keys", token, payload=row)
    _check(r2, "保存")
    return {"slot": slot, "key_tail": row["key_tail"], "masked": mask(key)}, None


def list_keys(token, uid):
    if not uid:
        raise VaultError("NOT_SIGNED_IN", 401, "请先登录会员账号")
    r = _request("GET", "user_api_keys", token,
                 params={"owner_uid": "eq." + uid, "select": "slot,name,base_url,model,key_tail,updated_at"})
    _check(r, "列出")
    rows = _json(r)
    return {"keys": [{
        "slot": x.get("slot"), "name": x.get("name", ""),
        "base_url": x.get("base_url", ""), "model": x.get("model", ""),
        "key_tail": x.get("key_tail", ""),
        "masked": "sk-****" + (x.get("key_tail") or ""),
        "updated_at": x.get("updated_at"),
    } for x in rows]}, None


def delete(token, uid, slot):
    if not uid:
        raise VaultError("NOT_SIGNED_IN", 401, "请先登录会员账号")
    r = _request("DELETE", "user_api_keys", token,
                 params={"owner_uid": "eq." + uid, "slot": "eq." + str(slot)})
    _check(r, "删除")
    return {"deleted": True, "slot": slot}, None


def reveal(token, uid, slot):
    """仅服务端代调用内部使用：解密出明文 Key，绝不经日志/响应外泄。"""
    if not uid:
        raise VaultError("NOT_SIGNED_IN", 401, "请先登录会员账号")
    r = _request("GET", "user_api_keys", token,
                 params={"owner_uid": "eq." + uid, "slot": "eq." + str(slot)})
    _check(r, "读取")
    rows = _json(r)
    if not rows or not rows[0].get("ciphertext"):
        raise VaultError("KEY_NOT_CONFIGURED", 404, "还没配置这个 Key，去保险箱添加后再试")
    row = rows[0]
    try:
        ct = base64.b64decode(row["ciphertext"])
        nonce = base64.b64decode(row["nonce"])
        plain = _aead().decrypt(nonce, ct, uid.encode("utf-8")).decode("utf-8")
    except Exception:  # noqa: BLE001
        raise VaultError("DECRYPT_FAILED", 500, "密钥解密失败，请重新保存该 Key")
    return {"key": plain, "base_url": row.get("base_url", ""),
            "model": row.get("model", "")}, None
