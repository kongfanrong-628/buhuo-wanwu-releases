# -*- coding: utf-8 -*-
"""写作工坊网页端 · 排版导出核心（任务 #63 切片3a）。

复用桌面端 typeset/ 纯逻辑（已复制到 wctypeset/，零第三方依赖）：
  - slots.summary / slots.prepare：图位锚点 +【导演填】清单 + 能不能直接发
  - themes14.render：17 套微信安全 HTML 模板（全内联 style / section / span）
  - compliance.validate_gzh：公众号兼容门禁（无 flex/rgba/渐变/外链 CSS）

网页端不做：本地 IP profile 读取（无 config.yaml）、漫画（胜元拍板）、
legacy 主题名映射（前端直接传 themes14 key）。输出带 AIGC 双标识由 webcore.aigc_mark 负责。
"""
import re

MAX_CONTENT = 50000
MAX_HTML = 200000


class TypeError_(Exception):
    def __init__(self, code, message):
        self.code, self.message = code, message
        super().__init__(message)


def slots_summary(content):
    from wctypeset import slots
    return slots.summary(str(content or ""))


def _inject_spots(content, spots):
    """配图位：把 [[图位N]] 盲替换成 <img>，与桌面端一致。"""
    content = str(content or "")
    spots = spots or []
    if not isinstance(spots, list):
        return content
    for i, sp in enumerate(spots):
        if not isinstance(sp, dict):
            continue
        url = str(sp.get("url") or sp.get("src") or "").strip()
        if not url:
            continue
        marker = "[[图位%d]]" % (i + 1)
        if marker in content:
            content = content.replace(marker, "![图%d](%s)" % (i + 1, url))
    return content


def export_html(content, *, template="", theme="", byline="", cover_src="",
                footer_cta=False, ip=None, publish=False, content_type="article",
                spots=None):
    """渲染公众号兼容 HTML：themes14 模板 + 图位注入 + 合规门禁。

    返回 {ok, html, compliance, slots, template}；不合规也在 body 里给出 errors，
    由前端决定是否提示（红色提示只提醒不拦截，与热点合规提示口径一致）。
    """
    from wctypeset import slots as _SL, themes14, compliance
    content = str(content or "")
    if not content.strip():
        raise TypeError_("EMPTY", "正文为空，没有可排版的内容")
    if len(content) > MAX_CONTENT:
        raise TypeError_("TOO_LONG", "正文超过 %d 字上限" % MAX_CONTENT)
    if content_type == "comic":
        raise TypeError_("NOT_SUPPORTED", "漫画排版网页端不支持")

    md = _inject_spots(content, spots)
    prepared = _SL.prepare(md, publish=bool(publish))

    # 模板选择：显式 template 优先；前端直传 themes14 key；未知 key 回落默认
    known = set(themes14.THEMES.keys()) if hasattr(themes14, "THEMES") else set()
    tpl = (template or theme or "").strip()
    if tpl not in known:
        tpl = getattr(themes14, "DEFAULT_THEME", "green")

    ip = ip if isinstance(ip, dict) else None  # 无 config → 只接受前端显式 IP
    html = themes14.render(prepared, tpl, byline or "", cover_src or "",
                           footer_cta, ip)
    report = compliance.validate_gzh(html)
    return {"ok": True, "html": html, "template": tpl,
            "compliance": report, "slots": _SL.summary(md),
            "content_type": content_type}


def preflight(content, html="", track=""):
    """发布前统一自检：排版合规(有html时) + AI味检测 + 排版清单。

    词库红线是桌面端 compliance_db（本地词库），网页端第一批不加载，
    改为提示「词库自检请在桌面端做」——不假装通过。
    """
    from wctypeset import compliance
    from wccore import ai_score
    content = str(content or "")
    if not content.strip():
        raise TypeError_("EMPTY", "正文为空，无法预检")
    if len(content) > MAX_CONTENT:
        raise TypeError_("TOO_LONG", "正文超过上限")

    out = {"ok": True, "passed": True, "errors": [], "warnings": [], "sections": {}}
    if html:
        lay = compliance.validate_gzh(str(html)[:MAX_HTML])
        out["sections"]["排版合规"] = lay
        out["errors"].extend(lay.get("errors") or [])
        out["warnings"].extend(lay.get("warnings") or [])
    else:
        out["sections"]["排版合规"] = {"passed": True, "note": "未提供 HTML，跳过排版检测"}

    ai = ai_score.scan(content)
    out["sections"]["AI味检测"] = {"verdict": ai.get("verdict"),
                                    "total": ai.get("total"),
                                    "advice": ai.get("advice")}
    out["sections"]["排版清单"] = slots_summary(content)
    if not out["sections"]["排版清单"].get("publish_ready"):
        out["warnings"].append("还有【导演填】或图位未处理，发布版导出会剔除这些内容")

    out["sections"]["内容合规"] = {
        "passed": True, "errors": [], "warnings": [],
        "note": "词库红线自检在桌面端做；网页端仅做排版与 AI 味检测"}
    out["passed"] = not out["errors"]
    return out
