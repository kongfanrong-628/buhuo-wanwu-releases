"""去 AI 味后处理流水线（工单 P1-1，2026-10-27）。

孤狼智写可迁移「4 件套」的纯算法实现，与模型解耦、零依赖、可单测：

| 序 | 组件 | 解决的事故 |
|---|---|---|
| 1 | 占位保护 | 改写把数字/书名号/英文专名改掉（实测：2026→去年、GPT-4→GPT4） |
| 2 | 分段 1:1 回填 | 模型少返段/多返段/合并段，导致段落增删与重排 |
| 3 | 相似度重降 | 模型只换几个词，「改不透」但排在 PASS 里 |
| 4 | 泄漏清洗 | 模型把「好的，以下是改写后的文章」写进正文 |

设计铁律（沿用本仓库既有纪律）：
  · **宁可少改，不可改坏**——任何一步拿不准就回退原文对应片段，不猜；
  · **不静默**——每步产出结构化 report，调用方负责把异常写进提示文案；
  · **纯函数**——不接受任何全局配置，同样的入参永远给同样的出参（可复现）。

与 `detox._protect_rewrite` 的分工：本模块做**改写前后的结构性处理**，
`_protect_rewrite` 做**终稿质量守卫**（篇幅/标点/第一人称）。两者串联，
不互相替代。
"""

from __future__ import annotations

import difflib
import re
import zlib

# ── 占位符 ────────────────────────────────────────────────────────────────
# 🔴 用「⟦⟧」而不是「[[ ]]」：中括号在模型输出里出现频率太高（Markdown 链接、
#    数组），模型会把占位符当语法改写掉。⟦⟧ 是数学定界符，中文模型不会误判。
_PH_OPEN, _PH_CLOSE = "⟦", "⟧"
# 原文自带 ⟦⟧ 时的转义字符（私有区，正常中文稿不可能出现）
_ESC_OPEN, _ESC_CLOSE = "\ue000", "\ue001"

# 类型：N=数字  B=书名号  E=英文专名/型号
_ENTITY_RE = re.compile(
    r"《[^》\n]{1,60}》"                                # 书名号整体（含里面数字，优先级最高）
    r"|[A-Za-z][A-Za-z0-9]*(?:[.\-_][A-Za-z0-9]+)*"     # 英文专名 / 型号（GPT-4、zh-lite）
    r"|\d+(?:[.,]\d+)*(?:\s*[%％])?"                    # 数字（含千分位、小数、百分号）
)

# 回填容错：模型会把 ⟦N1⟧ 改写成 【N1】/(N1)/[N1]/⟦N1 ⟧
_VARIANT_PATTERNS = (
    "{o}{ph}{c}", "{o} {ph} {c}",
    "【{ph}】", "[{ph}]", "（{ph}）", "({ph})", "「{ph}」", "《{ph}》",
    "{{{{{ph}}}}}", "<{ph}>",
)

_LEAK_HEAD = (
    re.compile(r"^(好的|好[，,。！!]|可以[，,]?|没问题[，,]?|收到[，,]?|明白了)[^\n]{0,24}$"),
    re.compile(r"^(以下是|下面是|这是|现将)[^\n]{0,40}(改写|优化|润色|降味|版本|稿件|文章)[^\n]{0,20}[：:]?$"),
    re.compile(r"^(分析|说明|解释|改写思路|处理说明)\s*[：:].{0,60}$"),
    re.compile(r"^(首先|接下来|下面)[，,]?\s*我(需要|将|会|先)[^\n]{0,40}$"),
    re.compile(r"^[《【\[]?(改写后|改写结果|优化后|润色后|输出|结果)[》】\]]?\s*[：:]?$"),
    re.compile(r"^(OK|Okay|Sure)[,.]?.{0,40}$", re.I),
)
_LEAK_TAIL = (
    re.compile(r"^(希望|如需|如果|若|以上|请|需要)[^\n]{0,50}(帮助|调整|告知|核对|放心|修改|反馈|继续)[^\n]{0,20}[。！!]?$"),
    re.compile(r"^(—+|–+|-+)?\s*以上[，,]?\s*(是|为)?[^\n]{0,30}[。]?$"),
    re.compile(r"^(如|若)(有|需)[^\n]{0,30}[，,]?\s*(欢迎|随时)[^\n]{0,30}[。！!]?$"),
)

_NUM_RE = re.compile(r"\d+(?:[.,]\d+)*\s*[%％]?")

# 🔴 缺陷1（2026-10-27 P1-1 真机回归）：模型会把提示词里的**指令块**原样抄进正文。
# 实测样例：成品段落里出现「【不要合并段落，保留段落和空行】」。旧的 strip_leak
# 只认「好的/以下是…」这类自述句，方括号指令块整段漏网 → 成品直接带出提示词。
# 判定口径：括号内命中指令词才算泄漏；不含指令词的【小标题】【案例】一律保留，
# 避免把正文自己的方括号结构当泄漏删掉。
_INSTR_WORDS = (
    "不要", "请", "禁止", "务必", "必须", "保留", "合并", "拆", "扩写", "改写",
    "降味", "润色", "输出", "字数", "段落", "空行", "格式", "语气", "风格",
    "口播", "原文", "标点", "标题", "口语", "书面",
    # 🔴 P1-13b（2026-10-27 真机实测）：节奏/句式类指令复读漏网。
    # 模型把注入的「本段以短句为主 / 允许长句铺陈 / 打散首先其次最后」改写后抄回正文，
    # 旧词表一个都不命中（实测 6 个泄漏块漏 3 个）：
    #   【打散排比词（首先/其次/最后）变成叙述】【短句为主，平缓些】【这个段短句居多，慢节奏】
    "打散", "排比", "短句", "长句", "节奏", "句式", "铺陈", "平缓",
    "叙述", "复述", "首句", "排比句",
    # 🔴 P1-13b 二轮（AI_002 复跑又漏）：标点/排版类复读——
    #   【书名号《》等保持不变】【每段之间空一行】【开头不要加称呼】
    # 这类一个旧词都不命中（只有「标点」勉强沾边，实测「书名号《》等保持不变」命中 0）。
    "书名号", "引号", "分行", "换行", "加粗", "省略号",
)
# 弱词：单独出现**不判泄漏**（作者标题里「开头」「保持」很常见，如【开头三个月的记账复盘】），
# 只参与计数——累计 ≥2 个才算指令块。这样「书名号《》等保持不变」（书名号+保持=2）能剥，
# 而「【开头三个月的记账复盘】」（=1）能留。
_WEAK_WORDS = (
    "保持", "原样", "符号", "开头", "结尾", "称呼",
    "逗号", "句号", "问号", "分隔", "缩进", "对齐",
)
_BRACKET_BLOCK_RE = re.compile(r"[【\[]([^【】\[\]\n]{1,40})[】\]]")
# 排版指令的形态词：「每段之间空一行」一个词表词都不含（不是「空行」而是「空一行」），
# 只能靠形态正则兜。限定在【】块内 + ≤40 字，正文里出现「每段」这种说法的概率极低。
_LAYOUT_RE = re.compile(
    r"(?:空|隔)[一二三1-3两]\s*行|每\s*段|段\s*首|行\s*首|行\s*尾|段\s*间|"
    r"不\s*合并|不\s*分段|加\s*空行|去\s*空行")


def instr_score(inner: str) -> int:
    """指令味计数：强词各 +1，弱词各 +1（弱词单独不算，累计才起作用）。"""
    s = (inner or "").strip()
    if not s:
        return 0
    return sum(1 for w in _INSTR_WORDS if w in s) + sum(1 for w in _WEAK_WORDS if w in s)


def is_instr_block(inner: str) -> bool:
    """括号内文本是否像「写给我看的指令」而不是「正文内容」。"""
    s = (inner or "").strip()
    if not (1 <= len(s) <= 40):
        return False
    if any(w in s for w in _INSTR_WORDS):
        return True
    if _LAYOUT_RE.search(s):
        return True
    return instr_score(s) >= 2


def strip_instr_blocks(text: str) -> tuple[str, list]:
    """删掉正文里的提示词指令块（行级整行 / 段内嵌块两处都清）。"""
    removed: list = []
    lines = (text or "").split("\n")
    out_lines = []
    for line in lines:
        cur = line.strip()
        # 整行只有一个（或两个）指令块 → 整行删掉（连同残留标点）
        only = _BRACKET_BLOCK_RE.findall(cur)
        if only and _BRACKET_BLOCK_RE.sub("", cur).strip(" 　，,。；;：:") == "" \
                and all(is_instr_block(x) for x in only):
            removed.extend(only)
            continue

        def _drop(m: "re.Match") -> str:
            if is_instr_block(m.group(1)):
                removed.append(m.group(1))
                return ""
            return m.group(0)

        new = _BRACKET_BLOCK_RE.sub(_drop, line)
        if new != line:
            new = re.sub(r"[ \t]{2,}", " ", new).strip()
        out_lines.append(new)
    return "\n".join(out_lines), removed

# 段级相似度阈值：>0.85 判「没改透」（孤狼智写同口径）
SIM_THRESHOLD = 0.85
# 段落配对阈值：低于此值视为「模型另起炉灶」，该段回退原文
MATCH_THRESHOLD = 0.25


# ── 1. 占位保护 ───────────────────────────────────────────────────────────

def mask_entities(text: str) -> tuple[str, dict]:
    """把数字/书名号/英文专名换成占位符。返回 (掩码稿, 回填表)。

    回填表结构：{"⟦N1⟧": "2026", ...}，键含定界符，回填时直接精确替换。
    """
    src = text or ""
    # 原文自带定界符 → 转义，避免与生成的占位符混淆
    if _PH_OPEN in src or _PH_CLOSE in src:
        src = src.replace(_PH_OPEN, _ESC_OPEN).replace(_PH_CLOSE, _ESC_CLOSE)
        escaped = True
    else:
        escaped = False

    table: dict[str, str] = {}
    counter = {"N": 0, "B": 0, "E": 0}

    def _sub(m: "re.Match") -> str:
        tok = m.group(0)
        if tok.startswith("《"):
            kind = "B"
        elif tok[0].isalpha():
            kind = "E"
        else:
            kind = "N"
        counter[kind] += 1
        ph = f"{_PH_OPEN}{kind}{counter[kind]}{_PH_CLOSE}"
        table[ph] = tok
        return ph

    masked = _ENTITY_RE.sub(_sub, src)
    info = {
        "escaped": escaped,
        "counts": dict(counter),
        "total": sum(counter.values()),
    }
    return masked, {"table": table, "info": info}


def restore_entities(text: str, mask: dict) -> tuple[str, dict]:
    """把占位符逐位还原成原值。返回 (还原稿, report)。

    report 字段：
      restored —— 成功还原的条数
      lost     —— 模型把占位符删掉了（该处原值无处安放，只能丢弃并告警）
      dup      —— 同一占位符出现多次（保留第一处，其余也还原，内容重复不算事故）
      leftover —— 还原后仍残留的占位符（已清理）
    """
    table = (mask or {}).get("table") or {}
    out = text or ""
    report = {"restored": 0, "lost": [], "kept_by_model": [],
              "dup": 0, "leftover": [], "escaped": False}

    for ph, val in table.items():
        tries = [ph] + [p.format(o=_PH_OPEN, c=_PH_CLOSE, ph=ph.strip(_PH_OPEN + _PH_CLOSE))
                        for p in _VARIANT_PATTERNS]
        hits = 0
        for cand in tries:
            if not cand or cand == ph:
                continue
            if cand in out:
                hits += out.count(cand)
                out = out.replace(cand, val)
        n = out.count(ph)
        if n:
            hits += n
            out = out.replace(ph, val)
        if hits == 0:
            # 🔴 模型没用占位符、直接把原词写回来了 —— 这是**好结果**不是事故。
            # 初版一律记 lost，实测误报率 100%（模型本来就常原样保留数字）。
            if val and val in out:
                report["kept_by_model"].append(val)
            else:
                report["lost"].append(val)
        else:
            report["restored"] += 1
            if hits > 1:
                report["dup"] += 1

    # 残留占位符（模型改出了本函数没枚举到的形态）：清理并告警
    for m in re.finditer(r"[⟦【\[（(]\s*([NBE])\d{1,3}\s*[⟧】\]）)]", out):
        report["leftover"].append(m.group(0))
    out = re.sub(r"[⟦【\[（(]\s*[NBE]\d{1,3}\s*[⟧】\]）)]", "", out)

    # 原文自带定界符的转义还原
    if _ESC_OPEN in out or _ESC_CLOSE in out:
        out = out.replace(_ESC_OPEN, _PH_OPEN).replace(_ESC_CLOSE, _PH_CLOSE)
        report["escaped"] = True
    return out, report


# ── 2. 分段 1:1 回填 ──────────────────────────────────────────────────────

def split_paragraphs(text: str) -> list[str]:
    """按空行分段，段内单换行保留（与 detox 全局口径一致）。"""
    parts = re.split(r"\n\s*\n", (text or "").strip())
    return [p.strip() for p in parts if p.strip()]


def _ratio(a: str, b: str) -> float:
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    return difflib.SequenceMatcher(None, a, b).ratio()


def align_paragraphs(src: str, out: str) -> tuple[str, dict]:
    """按原文段数 1:1 对齐。返回 (对齐稿, report)。

    规则（顺序即优先级）：
      ⓪ 整篇相似度 <0.35 → 判模型跑偏，整篇回退原文（无论段数是否相等）；
      ① 段数相等 → 直接返回（模型自己守住了 1:1，不重排）；
      ② 段数不等 → **顺序累加填充**：按输出段原始顺序依次喂给原文各段，边界对齐
         到原文段长度比例；段序永不改变；
      ③ 输出段用尽而原文段还有剩余 → 该段回退原文（模型少返回）；
      ④ 输出段有富余 → 并入最后一段（不丢内容）。

    🔴 2026-10-27 初版用 DP 最优配对，实测**会造成重排**：模型把 1 段拆成 2 段时，
    DP 把「后半句」配给本段、「前半句」配给下一段位置，输出读起来顺序是乱的——
    比「少改」严重得多，故改为顺序累加，从机制上消灭重排可能。

    🔴 段内多段合并用单换行（`\n`）而不是空行（`\n\n`）：用空行会让「段内合并」
    重新变成多个段落，段数 1:1 直接失效（初版实测 2 段交出 5 段）。
    """
    sp = split_paragraphs(src)
    op = split_paragraphs(out)
    report = {"src_paras": len(sp), "out_paras": len(op),
              "fallback": [], "merged": 0, "rejected": False}

    if not sp:
        return (out or ""), report
    if not op:
        report["rejected"] = True
        report["fallback"] = list(range(len(sp)))
        return src, report

    if len(sp) > 1 and document_similarity(src, out) < 0.35:
        report["rejected"] = True
        report["fallback"] = list(range(len(sp)))
        return src, report                    # ⓪ 整体跑偏

    if len(sp) == 1 or len(op) == len(sp):
        report["merged"] = max(0, len(op) - 1)
        return out, report                    # ① 结构已 1:1

    total_s = sum(len(x) for x in sp) or 1
    total_o = sum(len(x) for x in op) or 1
    built: list[str] = []
    j = 0
    cum_s = 0
    for i, p in enumerate(sp):
        cum_s += len(p)
        target = total_o * (cum_s / total_s)   # 该段在输出中的目标累计长度
        acc = ""
        while j < len(op):
            acc += ("\n" if acc else "") + op[j]
            j += 1
            if len(acc) >= target:
                break
        if acc.strip():
            built.append(acc)
        else:                                  # ③ 输出段用尽 → 回退原文
            built.append(p)
            report["fallback"].append(i)
    if j < len(op):                            # ④ 富余段并入最后一段
        built[-1] = built[-1] + "\n" + "\n".join(op[j:])
    report["merged"] = max(0, len(op) - len(sp)) if len(op) > len(sp) else 0
    return "\n\n".join(built), report


# ── 3. 相似度 ─────────────────────────────────────────────────────────────

def paragraph_similarity(src: str, out: str) -> float:
    """段级平均相似度（对齐后逐段算，缺段按 0 计）。

    为什么不直接算整篇：整篇 ratio 对「只改了两段、其余原样」不敏感
    （长稿里改两段 ratio 只掉 0.05），而这恰恰是「改不透」的典型形态。
    """
    sp = split_paragraphs(src)
    op = split_paragraphs(out)
    if not sp or not op:
        return 0.0
    k = min(len(sp), len(op))
    vals = [_ratio(sp[i], op[i]) for i in range(k)]
    # 段数不一致 = 结构被改坏，直接按缺段扣分
    vals += [0.0] * abs(len(sp) - len(op))
    return round(sum(vals) / len(vals), 4)


def document_similarity(src: str, out: str) -> float:
    return round(_ratio(src or "", out or ""), 4)


def seed_base(text: str) -> int:
    """由稿件内容派生基准 seed：同稿同参 → 同 seed → 同结果（可复现）。"""
    return zlib.crc32((text or "").encode("utf-8")) & 0x7FFFFFFF


# ── 4. 泄漏清洗 ───────────────────────────────────────────────────────────

def strip_leak(text: str) -> tuple[str, dict]:
    """剥离模型自述式前言/结尾。返回 (清洗稿, report)。"""
    lines = (text or "").split("\n")
    report = {"head": [], "tail": []}
    # 头：最多剥 3 行，且只剥非空行
    head_i = 0
    stripped_head = 0
    while head_i < len(lines) and stripped_head < 3:
        cur = lines[head_i].strip()
        if not cur:
            head_i += 1
            continue
        if any(p.match(cur) for p in _LEAK_HEAD) and len(cur) <= 80:
            report["head"].append(cur)
            lines.pop(head_i)          # 删掉后索引不动，继续看下一个
            stripped_head += 1
        else:
            break
    # 尾：最多剥 2 行
    stripped_tail = 0
    while lines and stripped_tail < 2:
        last = lines[-1].strip()
        if not last:
            lines.pop()
            continue
        if any(p.match(last) for p in _LEAK_TAIL) and len(last) <= 80:
            report["tail"].insert(0, last)
            lines.pop()
            stripped_tail += 1
        else:
            break
    out = "\n".join(lines).strip()
    # 🔴 缺陷1：头尾自述剥完，再清「提示词指令块」（可能在段中，头尾规则管不到）
    out, blocks = strip_instr_blocks(out)
    if blocks:
        report["instr"] = blocks
    return out, report


# ── 5. 数字漂移（验收用，逐字符比对） ─────────────────────────────────────

def number_tokens(text: str) -> list[str]:
    return [re.sub(r"\s+", "", t).replace(",", "") for t in _NUM_RE.findall(text or "")]


def number_drift(src: str, out: str) -> dict:
    """原文数字是否零漂移。返回 {ok, missing, extra, equal}。"""
    a = number_tokens(src)
    b = number_tokens(out)
    from collections import Counter
    ca, cb = Counter(a), Counter(b)
    missing = list((ca - cb).elements())
    extra = list((cb - ca).elements())
    return {"ok": not missing and not extra, "missing": missing,
            "extra": extra, "src_count": len(a), "out_count": len(b)}


# ── 5.5 碎句带回并（缺陷2） ───────────────────────────────────────────────
# 🔴 缺陷2（2026-10-27 P1-1 真机回归）：模型把长句拆成「短句+短句+短句」，
# 碎句带从 0 处涨到 1–2 处（该项满分 15 → 8 或 0），越改越像 AI 脸。
# 处理：只做**回并**，不改用词——把一处碎句带里除最后一句外的句末标点降成逗号，
# 三句并一句。这样既保住原文用词与事实，又直接消掉碎句带。

_SENT_KEEP_RE = re.compile(r"[^。！？!?；;…\n]*[。！？!?；;…]+|[^。！？!?；;…\n]+")
_FRAG_LO, _FRAG_HI = 4, 15


def frag_band_count(text: str) -> int:
    """与 ai_score.check_frag_bands 同口径的碎句带处数；句数 <3 返回 -1（无法判定）。"""
    from .ai_score import split_sentences, cjk_len
    sents = split_sentences(text or "")
    if len(sents) < 3:
        return -1
    bands, cur = 0, 0
    for s in sents:
        if _FRAG_LO <= cjk_len(s) <= _FRAG_HI:
            cur += 1
        else:
            if cur >= 3:
                bands += 1
            cur = 0
    if cur >= 3:
        bands += 1
    return bands


def _defix_para(para: str) -> tuple[str, bool]:
    """把单段内每一处碎句带并成一句（末句标点保留，前面降级成逗号）。"""
    from .ai_score import cjk_len
    spans = [(m.start(), m.end(), m.group(0)) for m in _SENT_KEEP_RE.finditer(para)]
    spans = [x for x in spans if cjk_len(x[2]) >= 2]
    if len(spans) < 3:
        return para, False
    lens = [cjk_len(s) for _, _, s in spans]
    edits = []
    i = 0
    while i < len(spans):
        if _FRAG_LO <= lens[i] <= _FRAG_HI:
            j = i
            while j < len(spans) and _FRAG_LO <= lens[j] <= _FRAG_HI:
                j += 1
            if j - i >= 3:
                for k in range(i, j - 1):
                    _, en, seg = spans[k]
                    if seg.rstrip()[-1:] in list("。！？!?；;…"):
                        edits.append(en - 1)
            i = j
        else:
            i += 1
    if not edits:
        return para, False
    chars = list(para)
    for pos in edits:
        chars[pos] = "，"
    return "".join(chars), True


def fix_frag_bands(src: str, out: str, max_round: int = 3) -> tuple[str, dict]:
    """改写稿碎句带比原文多时回并，最多 3 轮。返回 (处理稿, report)。

    base=-1 表示原稿句数不足（口播稿/无标点）**无法判定**，不等于「原稿有碎句带」。
    这种情况按 0 处算基准：原稿判不出节奏，也不该让改写稿凭空多出一处碎句带。
    """
    base = frag_band_count(src)
    before = frag_band_count(out)
    rep = {"base": base, "before": before, "after": before, "rounds": 0}
    if before < 0:
        return out, rep            # 改写稿自己判不出，无从下手
    floor = max(base, 0)
    if before <= floor:
        return out, rep
    parts = re.split(r"(\n\s*\n)", out or "")
    cur = out
    for r in range(max_round):
        new_parts, changed = [], False
        for idx, p in enumerate(parts):
            if idx % 2 == 1:            # 分隔符原样保留
                new_parts.append(p)
                continue
            np_, ch = _defix_para(p)
            changed = changed or ch
            new_parts.append(np_)
        if not changed:
            break
        cur = "".join(new_parts)
        parts = re.split(r"(\n\s*\n)", cur)
        rep["rounds"] = r + 1
        now = frag_band_count(cur)
        rep["after"] = now
        if now <= floor:
            break
    rep["after"] = frag_band_count(cur)
    return cur, rep


# ── 流水线编排 ────────────────────────────────────────────────────────────

def postprocess(src: str, raw_out: str, mask: dict) -> tuple[str, dict]:
    """改写产物 → 可交付正文。顺序：回填 → 泄漏清洗 → 1:1 对齐 → 数字比对。

    🔴 清洗必须在**对齐之前**：模型的前言（「好的，以下是改写后的文章」）会被
    空行分成独立段落，先对齐就会被当成「模型多拆的段」并进正文，段落数直接错位
    （2026-10-27 初版实测：3 段原稿被数成 5 段）。
    """
    restored, r_rep = restore_entities(raw_out, mask)
    cleaned, l_rep = strip_leak(restored)
    if not cleaned.strip():
        cleaned = src            # 全被清洗掉 = 模型只吐了前言，回退原稿
        l_rep["head"].append("（清洗后为空，已回退原稿）")
    aligned, a_rep = align_paragraphs(src, cleaned)
    # 🔴 缺陷2：对齐之后再回并碎句带（对齐会按段落重排，先并会打乱配对）
    aligned, f_rep = fix_frag_bands(src, aligned)
    drift = number_drift(src, aligned)
    rep = {
        "mask": (mask or {}).get("info") or {},
        "restore": r_rep,
        "align": a_rep,
        "leak": l_rep,
        "frag": f_rep,
        "drift": drift,
        "sim_para": paragraph_similarity(src, aligned),
        "sim_doc": document_similarity(src, aligned),
    }
    return aligned, rep


def describe(rep: dict) -> str:
    """把 report 压成一句人话，供 `LOCAL_FALLBACK_NOTE` 拼接。"""
    bits = []
    r = rep.get("restore") or {}
    if r.get("lost"):
        bits.append("占位回填丢失 " + "、".join(r["lost"][:5]) + "（模型删了占位符）")
    if r.get("leftover"):
        bits.append(f"清理残留占位符 {len(r['leftover'])} 处")
    a = rep.get("align") or {}
    if a.get("fallback"):
        bits.append(f"{len(a['fallback'])} 段模型没返回，已回退原文")
    if a.get("merged"):
        bits.append(f"模型多拆 {a['merged']} 段，已并回原位")
    l = rep.get("leak") or {}
    if l.get("head") or l.get("tail"):
        bits.append(f"剥离模型自述 {len(l.get('head') or []) + len(l.get('tail') or [])} 行")
    if l.get("instr"):
        bits.append(f"剥离提示词指令块 {len(l['instr'])} 处（"
                    + "、".join(str(x)[:16] for x in l["instr"][:2]) + "）")
    f = rep.get("frag") or {}
    if f.get("rounds"):
        _after = f.get("after")
        bits.append(f"碎句带回并 {f.get('before')}→"
                    f"{('已消除' if _after is not None and _after < 0 else _after)} 处")
    d = rep.get("drift") or {}
    if d and not d.get("ok"):
        if d.get("missing"):
            bits.append("数字丢失：" + "、".join(d["missing"][:5]))
        if d.get("extra"):
            bits.append("数字新增：" + "、".join(d["extra"][:5]))
    return "；".join(bits)
