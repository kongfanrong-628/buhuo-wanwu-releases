# -*- coding: utf-8 -*-
"""规则后处理层 rule_post —— 打散检测器依赖的统计指纹（2026-10-13 P20-c）

## 为什么需要这一层（它才是对标软件「100%」的真正核心）

本地模型改写解决的是**语义层**（换说法、重组句子），但 AIGC 检测器的判据里有很大一部分是
**统计指纹**——它不是"这句话什么意思"，而是"这段文字的分布长什么样"：

| 检测器盯的统计特征 | 官方/第三方披露的比例 | 本层对应的规则 |
|---|---|---|
| 句长集中度 | 约 65% 的句子落在 15-25 字 | `spread_lengths()` |
| 书面化/程式化词频 | 是人类写作的约 3.2 倍 | `swap_ai_words()` |
| 模板化过渡词 | 约 80% 的 AI 文本命中"首先/其次" | `merge_enumerations()` |
| 名词化结构 | 是人类写作的约 2.8 倍 | `denominalize()` |
| 情感词密度 | 不足人类写作的约 1/3 | `inject_rhythm()` |

**模型改不动这些分布**（它自己就是 LLM，产出的仍是"LLM 会产出的分布"）；
而规则层是**确定性操作**，改的就是分布本身。所以：
- 它**不随检测器版本更新而失效**（改的是文本特征，不是针对某个检测器的补丁）；
- 它**零成本、零依赖、可解释**（每条改动都能说出改了什么）。

## 🔴 三条硬约束

1. **事实零丢失**：任何一步改动前后，数字/日期/百分比的**多重集必须完全一致**。
   校验不过 → **整步回退**，并在 changes 里如实记录"因事实校验未过已回退"。
   （改写模型最容易出事实滑移，规则层绝不能重蹈覆辙。）
2. **尊重用户的"一个字不许改"清单**（`user_model` 的 `detox_frozen`）：命中该清单的片段，
   所有规则一律跳过。这是用户的招牌，改了就不是他。
3. **强度可调 + 可解释**：`level` 三档（轻/中/重），返回逐条 changes，前端要能展示。

用法：
    from app.core import rule_post
    r = rule_post.apply(text, level="mid")
    r["text"]      # 处理后的文本
    r["changes"]   # [{"rule":..., "count":..., "detail":...}]
    r["reverted"]  # 因事实校验回退的规则名
    rule_post.hits(text)   # 只报命中，不改（供 UI 预览）
"""
from __future__ import annotations

import re
from collections import Counter

# ── 强度档 ────────────────────────────────────────────────────────────────
LEVELS = ("light", "mid", "heavy")
_DEFAULT = "mid"

# 编号式排比标记（模板化过渡词，80% AI 文本命中）
_ENUM_MARKS = (
    "首先", "其次", "再次", "最后", "最终", "然后", "接着",
    "其一", "其二", "其三", "其四", "其五",
    "第一", "第二", "第三", "第四", "第五",
    "一方面", "另一方面", "总结来说", "综上所述", "总而言之", "总的来说",
)

# 书面化 / 程式化词 → 更口语的替代（不是同义词替换游戏，是**降词频层级**）
_AI_WORDS = {
    "显著": "明显", "极大地": "很", "有效地": "真的能", "值得注意的是": "",
    "众所周知": "", "不难看出": "", "由此可见": "所以说", "需要指出的是": "",
    "在当今社会": "现在", "随着…的发展": "", "赋能": "帮上忙", "助力": "帮到",
    "抓手": "办法", "闭环": "转起来的一圈", "深入探讨": "仔细聊聊",
    "全方位": "各方面", "多维度": "几个角度", "持续性": "一直",
    "重要性": "要紧的地方", "必要性": "该不该做", "具备": "有", "旨在": "想",
    "致力于": "一直在做", "基于此": "所以", "与此同时": "同时",
}

# 名词化：动词短语被名词化（人类写作的约 2.8 倍）
_DENOM = re.compile(r"(进行|实现|做出|加以|予以|开展|实施)([一-龥]{2})")

# 句子切分（中英标点）
_SPLIT = re.compile(r"(?<=[。！？!?；;])")

# 事实 token：数字/百分比/日期片段
_FACT = re.compile(r"\d+(?:\.\d+)?(?:%|万|亿|w)?")

# 插入语池（按强度取用）——必须"像人随手加的"，不是装饰
_RHYTHM = ("说实话", "说真的", "你懂的", "说白了", "讲道理", "有意思的是")


# ───────────────────────── 工具 ─────────────────────────

def facts(text: str) -> Counter:
    """事实 token 的多重集（数字/日期/百分比）。"""
    return Counter(_FACT.findall(text or ""))


def _frozen_list() -> list:
    """用户声明"一个字都不许改"的表述（user_model.detox_frozen）。失败返回 []。"""
    try:
        from app.core import user_model as UM
        v = UM.get("detox_frozen")
        if isinstance(v, str):
            v = [x for x in re.split(r"[,，\n]", v) if x.strip()]
        return [str(x).strip() for x in (v or []) if str(x).strip()]
    except Exception:  # noqa: BLE001
        return []


def _protect(text: str, frozen: list):
    """把"不许改"的片段挖出来占位，返回 (带占位符的文本, 还原表)。

    🔴 用占位符而不是"改完再替换回去"：后者会在占位片段内部被规则命中时出问题。
    """
    table = {}
    out = text or ""
    for i, f in enumerate(frozen):
        if not f or f not in out:
            continue
        ph = f"\u0000F{i}\u0000"
        table[ph] = f
        out = out.replace(f, ph)
    return out, table


def _restore(text: str, table: dict) -> str:
    out = text or ""
    for ph, f in table.items():
        out = out.replace(ph, f)
    return out


def _sentences(text: str) -> list:
    parts = [p for p in _SPLIT.split(text or "") if p]
    return parts or ([text] if text else [])


# ───────────────────────── 五条规则 ─────────────────────────
# 每条规则签名统一：fn(text, level) -> (new_text, count, detail)

def merge_enumerations(text: str, level: str = _DEFAULT):
    """编号式排比 → 叙述式。**杀伤力最大的一条**（模板化过渡词是 80% AI 文本的共性）。

    做法：删掉句首的序数标记，句尾用轻连接词续接；连续 3 条以上时保留最后一条的收束感。
    🔴 关键判据（也是前端提醒的依据）：改完后不得再出现「其一/其二/首先/其次」。
    """
    sents = _sentences(text)
    hits = 0
    out = []
    for s in sents:
        stripped = s.lstrip()
        hit = None
        for m in _ENUM_MARKS:
            if stripped.startswith(m):
                hit = m
                break
        if not hit:
            out.append(s)
            continue
        rest = stripped[len(hit):].lstrip(" ，,、：:")
        if not rest:
            out.append(s)
            continue
        # 保留原句的前导空白（表格/缩进场景）
        lead = s[:len(s) - len(stripped)]
        out.append(lead + rest)
        hits += 1
    new = "".join(out)
    return new, hits, f"去掉 {hits} 处序数排比标记（首先/其次/其一…）"


def swap_ai_words(text: str, level: str = _DEFAULT):
    """书面化 / 程式化词 → 降层级说法。"""
    new, hits = text, 0
    for bad, good in _AI_WORDS.items():
        if bad not in new:
            continue
        n = new.count(bad)
        new = new.replace(bad, good)
        hits += n
    # 清掉替换后可能出现的双标点/空句首
    new = re.sub(r"[，,]{2,}", "，", new)
    new = re.sub(r"^[，,]\s*", "", new)
    return new, hits, f"替换 {hits} 处书面化/程式化词"


def denominalize(text: str, level: str = _DEFAULT):
    """名词化还原：「进行分析」→「分析」、「实现提升」→「提上来」。"""
    hits = [0]

    def _sub(m):
        hits[0] += 1
        return m.group(2)

    new = _DENOM.sub(_sub, text)
    return new, hits[0], f"还原 {hits[0]} 处名词化结构"


def spread_lengths(text: str, level: str = _DEFAULT):
    """句长打散：连续 3 句长度相近（15-25 字）时，在最长句的主要逗号处断开。

    打的是「约 65% 句子集中在 15-25 字」这个集中度特征。
    🔴 只在句子内部有逗号时断，断不动就跳过（不强拆，避免破坏可读性）。
    """
    if level == "light":
        return text, 0, "轻档跳过句长打散"
    sents = _sentences(text)
    word_re = re.compile(r"[一-龥]")
    new, fixed = [], 0
    run = 0
    for i, s in enumerate(sents):
        core = s.strip()
        n = len(word_re.findall(core))
        mid = 15 <= n <= 25
        if mid:
            run += 1
        else:
            run = 0
        if run >= 3 and "，" in core:
            k = core.rfind("，")
            if 0 < k < len(core) - 1:
                left, right = core[:k] + "。", core[k + 1:]
                new.append(left + right)
                fixed += 1
                run = 0
                continue
        new.append(s)
    return "".join(new), fixed, f"打散 {fixed} 处连续等长句"


def inject_rhythm(text: str, level: str = _DEFAULT):
    """节奏注入：在句间插入口语碎片（提升情感词密度）。

    档位：light=不插 / mid=每 ~6 句插 1 处 / heavy=每 ~3 句插 1 处。
    🔴 只插在句首且**不改动原句内容**，插完立刻过事实校验（不改字所以必然通过）。
    """
    step = {"light": 0, "mid": 6, "heavy": 3}.get(level, 6)
    if not step:
        return text, 0, "轻档跳过节奏注入"
    sents = _sentences(text)
    if len(sents) < 4:
        return text, 0, "句子太少，跳过节奏注入"
    out, n = [], 0
    for i, s in enumerate(sents):
        if i and i % step == 0:
            w = _RHYTHM[(i // step - 1) % len(_RHYTHM)]
            out.append(w + "，")
            n += 1
        out.append(s)
    return "".join(out), n, f"注入 {n} 处口语节奏"


# 顺序很重要：先去模板词，再降词频，再还原名词化，最后动节奏。
# 句长打散放最后（前面的改动会改变句长分布，放前面判断会失真）。
_PIPELINE = (
    ("merge_enumerations", merge_enumerations),
    ("swap_ai_words", swap_ai_words),
    ("denominalize", denominalize),
    ("inject_rhythm", inject_rhythm),
    ("spread_lengths", spread_lengths),
)


# ───────────────────────── 对外接口 ─────────────────────────

def hits(text: str) -> list:
    """只报命中、不改文本（供 UI 预览「这段能被改掉哪些 AI 特征」）。"""
    out = []
    for name, fn in _PIPELINE:
        try:
            _, n, detail = fn(text, "heavy")
        except Exception:  # noqa: BLE001
            continue
        if n:
            out.append({"rule": name, "count": n, "detail": detail})
    return out


def apply(text: str, level: str = _DEFAULT, respect_frozen: bool = True) -> dict:
    """跑完整规则链。返回 {text, changes, reverted, level, frozen_used}。

    🔴 每一步都过事实校验（数字多重集不变）；不过就**整步回退**并记录到 reverted。
    """
    lv = level if level in LEVELS else _DEFAULT
    src = text or ""
    if not src.strip():
        return {"text": src, "changes": [], "reverted": [], "level": lv,
                "frozen_used": 0, "note": "空文本"}

    frozen = _frozen_list() if respect_frozen else []
    work, table = _protect(src, frozen)
    base_facts = facts(src)

    changes, reverted = [], []
    cur = work
    for name, fn in _PIPELINE:
        try:
            new, n, detail = fn(cur, lv)
        except Exception as e:  # noqa: BLE001
            reverted.append({"rule": name, "why": f"异常：{type(e).__name__}"})
            continue
        if not n or new == cur:
            continue
        # 🔴 事实校验：数字多重集必须完全一致，否则整步回退
        if facts(_restore(new, table)) != base_facts:
            reverted.append({"rule": name, "why": "事实校验未过（数字/日期有增减），已回退"})
            continue
        cur = new
        changes.append({"rule": name, "count": n, "detail": detail})

    final = _restore(cur, table)
    return {
        "text": final,
        "changes": changes,
        "reverted": reverted,
        "level": lv,
        "frozen_used": len(table),
        "note": (f"共 {len(changes)} 条规则生效，{len(reverted)} 条回退 "
                 f"（{len(table)} 处「不许改」片段已保护）"),
    }
