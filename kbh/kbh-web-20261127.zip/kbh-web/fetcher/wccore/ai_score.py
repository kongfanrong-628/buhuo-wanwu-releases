#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
中文 AI 味机械扫描 v1.0  (2026-09-02 · Claw)

为什么要有这个脚本：
    之前所有「去 AI 味规则」都是写在 SKILL.md 里的文字，靠 LLM 自觉执行——
    必然漏跑（humanizer-zh 装了 50 天零调用就是实证）。
    本脚本把「能机械测量的部分」全部量化，跑完直接出数字和判定，
    **不依赖任何主观判断，跑不出报告 = 没过**。

能测什么（统计特征层 + 中文指纹层）：
    1. Burstiness   句长变异系数（朱雀核心指标）
    2. 碎句带       连续短句扎堆（全短句 = 另一种 AI 脸）
    3. 真事密度     私有信息标记密度（困惑度的代理指标）
    4. AI 词汇      中文高频 AI 词命中
    5. 中文指纹     C1「…着」伪深度 / C2「不是A而是B」/ 破折号 / Emoji / 数字罗列 / 理论背书
    6. 伪金句结尾   "真正的…""核心就一句话"类收尾

测不了什么（仍需 humanizer-zh / LLM 层判断，本脚本不替代）：
    - 内容是否真的有认知差、人事是否具体（语义层）
    - 局部修辞是否自然
    → 机械层跑完后再跑 humanizer-zh，两层互补。

用法：
    python ai_smell_scan.py <文件路径> [--md] [--json]

参数：
    --md    输出 Markdown 格式报告（便于贴进预检报告）
    --json  输出 JSON（便于程序消费）
    默认输出终端彩色报告

判定：
    >= 78  PASS    可进入下一关
    60-77  WARN    建议回改后再发
    <  60  FAIL    必须重写

    🔴 P1-13b 二轮（2026-10-27）：PASS 线由 80 降到 78，与 dual_review.SEG_MIN_SCORE 对齐。
    依据 32 篇复扫（AI 10 / 真人 22）：AI 最高 73、真人最低 79，中间空 6 分；
    80 线误杀 1 篇真人（87→79，顿号 11.83/千字），81 线误杀 3、82 线误杀 4。
    取 78 = 零漏放零误杀，并给新样本留 2 分余量。整篇线与段级线必须是同一个数字，
    否则会出现「段级判它改、整篇判它过」的自相矛盾。

作者：Claw（胜元/孔不惑AIko 内容管线）
"""

import re
import sys
import json
import statistics
from pathlib import Path

# ============ 词库 ============

# ── 2026-10-26 工单 P0-3：AI 词表分级（误报降噪）────────────────────────────
# 背景（实测）：旧版把「赛道 / 方法论 / 迭代 / 展示 / 沉淀 / 闭环」等词与
# 「综上所述 / 值得注意的是」等官样套话等权计分，导致**作者本人的 3 篇教程稿
# 全部被判 0 分**（人文历史稿 55 分 FAIL、贴图版 55 分 FAIL）。这些词是 AI 圈
# 日常口语，不等于 AI 腔；真正暴露机器的只有「官样总结 + 伪深刻固定搭配」。
# 分级原则：
#   STRONG = 只有 AI/公文才成句使用的固定套话，命中即计满权；
#   WEAK   = 领域实词，单独出现属正常写作，需「≥2 个不同词共现」才计入且只算 0.3 权。
AI_WORDS_STRONG = [
    "此外", "至关重要", "综上所述", "值得注意的是", "众所周知", "不难发现",
    "由此可见", "毋庸置疑", "保驾护航", "提质增效", "持续深化", "深刻反映",
    "未来可期", "深远影响", "关键所在", "不可或缺", "标志着", "全方位",
    "一站式", "沉浸式", "革命性", "重塑", "底层逻辑", "组合拳", "充满活力",
    "宝贵的", "相互作用", "织锦", "深入探讨", "关键性", "重要意义",
]

AI_WORDS_WEAK = [
    "持久", "增强", "培养", "获得", "突出", "复杂性", "复杂", "格局",
    "展示", "证明", "赋能", "抓手", "闭环", "对齐", "沉淀", "迭代", "生态",
    "维度", "层面", "赛道", "护城河", "颗粒度", "方法论", "打法", "颠覆",
    "显著",
]

# 兼容旧引用（外部按单一列表使用的地方不受影响）
AI_WORDS = AI_WORDS_STRONG + AI_WORDS_WEAK

# ── 总分级距（整篇口径）────────────────────────────────────────────────
# 🔴 与 dual_review.SEG_MIN_SCORE 必须同一个数字：段级说「这段要改」、整篇说「可以过」，
#    同一次审稿会自相矛盾。改动时两边一起改（_verify_p1_13b 有断言守着）。
PASS_LINE = 78
WARN_LINE = 60

# 权重与阈值（2026-10-26 用 3 篇真人稿 + 2 篇 AI 腔稿校准，见 P0-3 实测报告）
AI_W_STRONG = 1.0        # 强信号每处权重
AI_W_WEAK = 0.3          # 弱信号每处权重
AI_WEAK_MIN_DISTINCT = 2  # 弱词至少这么多个不同词共现才计
AI_META_WEIGHT = 0.4     # 标题 / 引用 / 表格行内命中的折扣（小标题点题不算 AI 腔）

# 伪金句 / 总结腔收尾标志
# 2026-10-27 P1-9（P1-4 基线暴露）：旧版把这些词混在一个表里、命中一个就归零，
# 结果 3 篇真人稿（气候王朝 / 张居正 / 资治通鉴）只因为结尾出现「真正的」被判 0 分。
# 「真正的」在中文里是极普通的强调词，不是金句指纹。改为强弱两级：
#   强标志：AI 收尾套路，命中即 0 分
#   弱标志：单独出现属正常行文，需同段命中 >=2 个不同词才计
GOLDEN_MARKERS_STRONG = [
    "核心就一句话", "一言以蔽之", "综上所述", "总而言之", "归根到底", "归根结底",
    "让我们一起", "让咱们", "共同期待", "未来可期", "携手", "道阻且长",
    "行则将至", "任重道远", "砥砺前行", "在路上的我们", "持续迭代的过程",
    "这场革命", "这场变革", "新的篇章",
]
GOLDEN_MARKERS_WEAK = [
    "真正的", "这才是", "值得期待", "本质上说", "本质上，", "说到底", "核心就是",
]
GOLDEN_SENT_MARKERS = GOLDEN_MARKERS_STRONG + GOLDEN_MARKERS_WEAK

# 私有信息标记（拉高困惑度的东西：具体时间 / 数字 / 对话 / 引语）
TIME_ANCHORS = [
    "去年", "今年", "前年", "上周", "这周", "昨天", "今天", "明天", "那天",
    "三个月前", "半年前", "一个月前", "两年前", "当时", "有一次", "那天下午",
    "上个月", "前几天", "前两天", "去年这个时候", "上个月底", "上周三",
    # 2026-10-27 P0-8：口播/历史稿的高频时间锚点（真人常用、AI 原稿罕用）
    "那年", "那次", "那会儿", "当晚", "第二天", "头一天", "小时候",
    "十来岁", "开春", "年底", "年初", "正月", "临走前", "年纪",
]

# --- P0-8 中文数字私有信息 ---
# 依据 P1-4 基线回归：22 篇朱雀判 100% 真人稿里有 13 篇「真事密度 = 0」，
# 直接丢 20 分且被判「几乎没有私有信息 — 朱雀必判高 AIGC」，
# 根因是旧版只认 r"\d+"，而口播/历史讲解稿写的是「万历十五年」「三百万」「一九一二年」。
# 修法：补中文数字，但必须带量词/单位才计，否则「一些/一起/一切/一直」全部误命中。
CN_DIGIT = "一二三四五六七八九十百千万零〇两"
CN_NUM_UNIT = re.compile(
    rf"[{CN_DIGIT}]{{1,8}}"
    r"(?:年|月|日|号|岁|人|次|天|小时|分钟|秒|米|公里|吨|斤|元|块|万|亿|倍|度|层|座|篇|本|章|回|场|届|级|代)"
)
# 中文年份写法：一九一二年 / 二零二五年（不带量词也算硬事实）
CN_YEAR = re.compile(rf"[一二三四五六七八九][〇零一二三四五六七八九]{{3}}年?")

# --- P1-12 真事密度口径重做（2026-10-27）---
# 盲测发现旧口径完全失效：12/12 篇 AI 稿拿满 20 分，真人稿反而落在 14-17。
# 34 篇特征分离度探测（AUC = P(真人值 > AI 值)，0.5 无区分）结论：
#   引语密度    AUC 0.015（AI 11.40/千字 vs 真人 0.67）→ 旧口径最大的送分口
#   阿拉伯数字  AUC 0.409（AI 高）→ 反向
#   顿号        AUC 0.114（AI 15.54 vs 真人 3.84）→ 强反向
#   第一人称    AUC 0.720 / 时间锚点 0.695 / 问号 0.689 → 弱正向
# 新口径改为「正向多通道取高 + 反向 AI 特征扣分」，真事密度 AUC 0→0.958。
RE_QUOTE_DLG = re.compile(r"[\"“”「」『』'][^\"“”「」『』']{2,}[\"“”「」『』']")
ABSTRACT_WORDS = ["价值", "意义", "本质", "底层", "逻辑", "维度", "生态", "体系", "赋能",
                  "闭环", "抓手", "链路", "范式", "格局", "认知", "红利", "方法论", "底层逻辑"]

# 反义对仗 / 伪深刻结构（中文自媒体第一大指纹）
ANTITHESIS_PATTERNS = [
    r"不仅是?[^。！？]{1,25}[，,]更是",
    r"不仅仅是?[^。！？]{1,25}[，,]?更是",
    r"不只是[^。！？]{1,25}[，,]?而是",
    r"与其说[^。！？]{1,25}[，,]?不如说",
    r"不是[^。！？]{1,25}[，,]而是",
]

# 数字罗列骨架（注意：单个"第一种""第三段"是具体内容，不算骨架；
# 只有序号**连续递增出现 >=2 次**才构成骨架 —— 见 check_list_skeleton）
CN_NUM = "一二三四五六七八九十"

EMOJI_PATTERN = re.compile(
    "[\U0001F300-\U0001FAFF\U00002600-\U000027BF\U0001F000-\U0001F2FF"
    "\U00002190-\U000021FF\U00002B00-\U00002BFF\U00002700-\U000027BF]"
)

# --- 句式层 / 统计层词表（2026-10-25「过朱雀」批次新增）---
# 数据来源：sepia `languages/zh.md` 中文实测（人 vs ChatGPT），以及
# Humanizer-zh #26/27/29、human-writing check_prose.py 的检测项。
# 🔴 每个数字都是「观察过一次的方向」，不是校准常数；阈值在本文件实测校准段说明。

# 连词：sepia 实测 人 0.013 vs AI 0.036，「和」单项 人 4.13 vs AI 11.76 每答
CN_CONNECTIVES = [
    "和", "以及", "并且", "同时", "此外", "因此", "然而", "而且", "于是",
    "所以", "因为", "虽然", "但是", "不仅", "还", "又", "再者", "与此同时",
    "在此基础上", "除此之外", "总的来说",
]

# 语气词 / 口语颗粒：sepia 实测 人 0.016 vs AI 0.003（**人高 5 倍**）
# → 这是唯一「越少越像 AI」的指标，与其余指标方向相反。
CN_MODAL_PARTICLES = [
    "啊", "呀", "吧", "呢", "嘛", "哦", "嗯", "哈", "唉", "哎", "呗",
    "咯", "喽", "啦", "罢了", "来着", "着呢", "而已", "就是说", "怎么说",
]

# 名词化：动词被名词化后配一个空动词（Humanizer-zh #27、sepia zh §2 双字 padding）
NOMINALIZE_HEADS = ["进行", "加以", "予以", "做出", "作出", "开展", "实施", "给予", "做了"]

# 借喻簇：抽象名词配具体动词写抒情（human-writing LYRIC_WORDS / metaphor_cluster）
# 「时间保管细节」「焦虑显出形状」「岁月磨平棱角」——公众号 AI 稿最高频的假文学
LYRIC_SUBJECTS = ["时间", "岁月", "命运", "焦虑", "人生", "时代", "生活", "青春",
                  "记忆", "孤独", "努力", "成长", "初心", "理想", "现实"]
LYRIC_VERBS = ["保管", "显出", "磨平", "吞噬", "撕裂", "见证", "雕刻", "沉淀",
               "拥抱", "诉说", "低语", "回答", "惩罚", "奖赏", "记住", "遗忘",
               "张开", "关上", "收拢", "铺开"]

# 中长句等长 run：sepia §5「3 句以上相邻近等长」是唯一方向一致的句法指标
RUN_MIN_LEN = 22          # 只查中长句（短句扎堆已由「碎句带」负责）
RUN_TOL = 0.15            # 相邻两句长度差 <15% 视为「近等长」

SENT_SPLIT = re.compile(r"(?<=[。！？!?；;…])\s*")
CJK = re.compile(r"[\u4e00-\u9fff]")


# ============ 解析 ============

def load_text(path: str) -> str:
    """读文件，自动剥掉 Markdown 标题符号与 HTML 注释块。"""
    raw = Path(path).read_text(encoding="utf-8", errors="ignore")
    # 去 HTML 注释（导演备注块）
    raw = re.sub(r"<!--.*?-->", "", raw, flags=re.S)
    # 去 Markdown 标题符号
    raw = re.sub(r"^#{1,6}\s*", "", raw, flags=re.M)
    # 去代码块
    raw = re.sub(r"```.*?```", "", raw, flags=re.S)
    # 去行内代码与加粗符号
    raw = re.sub(r"`[^`]*`", "", raw)
    raw = raw.replace("**", "").replace("*", "")
    return raw


def split_sentences(text: str):
    parts = SENT_SPLIT.split(text)
    out = []
    for p in parts:
        p = p.strip()
        if not p:
            continue
        # 去掉换行，视作一句
        p = p.replace("\n", "")
        if len(CJK.findall(p)) >= 2:  # 至少 2 个汉字才算一句
            out.append(p)
    return out


# --- P0-9 停顿单元兜底 ---
# 依据 P1-4 基线回归：5 篇朱雀判 100% 真人稿（口播/视频稿）整篇按全角标点只切出
# 1–2 句 —— 它们通篇没有「。！？」，只有逗号和换行。句级切分一失效，
# burstiness 直接「样本不足」给 10 分、碎句带「无碎句带」白送 15 分，两项全失真。
# 朱雀的 burstiness 本质是 token 序列的困惑度波动，并不依赖句号，
# 因此句数不足时改用「停顿单元」（逗号/顿号/冒号/换行）作为节奏样本。
PAUSE_SPLIT = re.compile(r"[。！？!?；;…，,、：:\n]+")


def split_pause_units(text: str):
    out = []
    for p in PAUSE_SPLIT.split(text or ""):
        p = p.strip().replace("\n", "")
        if len(CJK.findall(p)) >= 2:
            out.append(p)
    return out


def split_paragraphs(text: str):
    paras = re.split(r"\n\s*\n|\n", text)
    return [p.strip() for p in paras if p.strip() and len(CJK.findall(p)) >= 2]


def cjk_len(s: str) -> int:
    """汉字数（不含标点、不含纯数字字母，更贴近'句子长度'感知）"""
    return len(CJK.findall(s))


# ============ 六项检测 ============

def check_burstiness(sents, text=None):
    """1. 句长变异系数 CV = stdev / mean。朱雀 burstiness 的代理指标。

    P0-9：句数 <4（无标点稿）时改用停顿单元计算，避免「样本不足」白送 10 分。
    """
    src = sents
    fallback = False
    if len(sents) < 4 and text:
        units = split_pause_units(text)
        if len(units) >= 4:
            src, fallback = units, True
    if len(src) < 4:
        return {"cv": 0, "std": 0, "mean": 0, "score": 10, "note": "句子太少，样本不足"}
    lens = [cjk_len(s) for s in src]
    mean = statistics.mean(lens)
    std = statistics.pstdev(lens)
    cv = std / mean if mean else 0

    # 2026-10-27 P0-9 补丁：停顿单元比句子短、长度天然更集中，
    # 沿用句子阈值会把正常口播稿系统性判成「过于均匀」（415 字稿 CV0.444 只得 5 分）。
    # 口径不同则阈值同步下移，而不是放宽整体标准。
    hi, mid, lo = (0.65, 0.50, 0.35) if fallback else (0.75, 0.60, 0.45)

    if cv >= hi:
        score, note = 25, "长短交错充分"
    elif cv >= mid:
        score, note = 20, "节奏尚可"
    elif cv >= lo:
        score, note = 12, "偏均匀，需加长句岔开"
    else:
        score, note = 5, "句长过于均匀 — burstiness 高风险"

    if fallback:
        note = "（无全角标点，按停顿单元计）" + note

    return {"cv": round(cv, 3), "std": round(std, 1), "mean": round(mean, 1),
            "score": score, "note": note, "unit": "停顿单元" if fallback else "句",
            "samples": len(src),
            "min": min(lens), "max": max(lens)}


def check_frag_bands(sents, text=None):
    """2. 碎句带：连续 >=3 句长度都落在 [4,15] 区间。全短句 = 另一种 AI 脸。

    P0-9：句数 <3 时无法判断（不是「干净」），按中性 8 分处理，
    不再白送满分 15 —— 旧版让 5 篇无标点真人稿凭空多拿 7 分，掩盖了真实问题。
    """
    if len(sents) < 3:
        return {"count": 0, "bands": [], "score": 12,
                "note": "缺全角标点，句级节奏无法判定：口播稿短促是真人特征，"
                        "但建议补齐标点后再判一次"}
    lens = [cjk_len(s) for s in sents]
    bands, cur = [], []
    for i, L in enumerate(lens):
        if 4 <= L <= 15:
            cur.append(i)
        else:
            if len(cur) >= 3:
                bands.append(cur)
            cur = []
    if len(cur) >= 3:
        bands.append(cur)

    n = len(bands)
    if n == 0:
        score, note = 15, "无碎句带"
    elif n == 1:
        score, note = 8, f"1 处碎句带（句位 {bands[0][0]+1}-{bands[0][-1]+1}），建议拆开"
    else:
        score, note = 0, f"{n} 处碎句带，节奏发抖 — 必须改"

    return {"count": n, "bands": [[b[0] + 1, b[-1] + 1] for b in bands],
            "score": score, "note": note}


def check_truth_density(text):
    """3. 真事密度 → 私有信息分（2026-10-27 P1-12 口径重做）。

    旧口径（数字 + 中文数字 + 中文年份 + 时间锚点 + 引语，够密就满分）在 34 篇盲测上
    完全失效：12/12 篇 AI 稿拿满 20 分，22 篇真人稿反而多数落在 14-17 分，AUC = 0.5。
    根因是「引语」和「阿拉伯数字」是 AI 的高频动作，不是真人的私有信息：
    AI 引语 11.40/千字 vs 真人 0.67，AI 顿号 15.54 vs 真人 3.84。

    新口径 = max(三个正向通道) - (三类 AI 特征扣分)：
      正向：第一人称密度 / 时间锚点密度 / 问号密度（任一通道达标即给分，历史稿不必写「我」）
      反向：引语过密、顿号罗列、抽象大词过密
    实测：真事密度 AUC 0→0.958，真人均值 16.1，AI 均值 2.7。
    """
    total = len(CJK.findall(text))
    if total == 0:
        return {"density": 0, "marks": 0, "detail": {}, "total_chars": 0,
                "score": 0, "note": "无中文内容"}

    k = 1000.0 / total

    def dens(n):
        return round(n * k, 2)

    # ---- 正向三通道：私有细节的三种载体 ----
    d_first = dens(text.count("我"))
    d_time = dens(sum(text.count(w) for w in TIME_ANCHORS))
    d_ask = dens(text.count("？"))

    def tier(v, ths, pts=(20, 14, 8)):
        for t, p in zip(ths, pts):
            if v >= t:
                return p
        return 0

    pos_first = tier(d_first, (6.0, 3.0, 1.5))
    pos_time = tier(d_time, (1.0, 0.6, 0.3))
    pos_ask = tier(d_ask, (1.5, 0.7, 0.3))
    pos = max(pos_first, pos_time, pos_ask)

    # ---- 无标点口播稿专用通道 ----
    # 「40分钟历史」型：9446 字 / 1 段 / 2 句，全篇没有句号问号，第三人称讲史。
    # 三个正向通道全归零（第一人称 0、时间锚点 0.21、问号 0.11），但它靠
    # 「一九一七年」「波斯尼亚的萨拉热窝」这类硬事实被判真人。只对这类
    # 无标点长稿启用硬事实计数 —— AI 稿都有标点（27–115 句），不会走到这里。
    sents_ = split_sentences(text)
    no_punct = len(sents_) <= 3 and total >= 1500
    hard = 0
    if no_punct:
        hard = (len(re.findall(r"\d+(?:\.\d+)?%?", text))
                + len(set(CN_NUM_UNIT.findall(text)))
                + len(set(CN_YEAR.findall(text)))
                + sum(text.count(w) for w in TIME_ANCHORS))
        if hard >= 30:
            pos = max(pos, 16)
        elif hard >= 15:
            pos = max(pos, 10)

    # ---- 反向三通道：AI 的高频动作 ----
    d_quote = dens(len(RE_QUOTE_DLG.findall(text)))
    d_dunhao = dens(text.count("、"))
    d_abstract = dens(sum(text.count(w) for w in ABSTRACT_WORDS))

    pen_quote = 8 if d_quote >= 8 else (4 if d_quote >= 4 else 0)
    pen_dunhao = 8 if d_dunhao >= 10 else (4 if d_dunhao >= 6 else 0)
    pen_abstract = 4 if d_abstract >= 5 else (2 if d_abstract >= 3 else 0)
    pen = pen_quote + pen_dunhao + pen_abstract

    score = max(0, min(20, pos - pen))

    if score >= 18:
        note = "私有细节扎实：有人、有时、有追问，AI 造不出来"
    elif score >= 14:
        note = "私有信息够用"
    elif score >= 8:
        note = "私有信息偏薄 — 再补一处具体经历或真实时间点"
    elif pen >= 6:
        note = ("AI 味信号压过私有信息（引语/顿号罗列/大词过密）"
                "— 删掉引号金句与并列排比，换成自己的事")
    else:
        note = "几乎没有私有信息 — 全篇可替换，朱雀必判高 AIGC"

    detail = {"第一人称": d_first, "时间锚点": d_time, "问号": d_ask,
              "引语": d_quote, "顿号": d_dunhao, "抽象词": d_abstract}
    if no_punct:
        detail["硬事实(无标点稿)"] = hard
    return {"density": round(pos / 10.0, 2), "marks": pos,
            "positive": pos, "penalty": pen, "detail": detail,
            "total_chars": total, "score": score, "note": note}

def check_list_skeleton(text):
    """数字罗列骨架：只有**序号连续递增出现**才算（第一…第二…第三 / 01…02）。
    防误报：'我去年是第一种''他第三段的逻辑' 是具体内容，不是骨架。"""
    hits = {}

    seq = re.findall(r"第([一二三四五六七八九十])", text)
    idxs = [CN_NUM.index(c) for c in seq if c in CN_NUM]
    consec = sum(1 for i in range(1, len(idxs)) if idxs[i] == idxs[i - 1] + 1)
    # 2026-10-27 P1-8：「第一…第二」是中文正常行文（对比、并列），
    # 只有连续递增 >=3 次（第一…第二…第三）才像骨架。
    if consec >= 3:
        hits["数字罗列骨架(第一/第二/第三)"] = consec

    nums = re.findall(r"(?:^|\n|\s)([0-9]{2})[、\.．]", text)
    nidx = [int(n) for n in nums]
    nconsec = sum(1 for i in range(1, len(nidx)) if nidx[i] == nidx[i - 1] + 1)
    if nconsec >= 2:
        hits["数字罗列骨架(01/02/03)"] = nconsec

    # 段首型：连续 2 段以上以"第X"或"0X"开头
    heads = re.findall(r"(?:^|\n)\s*(?:第[一二三四五六七八九十]|[0-9]{2}[、\.．])", text)
    if len(heads) >= 2:
        hits["段落序号骨架"] = len(heads)

    # 枚举型："三个方向/四种方法/五大要素"
    enum = re.findall(r"[三四五六七八九]个(?:方向|维度|方法|要点|步骤|要素|力量|原因|建议)"
                      r"|[三四五六七八九]种(?:方法|类型|情况|方式)", text)
    if enum:
        hits["枚举式罗列(三个方向/四种方法)"] = len(enum)

    return hits


def _split_body_meta(text):
    """把正文行与「元信息行」分开：标题 / 引用 / 整行加粗 / 表格。

    工单 P0-3 依据：小标题点题、表格列名里出现「赛道、维度、方法论」是正常排版，
    不该和正文里的 AI 腔等权。元信息行的命中按 AI_META_WEIGHT 打折。
    """
    body, meta = [], []
    for ln in (text or "").splitlines():
        s = ln.strip()
        if not s:
            continue
        if (s.startswith("#") or s.startswith(">") or s.startswith("|")
                or (s.startswith("**") and s.endswith("**") and len(s) < 40)):
            meta.append(s)
        else:
            body.append(s)
    return "\n".join(body), "\n".join(meta)


def _weighted_hits(text, words, weight):
    """返回 {词: 加权次数}，只保留命中项。"""
    out = {}
    for w in words:
        c = text.count(w)
        if c:
            out[w] = round(c * weight, 2)
    return out


def check_ai_words(text):
    """4. AI 词汇命中（2026-10-26 P0-3 分级版）。

    与旧版差异（全部为降误报）：
    ① 强/弱分级：官样套话满权，领域实词 0.3 权且需 ≥2 个不同弱词共现；
    ② 标题/引用/表格行折扣 0.4；
    ③ 绝对分 + 每千字密度双门限，长文不会被词绝对数压死。
    """
    body, meta = _split_body_meta(text)
    strong = _weighted_hits(body, AI_WORDS_STRONG, AI_W_STRONG)
    strong_meta = _weighted_hits(meta, AI_WORDS_STRONG, AI_W_STRONG * AI_META_WEIGHT)
    weak = _weighted_hits(body, AI_WORDS_WEAK, AI_W_WEAK)
    weak_meta = _weighted_hits(meta, AI_WORDS_WEAK, AI_W_WEAK * AI_META_WEIGHT)

    strong_abs = sum(strong.values()) + sum(strong_meta.values())
    weak_distinct = len(set(list(weak) + list(weak_meta)))
    # 弱词只在「≥2 个不同词共现」时才计入——单个「迭代 / 展示」属正常写作
    weak_abs = (sum(weak.values()) + sum(weak_meta.values())
                if weak_distinct >= AI_WEAK_MIN_DISTINCT else 0.0)

    abs_score = round(strong_abs + weak_abs, 2)
    cjk = len(CJK.findall(text or ""))
    # 2026-10-27 P1-8：密度分母设 600 字下限。415 字稿里 3 个弱词，按真实字数
    # 算出 2.89/千字被判「中度」扣 7 分；按 600 字分母是 2.0，属轻微。
    density = round(abs_score / max(cjk, 600) * 1000, 2)

    # 合并命中表（保留旧字段形态：{词: 次数}，供 UI 直接展示）
    hits = {}
    for w in AI_WORDS_STRONG + AI_WORDS_WEAK:
        c = (text or "").count(w)
        if c:
            hits[w] = c

    if abs_score == 0:
        score, note = 15, "无 AI 词汇"
    elif cjk >= 400:
        if density <= 2.4:
            score, note = 15, (f"轻微命中（加权 {abs_score}，密度 {density}/千字，"
                               f"未达扣分线）：{', '.join(list(hits)[:8])}")
        elif density <= 5.0:
            score, note = 8, (f"中度命中（加权 {abs_score}，密度 {density}/千字）："
                              f"{', '.join(list(hits)[:8])} — 建议替换官样套话")
        else:
            score, note = 0, (f"重度命中（加权 {abs_score}，密度 {density}/千字）："
                              f"{', '.join(list(hits)[:8])} — AI 词汇超标")
    else:
        if abs_score <= 1.0:
            score, note = 15, f"轻微命中（加权 {abs_score}，短文按绝对分判定）"
        elif abs_score <= 3.0:
            score, note = 8, f"中度命中（加权 {abs_score}）：{', '.join(list(hits)[:8])}"
        else:
            score, note = 0, f"重度命中（加权 {abs_score}）：{', '.join(list(hits)[:8])} — AI 词汇超标"

    return {
        "total": int(round(abs_score)),
        "hits": hits,
        "score": score,
        "note": note,
        "abs_score": abs_score,
        "density": density,
        "strong_hits": {k: v for k, v in list(strong.items()) + list(strong_meta.items())},
        "weak_hits": {k: v for k, v in list(weak.items()) + list(weak_meta.items())},
        "weak_distinct": weak_distinct,
    }


def _fingerprint_gate(count, text, min_abs=3, min_density=3.0, floor_cjk=600):
    """指纹类命中的统一门限（2026-10-27 P1-8）。

    绝对数 + 每千字密度双条件，且密度分母设 600 字下限 —— 短文（300-500 字）
    用真实字数当分母会让单个词/单个破折号的密度虚高 3 倍，是 P0-3 破折号
    误杀之后又反复出现的老问题。返回 (是否计为指纹, 密度)。
    """
    cjk = len(CJK.findall(text or ""))
    dens = count / max(cjk, floor_cjk) * 1000
    return (count >= min_abs and dens >= min_density), dens


def check_zh_patterns(text):
    """5. 中文指纹 C1-C7 中可机械检测的部分。"""
    hits = {}
    advice = []   # 2026-10-26 P0-3：不计分但需要告诉作者的提示（Emoji / 破折号等）

    # C1 「…着」伪深度（中文版 -ing 肤浅分析）
    # 2026-10-27 P1-8：同 C2 口径，改为「≥3 处且 ≥3/千字」。单篇真人稿 2228 字
    # 出现 2 处「存在着，」被判指纹扣 8 分，属正常表述。
    zhe = len(re.findall(r"[\u4e00-\u9fff]{1,4}着[，,、]", text))
    _c1_flag, _c1_dens = _fingerprint_gate(zhe, text)
    if _c1_flag:
        hits["C1「…着」伪深度"] = zhe
    elif zhe:
        advice.append(f"C1「…着」{zhe} 处（密度 {_c1_dens:.1f}/千字，属正常表述，不计分）")

    # C2 反义对仗 / 伪深刻
    # 2026-10-27 P1-8：改为密度门限。依据 P1-4 基线：4 篇真人稿因单处「不是…而是…」
    # 被判「必须改」，「不是A而是B」在中文里本就是最常用的正常转折，历史讲解稿尤其高频。
    # 口径与破折号一致：≥4 处且密度 ≥3/千字才算指纹，其余降级为提示。
    anti = 0
    for p in ANTITHESIS_PATTERNS:
        anti += len(re.findall(p, text))
    _c2_flag, anti_density = _fingerprint_gate(anti, text, min_abs=4)
    if _c2_flag:
        hits["C2「不是A而是B」"] = anti
    elif anti:
        advice.append(f"C2「不是A而是B」{anti} 处（密度 {anti_density:.1f}/千字，"
                      f"属正常转折表述，不计分）")

    # 破折号（2026-10-26 P0-3 首次改密度门限；2026-10-27 P1-8 统一口径）
    # 依据：作者教程稿 3 篇里 5 处破折号全部是「解释展开」的正常用法，
    # 旧版按绝对数 ≥1 即计入，是「贴图版教程被判 0 分」的直接原因之一。
    # 现行口径与 C1/C2 一致：≥3 处且 ≥3/千字（分母下限 600），
    # 338 字短稿里 2 处破折号不再被判指纹。
    dash = len(re.findall(r"——", text))
    _dash_flag, dash_density = _fingerprint_gate(dash, text)
    if _dash_flag:
        hits["破折号——"] = dash
    elif dash:
        advice.append(f"破折号 {dash} 处（密度 {dash_density:.1f}/千字，属正常展开用法，不计分）")

    # Emoji（2026-10-26 P0-3：移出计分项，只作提示）
    # 依据：公众号教程/清单文体用 emoji 当条目符号是排版需要，朱雀等检测器也不按
    # emoji 判 AI 味；旧版 47/29/67 个 emoji 直接让「中文指纹」归零。
    emo = len(EMOJI_PATTERN.findall(text))
    if emo:
        advice.append(f"Emoji {emo} 处（按排版元素处理，不计入 AI 指纹）")

    # 数字罗列骨架（2026-10-26 P0-3：教程/步骤语境下降权）
    _skeleton = check_list_skeleton(text)
    _tutorial_words = ("步骤", "教程", "操作", "点击", "设置", "第一步", "安装", "下载")
    _is_tutorial = any(w in (text or "") for w in _tutorial_words)
    if _skeleton and _is_tutorial:
        advice.append("数字罗列骨架出现在教程/操作说明语境，按步骤编号处理，降权计分")
        _skeleton = {k: max(1, int(round(v * 0.2))) for k, v in _skeleton.items()}
    hits.update(_skeleton)

    # 理论背书堆叠（《》书名号 >= 2）
    books = re.findall(r"《[^》]{1,20}》", text)
    if len(books) >= 2:
        hits["理论背书堆叠"] = len(books)

    total = sum(hits.values())
    if total == 0:
        score, note = 15, "中文指纹全部干净"
    elif total <= 2:
        score, note = 7, f"命中 {total} 处：{'; '.join(f'{k}×{v}' for k, v in hits.items())}"
    else:
        score, note = 0, f"命中 {total} 处：{'; '.join(f'{k}×{v}' for k, v in hits.items())} — 必须改"

    return {"total": total, "hits": hits, "score": score, "note": note,
            "advice": advice}


# ============ 句式层 / 统计层（2026-10-25「过朱雀」批次新增）============
# 为什么加这一组：原有 6 项只覆盖「措辞 + 粗粒度节奏」，而实测证明
# AI 味的可测差异大量落在句法动作与词汇分布上（名词化、同构排比、借喻、
# 连词堆叠、语气词缺失）。这一组全部是纯正则/统计，不进 LLM、不耗额度。


def check_nominalization(text: str) -> list:
    """S1 名词化：「进行讨论 / 加以说明 / 予以处理 / 做出决定」→ 直接用动词。

    Humanizer-zh #27、human-writing NOMINALIZATION、sepia zh §2「双字 padding」。
    这是正式稿最典型的机器味，原有 6 项一项都没覆盖。
    """
    out = []
    for h in NOMINALIZE_HEADS:
        for m in re.finditer(re.escape(h), text):
            mm = re.match(r"(?:的|了|一次|一个)?([\u4e00-\u9fff]{2,4})", text[m.end():m.end() + 8])
            if mm:
                out.append(h + mm.group(1))
    return out


def check_triple_parallel(text: str) -> list:
    """S2 三项同构排比（无序号）：「是A，是B，是C」「X的A，Y的B，Z的C」。

    原有 check_list_skeleton 只认「第一/第二/第三」带序号的骨架，
    抓不到这种不带序号的同构三项——而这正是 AI 最爱用的形式。
    """
    out = []
    # 形如「思考的延伸，表达的锤炼，认知的沉淀」
    for m in re.finditer(
        r"(?:[\u4e00-\u9fff]{2,8}的[\u4e00-\u9fff]{2,8}[，、]){2}[\u4e00-\u9fff]{2,8}的[\u4e00-\u9fff]{2,8}",
        text):
        out.append(m.group(0)[:24])
    # 形如「是A，是B，是C」
    for m in re.finditer(r"(?:是[^，。！？；]{2,12}[，、]){2}是[^，。！？；]{2,12}", text):
        out.append(m.group(0)[:24])
    return out


def check_metaphor_cluster(text: str) -> list:
    """S3 借喻簇：抽象名词配具体动词写抒情（「时间保管细节」「焦虑显出形状」）。

    human-writing 的 LYRIC_WORDS + metaphor_cluster（同域隐喻在窗口内扎堆）。
    公众号 AI 稿最高频的假文学，原有 6 项零覆盖。
    """
    out = []
    for s in LYRIC_SUBJECTS:
        for v in LYRIC_VERBS:
            for m in re.finditer(re.escape(s) + r"[^。！？；]{0,6}" + re.escape(v), text):
                out.append(m.group(0))
    return out


def check_long_attribution(sents: list) -> list:
    """S4 长定语「的」堆叠：单句 ≥4 个「的」且句长 >25 字。

    Humanizer-zh #26（层叠的「的」）、human-writing heavy_de_sentences。
    """
    out = []
    for s in sents:
        n = s.count("的")
        if n >= 4 and cjk_len(s) > 25:
            out.append(s[:24] + f"（的×{n}）")
    return out


def check_connective_density(text: str) -> dict:
    """S5 连词密度：sepia 实测 人 0.013 vs AI 0.036；「和」人 4.13 vs AI 11.76 每答。

    只统计 ≥2 字的连词 + 「和」（单字的「还/又/也」是口语高频，不计入，否则
    会误伤真人稿——这是实测校准时特意排除的）。
    """
    total = max(len(CJK.findall(text)), 1)
    strict = [c for c in CN_CONNECTIVES if len(c) >= 2]
    n = sum(text.count(c) for c in strict)
    he = text.count("和")
    per1k = round((n + he) / (total / 1000.0), 2)
    return {"count": n + he, "he": he, "per1k": per1k, "total": total}


def check_modal_density(text: str) -> dict:
    """S6 语气词密度 —— 唯一「越少越像 AI」的指标。

    sepia 实测：人 0.016 vs AI 0.003，**人高 5 倍**。
    其余指标都是「多了扣分」，这一项必须反过来：语气词接近零 = 机器腔。
    """
    total = max(len(CJK.findall(text)), 1)
    n = sum(text.count(p) for p in CN_MODAL_PARTICLES)
    per1k = round(n / (total / 1000.0), 2)
    return {"count": n, "per1k": per1k, "total": total}


def check_equal_len_runs(sents: list) -> list:
    """S7 中长句等长 run：连续 3 句以上、长度差 <15% 且每句 >22 字。

    sepia §5：句长**离散度**是唯一方向一致的句法指标（人 9.248 vs AI 6.729）。
    原有「碎句带」只查 4–15 字的短句扎堆，查不出「连续 30–40 字的等长句」——
    而那才是 AI 写中文最典型的节奏。
    """
    lens = [cjk_len(s) for s in sents]
    runs, cur = [], []
    for i, L in enumerate(lens):
        if L < RUN_MIN_LEN:
            if len(cur) >= 3:
                runs.append(cur)
            cur = []
            continue
        if cur:
            prev = lens[cur[-1]]
            if abs(L - prev) / max(prev, 1) <= RUN_TOL:
                cur.append(i)
            else:
                if len(cur) >= 3:
                    runs.append(cur)
                cur = [i]
        else:
            cur = [i]
    if len(cur) >= 3:
        runs.append(cur)
    return [[b + 1, e + 1] for b, e in ((r[0], r[-1]) for r in runs)]


def check_lexical_richness(text: str) -> dict:
    """S8 词汇丰富度：bigram TTR。sepia 实测 人 0.725 vs AI 0.543。

    用字级 bigram 而不是单字（单字 TTR 对长文会天然偏低，无区分度）。
    """
    s = "".join(CJK.findall(text))
    if len(s) < 60:
        return {"ttr": None, "grams": 0, "note": "样本太短"}
    grams = [s[i:i + 2] for i in range(len(s) - 1)]
    ttr = round(len(set(grams)) / len(grams), 3)
    return {"ttr": ttr, "grams": len(grams)}


def check_syntax_layer(text: str, sents: list) -> dict:
    """句式层汇总（S1–S8）。返回明细 + 命中数，供 scan() 计入总分。"""
    s1 = check_nominalization(text)
    s2 = check_triple_parallel(text)
    s3 = check_metaphor_cluster(text)
    s4 = check_long_attribution(sents)
    s5 = check_connective_density(text)
    s6 = check_modal_density(text)
    s7 = check_equal_len_runs(sents)
    s8 = check_lexical_richness(text)
    return {"s1_nominal": s1, "s2_triple": s2, "s3_metaphor": s3,
            "s4_longattr": s4, "s5_conn": s5, "s6_modal": s6,
            "s7_run": s7, "s8_ttr": s8}


# 🔴 阈值来自本文件实测校准（2026-10-25）：11 篇真人原声稿 vs AI 味稿对照。
#   · 名词化   真人 0–2 / AI 3  → ≥3 扣分
#   · 三项排比 真人 0–2 / AI 3  → ≥3 扣分
#   · 借喻簇   真人 11 篇**全 0** / AI 3 → ≥1 扣分（真人从不命中，最干净的信号）
# 以下 5 项实测**不足以扣分**，只做提示，绝不能进 penalty：
#   · 长定语：真人 0–5（中位 1）反而多于 AI 0   → 扣了必误伤
#   · 连词密度：真人 3.85–17.73（中位 10.96），AI 14.93 落在真人范围内 → 弱区分
#   · 语气词：真人中位 0（多篇为 0）→ 「少则罚」会把真人稿全部打挂
#   · 等长 run：真人与本 AI 样本均为 0 → 无证据
#   · TTR：本口径下 AI 0.925 > 真人最高 0.911，**方向与 sepia 相反** → 未验证，禁用
SYNTAX_MAX_PENALTY = 12


def score_syntax_layer(d: dict) -> dict:
    """句式层计分：只扣实测站得住的 3 项，其余 5 项降级为提示。

    🔴 设计纪律：宁可少扣不可误伤。真人基线（11 篇）在这 3 项上命中均为 0，
    所以新增这一组对真人稿**零影响**，只打 AI 味稿。
    """
    n1 = len(d["s1_nominal"])
    n2 = len(d["s2_triple"])
    n3 = len(d["s3_metaphor"])
    penalty, hits = 0, []
    if n1 >= 3:
        penalty += 4
        hits.append(f"名词化×{n1}：" + "、".join(d["s1_nominal"][:3]))
    if n2 >= 3:
        penalty += 4
        hits.append(f"三项同构排比×{n2}")
    if n3 >= 1:
        penalty += 4
        hits.append(f"借喻簇×{n3}：" + "、".join(d["s3_metaphor"][:2]))
    penalty = min(penalty, SYNTAX_MAX_PENALTY)

    advice = []
    if d["s4_longattr"]:
        advice.append(f"长定语「的」堆叠 {len(d['s4_longattr'])} 处（真人稿也会出现，仅供参考）")
    if d["s5_conn"]["per1k"] >= 18:
        advice.append(f"连词密度 {d['s5_conn']['per1k']}/千字（偏高，真人中位 10.96）")
    if d["s6_modal"]["per1k"] == 0:
        advice.append("语气词为 0：真人稿中位也是 0，不是扣分项，但如果通篇没有口语颗粒可考虑补一点")
    if d["s7_run"]:
        advice.append(f"中长句等长 run {len(d['s7_run'])} 处（真人基线 0 处）")
    ttr = d["s8_ttr"].get("ttr")
    if isinstance(ttr, float) and ttr < 0.80:
        advice.append(f"bigram TTR {ttr}（偏低；注意本口径下方向与 sepia 相反，仅参考）")

    return {"penalty": penalty, "hits": hits, "advice": advice,
            "note": "；".join(hits) if hits else "句式层干净"}


def check_golden_ending(sents):
    """6. 伪金句结尾：最后 2 句含总结腔标志词。

    P1-9：强标志命中即判 0；弱标志（真正的/这才是…）需 >=2 个不同词才判 0，
    否则只提示。依据 P1-4 基线：3 篇真人稿只栽在单个「真正的」上。
    """
    if len(sents) < 2:
        return {"score": 10, "note": "样本不足"}
    # 查最后 3 句（"综上所述"常在倒数第 3 句，最后 2 句才是升华）
    tail = "".join(sents[-3:])
    strong = [w for w in GOLDEN_MARKERS_STRONG if w in tail]
    weak = [w for w in GOLDEN_MARKERS_WEAK if w in tail]
    if strong or len(weak) >= 2:
        hit = strong + weak
        return {"hits": hit, "score": 0,
                "note": f"结尾含伪金句标志：{', '.join(hit)} — 换开放尾"}
    note = "结尾无总结腔"
    if weak:
        note = f"结尾出现弱标志「{'、'.join(weak)}」（属正常强调，不计分）"
    return {"hits": [], "score": 10, "note": note}


# ============ 主流程 ============

def scan(text: str):
    sents = split_sentences(text)
    paras = split_paragraphs(text)

    r1 = check_burstiness(sents, text)
    r2 = check_frag_bands(sents, text)
    r3 = check_truth_density(text)
    r4 = check_ai_words(text)
    r5 = check_zh_patterns(text)
    r6 = check_golden_ending(sents)

    # 2026-10-25「过朱雀」批次：句式层（S1–S8）。只扣实测站得住的 3 项，
    # 真人基线命中为 0 → 对真人稿零影响；未验证的 5 项降级为 advice 提示。
    sl = check_syntax_layer(text, sents)
    r7 = score_syntax_layer(sl)

    # 段落均匀度（辅助项，不计分，只提示）
    para_cv = 0
    if len(paras) >= 3:
        pl = [cjk_len(p) for p in paras]
        m = statistics.mean(pl)
        para_cv = round(statistics.pstdev(pl) / m, 3) if m else 0

    total = (r1["score"] + r2["score"] + r3["score"] + r4["score"]
             + r5["score"] + r6["score"] - r7["penalty"])
    total = max(0, total)
    if total >= PASS_LINE:
        verdict = "PASS"
    elif total >= WARN_LINE:
        verdict = "WARN"
    else:
        verdict = "FAIL"

    return {
        "verdict": verdict,
        "total": total,
        "stats": {"句数": len(sents), "段数": len(paras),
                  "汉字数": len(CJK.findall(text)),
                  "段落长度变异系数": para_cv},
        # 2026-10-26 P0-3：不计分提示（Emoji / 破折号 / 教程骨架等），顶层汇总便于 UI 展示
        "advice": list(r5.get("advice") or []) + list(r4.get("advice") or []),
        "items": {
            "1_Burstiness(25)": r1,
            "2_碎句带(15)": r2,
            "3_真事密度(20)": r3,
            "4_AI词汇(15)": r4,
            "5_中文指纹(15)": r5,
            "6_伪金句结尾(10)": r6,
            # 附加扣分组（负值，最多 -12）；真人基线命中为 0，不影响原有判定
            "7_句式层(附加-12)": r7,
        },
        "syntax_layer": sl,
    }


def render_terminal(r):
    v = r["verdict"]
    color = {"PASS": "\033[92m", "WARN": "\033[93m", "FAIL": "\033[91m"}.get(v, "")
    reset = "\033[0m"
    lines = []
    lines.append("=" * 62)
    lines.append(f"  中文 AI 味机械扫描 v1.0   |   判定：{color}{v}{reset}   总分 {r['total']}/100")
    lines.append("=" * 62)
    s = r["stats"]
    lines.append(f"  基础：{s['句数']} 句 / {s['段数']} 段 / {s['汉字数']} 字 / 段落CV {s['段落长度变异系数']}")
    lines.append("-" * 62)
    for k, it in r["items"].items():
        name = k.split("_", 1)[1]
        # 句式层是附加扣分组（只有 penalty，无 score），按「扣 0 分即干净」判对勾
        if "句式层" in name:
            mark = "✓" if not it.get("penalty") else "✗"
        else:
            mark = "✓" if it.get("score", 0) >= 0.7 * _max_of(name) else "✗"
        lines.append(f"  {mark} {name:<22} {it.get('score', -it.get('penalty', 0)):>3} 分   {it['note']}")
        if name.startswith("1_") or name.startswith("Burstiness"):
            lines.append(f"      └ 句长 {it.get('min')}~{it.get('max')} 字，均值 {it.get('mean')}，标准差 {it.get('std')}")
        if name.startswith("3_") or name.startswith("真事"):
            lines.append(f"      └ 私有信号 {it.get('positive')} 分 − AI味扣 {it.get('penalty')} 分"
                         f" → {it.get('score')} 分")
            lines.append(f"      └ 明细 {it.get('detail')}")
    lines.append("=" * 62)
    if v == "FAIL":
        lines.append("  ❌ 不许发。机械层都没过，朱雀必挂。")
    elif v == "WARN":
        lines.append("  ⚠️  建议回改。机械层过了还要跑 humanizer-zh 语义层。")
    else:
        lines.append("  ✅ 机械层通过。下一步：跑 humanizer-zh（语义层，评分 /50）")
    lines.append("=" * 62)
    return "\n".join(lines)


def _max_of(name):
    for k, v in {"Burstiness": 25, "碎句带": 15, "真事密度": 20,
                 "AI词汇": 15, "中文指纹": 15, "伪金句结尾": 10}.items():
        if name.startswith(k):
            return v
    return 10


def render_md(r):
    lines = [f"### 机械层 AI 味扫描：{r['verdict']} · {r['total']}/100", ""]
    lines.append("| 检测项 | 得分 | 结论 |")
    lines.append("|---|---|---|")
    for k, it in r["items"].items():
        name = k.split("_", 1)[1]
        lines.append(f"| {name} | {it.get('score', -it.get('penalty', 0))} | {it['note']} |")
    s = r["stats"]
    lines.append("")
    lines.append(f"基础统计：{s['句数']} 句 / {s['段数']} 段 / {s['汉字数']} 字")
    return "\n".join(lines)


# 注：移植自胜元「爆款内容预检」skill 的 scripts/ai_smell_scan.py。
# 已移除 CLI 入口（main / __main__），本模块在工坊内作为库使用：
#   from app.core.ai_score import scan, _max_of
#   r = scan(text)  -> {"verdict","total","stats","items"}
# 渲染请用 render_md(r)（Web 侧自行解析 items，不使用 render_terminal 的 ANSI 输出）。
