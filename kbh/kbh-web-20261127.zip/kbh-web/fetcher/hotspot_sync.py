# -*- coding: utf-8 -*-
"""热点同步：桌面端 publish → 云端 hotspot_item → 网页/小程序 pull。

设计要点（对应 ai-writer/docs/web/01_热点同步接口契约.md）：
  - 写入只走云端 SECURITY DEFINER RPC `hotspot_publish`，**不用 service_role**，
    不给 authenticated/anon 任何 INSERT/UPDATE 策略（对标 card_admin）。
  - 身份校验两道：本模块先用 x-user-token 解 sub 并要求云端 is_admin() 为真；
    RPC 内部再拿 p_key + p_uid 校验一次，双保险。
  - 读取走云端 REST select，RLS `read_authed` 只允许 authenticated。
  - 任何异常都不抛出，返回 (data, err) 交给 server.py 的 _api_call 统一处理。
"""
import hashlib
import json
import re

# 由 server.py 注入（避免本模块重复定义常量）：
#   CFG = {"endpoint":..., "pub_key":..., "rpc":..., "db":...,
#          "cloud_headers": fn, "jwt_uid": fn}
CFG = {}


class SyncError(Exception):
    def __init__(self, code, http=400, message=""):
        super().__init__(message or code)
        self.code = code
        self.http = http


def norm_url(url):
    """与桌面端 feed_store 的 oriUrl 规范化保持一致。"""
    s = str(url or "").strip()
    s = re.sub(r"^https?://", "", s, flags=re.I)
    s = s.split("#")[0].split("?")[0].rstrip("/")
    return s.lower()


def make_item_id(url):
    return hashlib.md5(norm_url(url).encode("utf-8")).hexdigest()[:12]


# 写入允许字段（白名单，前端多传的一律丢弃）
_FIELDS = (
    "item_id", "ori_url", "title", "summary", "content", "cover_url",
    "thumbnail", "form", "form_confidence", "form_conflict", "track",
    "clicks_count", "share_count", "like_count", "comment_count",
    "watch_count", "user_name", "public_time", "data_date",
)
_INT_FIELDS = {
    "clicks_count", "share_count", "like_count", "comment_count", "watch_count",
}
_BOOL_FIELDS = {"form_conflict"}
_FLOAT_FIELDS = {"form_confidence"}


def _request(method, url, payload=None, token=None, timeout=25):
    import requests
    headers = dict(CFG.get("cloud_headers")(token)) if token else {
        "x-wb-webapp-access-key": CFG["pub_key"],
        "Content-Type": "application/json",
        "Origin": CFG["endpoint"],
        "Referer": CFG["endpoint"] + "/",
    }
    if method == "POST":
        r = requests.post(url, json=payload or {}, headers=headers, timeout=timeout)
    else:
        r = requests.get(url, params=payload or {}, headers=headers, timeout=timeout)
    return r


def _check_admin(token):
    """云端 is_admin() 校验。返回 uid；非管理员抛 403。"""
    if not token:
        raise SyncError("UNAUTHORIZED", 401, "缺少登录凭证")
    uid = CFG["jwt_uid"](token)
    if not uid:
        raise SyncError("UNAUTHORIZED", 401, "凭证无法识别")
    try:
        r = _request("POST", CFG["rpc"] + "is_admin", {}, token=token, timeout=15)
        if r.status_code in (401, 403):
            raise SyncError("UNAUTHORIZED", 401, "登录已过期")
        data = r.json()
    except SyncError:
        raise
    except Exception as e:  # noqa: BLE001
        raise SyncError("DB_ERROR", 500, "admin check failed: %s" % e)
    ok = bool(data.get("ok"))
    if isinstance(data, dict):
        ok = ok or bool(data.get("data")) or bool(
            (data.get("result") or {}).get("is_admin")
            if isinstance(data.get("result"), dict) else False)
    if not ok:
        raise SyncError("FORBIDDEN", 403, "仅主理人可发布热点")
    return uid


def publish(body, token):
    """桌面端批量推送。返回 (result, None) 或 (None, err)。"""
    uid = _check_admin(token)
    claimed = str(body.get("publisher_user_id") or "").strip()
    if claimed and claimed != uid:
        raise SyncError("FORBIDDEN", 403, "发布者与登录者不一致")
    items = body.get("items") or []
    if not isinstance(items, list) or not items:
        raise SyncError("INVALID_ITEM", 400, "items 不能为空")
    if len(items) > 500:
        raise SyncError("TOO_MANY_ITEMS", 413, "单批最多 500 条")

    clean = []
    for i, raw in enumerate(items):
        if not isinstance(raw, dict):
            raise SyncError("INVALID_ITEM", 400, "第 %d 条不是对象" % i)
        row = {}
        for k in _FIELDS:
            if k not in raw or raw[k] is None:
                continue
            v = raw[k]
            if k in _INT_FIELDS:
                try:
                    v = int(v)
                except (TypeError, ValueError):
                    v = 0
            elif k in _FLOAT_FIELDS:
                try:
                    v = float(v)
                except (TypeError, ValueError):
                    v = None
            elif k in _BOOL_FIELDS:
                v = bool(v)
            else:
                v = str(v).strip()
            row[k] = v
        if not row.get("ori_url"):
            raise SyncError("INVALID_ITEM", 400, "第 %d 条缺 ori_url" % i)
        row["item_id"] = str(row.get("item_id") or "").strip()[:64] or make_item_id(row["ori_url"])
        if not row.get("title"):
            row["title"] = "(无标题)"
        clean.append(row)

    payload = {"p_uid": uid, "p_items": clean}
    try:
        r = _request("POST", CFG["rpc"] + "hotspot_publish", payload,
                     token=token, timeout=40)
    except Exception as e:  # noqa: BLE001
        raise SyncError("DB_ERROR", 500, "publish failed: %s" % e)
    if r.status_code in (401, 403):
        raise SyncError("FORBIDDEN", 403, "RPC 拒绝写入")
    if r.status_code >= 400:
        raise SyncError("DB_ERROR", 500, "RPC HTTP %d" % r.status_code)
    try:
        data = r.json()
    except Exception:  # noqa: BLE001
        raise SyncError("DB_ERROR", 500, "RPC 返回非 JSON")
    if data.get("ok") is False or data.get("error"):
        raise SyncError("DB_ERROR", 500, str(data.get("message") or data.get("error"))[:160])
    return data, None


def pull(params, token):
    """网页/小程序只读拉取。token 必须有效（RLS authenticated）。"""
    if not token:
        raise SyncError("UNAUTHORIZED", 401, "请先登录")
    try:
        since = int(params.get("since") or 0)
    except (TypeError, ValueError):
        since = 0
    form = str(params.get("form") or "").strip()
    if form and form not in ("sticker", "article", "comic", "unknown"):
        form = ""
    try:
        limit = min(max(int(params.get("limit") or 500), 1), 1000)
    except (TypeError, ValueError):
        limit = 500

    q = {"select": "*", "order": "server_version.asc", "limit": limit + 1}
    if since > 0:
        q["server_version"] = "gt.%d" % since
    if form:
        q["form"] = "eq." + form
    try:
        r = _request("GET", CFG["db"] + "hotspot_item", q, token=token, timeout=25)
    except Exception as e:  # noqa: BLE001
        raise SyncError("DB_ERROR", 500, "pull failed: %s" % e)
    if r.status_code in (401, 403):
        raise SyncError("UNAUTHORIZED", 401, "登录已过期")
    if r.status_code >= 400:
        raise SyncError("DB_ERROR", 500, "REST HTTP %d" % r.status_code)
    try:
        rows = r.json()
    except Exception:  # noqa: BLE001
        raise SyncError("DB_ERROR", 500, "REST 返回非 JSON")
    if not isinstance(rows, list):
        raise SyncError("DB_ERROR", 500, "REST 返回格式异常")
    has_more = len(rows) > limit
    rows = rows[:limit]
    sv = max([int(x.get("server_version") or 0) for x in rows], default=since)
    dates = [str(x.get("data_date") or "") for x in rows if x.get("data_date")]
    return {
        "items": rows,
        "server_version": sv,
        "latest_data_date": max(dates) if dates else "",
        "has_more": has_more,
    }, None


def state(token):
    """纯读：当前游标 + 最新日期 + 总条数。"""
    if not token:
        raise SyncError("UNAUTHORIZED", 401, "请先登录")
    q = {"select": "server_version,data_date", "order": "server_version.desc", "limit": 1}
    try:
        r = _request("GET", CFG["db"] + "hotspot_item", q, token=token, timeout=15)
    except Exception as e:  # noqa: BLE001
        raise SyncError("DB_ERROR", 500, "state failed: %s" % e)
    if r.status_code in (401, 403):
        raise SyncError("UNAUTHORIZED", 401, "登录已过期")
    if r.status_code >= 400:
        raise SyncError("DB_ERROR", 500, "REST HTTP %d" % r.status_code)
    try:
        rows = r.json() or []
    except Exception:  # noqa: BLE001
        raise SyncError("DB_ERROR", 500, "REST 返回非 JSON")
    first = rows[0] if isinstance(rows, list) and rows else {}
    vr = _request("GET", CFG["db"] + "hotspot_item",
                  {"select": "item_id", "limit": 1}, token=token, timeout=15)
    total = 0
    if vr.status_code == 200:
        try:
            h = vr.headers.get("content-range") or ""
            total = int(h.rsplit("/", 1)[-1]) if "/" in h else 0
        except (ValueError, AttributeError):
            total = 0
    return {
        "server_version": int(first.get("server_version") or 0),
        "latest_data_date": str(first.get("data_date") or ""),
        "total_items": total,
    }, None
