// ============================================================
// 详情页脚本（articles/*.html 共用）
// 1. 会员门禁 guard：未登录/非有效会员 → 回会员站「会员服务」页，并带上原因
// 2. 阅读进度条 / 返回顶部 / 代码块复制
// ============================================================
(function(){
  // ---- guard：正文先隐藏，校验通过再显示 ----
  document.documentElement.classList.add('auth-wait');
  var isLocal = ['localhost','127.0.0.1'].indexOf(location.hostname) > -1;
  var passed = false;

  function allow(){
    if (passed) return;
    passed = true;
    document.documentElement.classList.remove('auth-wait');
    setupPage();
  }
  // 2026-11-01 修：原来一律 location.href='../index.html'，用户看到的就是「点开又被丢回主页」，
  // 而且完全不知道为什么。现在把原因带回去（need=login / member / error），由会员站弹一句说明。
  function deny(reason){
    location.replace('../index.html#page=service&need=' + (reason || 'member'));
  }

  function isMemberValid(m){
    return !!(m && m.tier && m.tier !== 'none' && m.expires_at && new Date(m.expires_at) > new Date());
  }

  if (isLocal && location.hash === '#preview'){
    allow(); // 本地预览豁免（线上域名不生效）
    return;
  }

  if (typeof cloud === 'undefined'){
    document.documentElement.classList.remove('auth-wait');
    var d = document.createElement('div');
    d.style.cssText = 'position:fixed;inset:0;z-index:999;background:#F5F4F0;display:flex;align-items:center;justify-content:center;text-align:center;padding:24px;font-size:14px;color:#5F5E5A;line-height:1.9';
    d.innerHTML = '资源加载失败（网络异常），请刷新重试。<br><a href="../index.html" style="color:#FF4D00">返回会员站</a>';
    document.body.appendChild(d);
    return;
  }

  var timeout = setTimeout(function(){ deny('error'); }, 6000); // 网络异常兜底：6s 未通过则回会员站
  (async function(){
    try{
      var sess = await cloud.auth.getSession();
      var user = sess && sess.data && sess.data.user;
      if (!user){ clearTimeout(timeout); deny('login'); return; }
      // 2026-11-01 修 BUG（用户报「点开文章又回主页」的真因）：
      // 原来这里是 .maybeSingle()。memberships 上有 memberships_select_admin 策略（is_admin() 对 public 开放），
      // 管理员账号一查会返回**全部**会员行 → PGRST116 多行错误 → data 为 null
      // → 年卡被判成「非会员」→ 直接弹回主页。与 dataLayer.js 的 getMyMembership() 保持同一套修法：
      // 显式按自己的 uid 过滤，取 expires_at 最晚的一条（兼容一人多卡续期），不用 maybeSingle。
      // 注意不能只 order by expires_at：管理员会拿到别人的（到期更晚的）那条。
      var rq = await cloud.database.from('memberships').select('*')
        .eq('owner_id', user.id)
        .order('expires_at', { ascending: false })
        .limit(1);
      var m = (rq && rq.data && rq.data[0]) || null;
      if (!isMemberValid(m)){ clearTimeout(timeout); deny('member'); return; }
      clearTimeout(timeout);
      allow();
    }catch(e){ clearTimeout(timeout); deny('error'); }
  })();

  // ---- 页面交互（脚本位于 body 末尾，DOM 已就绪） ----
  function setupPage(){
    // 阅读进度条
    var bar = document.querySelector('.progress-bar');
    var backtop = document.querySelector('.backtop');
    function onScroll(){
      var h = document.documentElement;
      var max = h.scrollHeight - h.clientHeight;
      if (bar) bar.style.width = (max > 0 ? (h.scrollTop / max) * 100 : 0) + '%';
      if (backtop) backtop.classList.toggle('show', h.scrollTop > 600);
    }
    window.addEventListener('scroll', onScroll, { passive:true });
    onScroll();
    if (backtop) backtop.onclick = function(){ window.scrollTo({ top:0, behavior:'smooth' }); };

    // 代码块复制按钮
    document.querySelectorAll('pre').forEach(function(pre){
      var btn = document.createElement('button');
      btn.className = 'code-copy';
      btn.textContent = '复制';
      btn.onclick = function(){
        var code = pre.querySelector('code');
        var text = code ? code.innerText : pre.innerText;
        function done(){ btn.textContent = '已复制'; setTimeout(function(){ btn.textContent = '复制'; }, 1500); }
        if (navigator.clipboard && navigator.clipboard.writeText){
          navigator.clipboard.writeText(text).then(done);
        } else {
          var ta = document.createElement('textarea');
          ta.value = text; document.body.appendChild(ta); ta.select();
          document.execCommand('copy'); document.body.removeChild(ta); done();
        }
      };
      pre.appendChild(btn);
    });
  }
})();
