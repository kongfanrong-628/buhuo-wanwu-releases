// publicConfig —— 云服务开通时返回。publishableKey 无权限可公开，服务端按域名 Origin 校验。
const PUBLIC_CONFIG = {
  endpoint: "https://kongbuhuo-member.app.workbuddy.host",
  publishableKey: "wbpk_lwasoCDMaCIVvRZlKpG9HO_PE10H7OY2Bf7mH9x2wzNyU7LScYeXp88"
};

// 全站唯一云客户端：Auth / Database 共用，登录后自动携带会话
const cloud = WorkBuddyCloud.createWorkBuddyCloud({
  endpoint: PUBLIC_CONFIG.endpoint,
  publishableKey: PUBLIC_CONFIG.publishableKey
});
